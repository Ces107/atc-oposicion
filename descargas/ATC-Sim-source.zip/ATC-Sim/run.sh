#!/bin/sh
# ATC Sim launcher for macOS / Linux: private virtual environment in ~/.cache/atcsim-venv
cd "$(dirname "$0")" || exit 1
VENV="${XDG_CACHE_HOME:-$HOME/.cache}/atcsim-venv"
PY="$(command -v python3 || command -v python)"
[ -z "$PY" ] && { echo "Python 3.10+ not found"; exit 1; }
[ -x "$VENV/bin/python" ] || "$PY" -m venv "$VENV" || exit 1
"$VENV/bin/python" -c "import pygame" 2>/dev/null || "$VENV/bin/python" -m pip install -q -r requirements.txt || exit 1
exec "$VENV/bin/python" main.py
