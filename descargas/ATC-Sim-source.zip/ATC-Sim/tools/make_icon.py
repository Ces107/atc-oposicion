"""Draw the app icon (radar ring, sweep, one blip) -> assets/icon.png and assets/icon.ico. Needs pygame and Pillow."""
import math
import os

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import pygame

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")


def draw(n: int = 1024) -> pygame.Surface:
    s = pygame.Surface((n, n), pygame.SRCALPHA)
    c = n // 2
    pygame.draw.circle(s, (9, 16, 14), (c, c), int(n * 0.48))
    pygame.draw.circle(s, (96, 214, 130), (c, c), int(n * 0.48), int(n * 0.03))
    pygame.draw.circle(s, (48, 110, 70), (c, c), int(n * 0.30), int(n * 0.016))
    pygame.draw.circle(s, (48, 110, 70), (c, c), int(n * 0.14), int(n * 0.016))
    w = int(n * 0.016)
    pygame.draw.line(s, (48, 110, 70), (c, int(n * 0.04)), (c, int(n * 0.96)), w)
    pygame.draw.line(s, (48, 110, 70), (int(n * 0.04), c), (int(n * 0.96), c), w)
    a = math.radians(-50)
    tip = (c + math.cos(a) * n * 0.46, c + math.sin(a) * n * 0.46)
    wedge = pygame.Surface((n, n), pygame.SRCALPHA)
    for k in range(1, 9):                     # fading sweep wedge
        b = a + math.radians(-4 * k)
        col = (96, 214, 130, max(10, 120 - k * 14))
        pygame.draw.polygon(wedge, col, [(c, c), (c + math.cos(b) * n * 0.46, c + math.sin(b) * n * 0.46),
                                     (c + math.cos(b + math.radians(4)) * n * 0.46, c + math.sin(b + math.radians(4)) * n * 0.46)])
    s.blit(wedge, (0, 0))
    pygame.draw.line(s, (170, 245, 190), (c, c), tip, int(n * 0.028))
    bx, by = c + int(n * 0.17), c - int(n * 0.16)
    pygame.draw.rect(s, (245, 176, 52), (bx - int(n * 0.035), by - int(n * 0.035), int(n * 0.07), int(n * 0.07)), int(n * 0.02))
    return s


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    big = draw(1024)
    png = pygame.transform.smoothscale(big, (256, 256))
    pygame.image.save(png, os.path.join(OUT, "icon.png"))
    from PIL import Image
    im = Image.open(os.path.join(OUT, "icon.png")).convert("RGBA")
    im.save(os.path.join(OUT, "icon.ico"), sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("icon written")
