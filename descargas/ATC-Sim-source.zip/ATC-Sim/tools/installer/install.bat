@echo off
rem ATC Sim installer: per-user, no admin rights. Copies the app, adds Start Menu and Desktop shortcuts and an Apps entry.
setlocal
set "DEST=%LOCALAPPDATA%\Programs\ATC-Sim"
if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0ATC-Sim.exe" "%DEST%\ATC-Sim.exe" >nul
if errorlevel 1 (
  echo Install failed: could not write to %DEST%
  pause
  exit /b 1
)
copy /y "%~dp0uninstall.bat" "%DEST%\uninstall.bat" >nul
set "PS=$s=New-Object -ComObject WScript.Shell; foreach($p in @(([Environment]::GetFolderPath('Programs')+'\ATC-Sim.lnk'),([Environment]::GetFolderPath('Desktop')+'\ATC-Sim.lnk'))){$l=$s.CreateShortcut($p);$l.TargetPath='%DEST%\ATC-Sim.exe';$l.WorkingDirectory='%DEST%';$l.Description='ATC Sim';$l.Save()}"
powershell -NoProfile -ExecutionPolicy Bypass -Command "%PS%"
set "K=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ATC-Sim"
reg add "%K%" /v DisplayName /d "ATC Sim" /f >nul
reg add "%K%" /v DisplayIcon /d "%DEST%\ATC-Sim.exe" /f >nul
reg add "%K%" /v InstallLocation /d "%DEST%" /f >nul
reg add "%K%" /v UninstallString /d "\"%DEST%\uninstall.bat\"" /f >nul
reg add "%K%" /v NoModify /t REG_DWORD /d 1 /f >nul
reg add "%K%" /v NoRepair /t REG_DWORD /d 1 /f >nul
if /i not "%~1"=="/nolaunch" start "" "%DEST%\ATC-Sim.exe"
exit /b 0
