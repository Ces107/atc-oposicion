@echo off
rem ATC Sim uninstaller. Your results (%LOCALAPPDATA%\ATC-Sim) are kept unless you run: uninstall.bat /purge
setlocal
set "DEST=%LOCALAPPDATA%\Programs\ATC-Sim"
set "PS=foreach($d in 'Programs','Desktop'){Remove-Item ([Environment]::GetFolderPath($d)+'\ATC-Sim.lnk') -ErrorAction SilentlyContinue}"
powershell -NoProfile -ExecutionPolicy Bypass -Command "%PS%"
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\ATC-Sim" /f >nul 2>nul
if /i "%~1"=="/purge" rmdir /s /q "%LOCALAPPDATA%\ATC-Sim" 2>nul
rem a running script cannot delete its own folder: hand over to a detached cmd
start "" /min cmd /c "ping -n 3 127.0.0.1 >nul & rmdir /s /q "%DEST%""
exit /b 0
