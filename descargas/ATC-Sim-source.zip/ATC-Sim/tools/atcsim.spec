# PyInstaller spec: one-file windowed Windows build.   pyinstaller --noconfirm --distpath dist --workpath build tools/atcsim.spec
import os

ROOT = os.path.abspath(os.path.join(SPECPATH, ".."))
VERSION_FILE = os.path.join(ROOT, "build", "version_info.txt")

a = Analysis(
    [os.path.join(ROOT, "main.py")],
    pathex=[ROOT],
    datas=[(os.path.join(ROOT, "assets", "icon.png"), "assets")],
    hiddenimports=[],
    excludes=["tkinter", "numpy", "pytest", "unittest", "pydoc", "test", "email", "http", "xml", "distutils", "setuptools", "pip",
              "pygame.tests", "pygame.docs", "pygame.examples", "pygame._sdl2", "pygame.mixer_music"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="ATC-Sim",
    console=False,
    icon=os.path.join(ROOT, "assets", "icon.ico"),
    version=VERSION_FILE if os.path.exists(VERSION_FILE) else None,
    upx=False,
    runtime_tmpdir=None,
)
