"""Generate the spoken clips of the audio secondary task into assets/voice/ (run once; the clips are committed).

    python tools/make_voice.py            (Windows: uses the built-in SAPI voices through PowerShell System.Speech)
    python tools/make_voice.py --tones    (force the tone fallback, for machines without a voice)

Output: assets/voice/<lang>/<token>.wav (16 kHz, 16-bit mono, silence trimmed, peak-normalised), assets/voice/tone.wav
and assets/voice/voice.json (which engine and voice made each language). Tokens: digits 0-9 and ten ICAO letters.
No network and no extra installs: SAPI ships with Windows. If a language has no installed voice, its clips are
synthesised TONES that encode the token (digit d = d short pips, 0 = one long low tone; letter i = a two-tone motif)
and voice.json says "fallback": true, so the game can say so.
"""
from __future__ import annotations

import argparse
import array
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
import wave

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "assets", "voice")
sys.path.insert(0, ROOT)
from atcsim.core.audio_task import DIGITS, LETTERS  # noqa: E402

RATE = 16000
WORDS = {
    "es": {"culture": "es", "rate": 0,
           "0": "cero", "1": "uno", "2": "dos", "3": "tres", "4": "cuatro", "5": "cinco", "6": "seis", "7": "siete",
           "8": "ocho", "9": "nueve",
           "alfa": "Alfa", "bravo": "Bravo", "delta": "Delta", "eco": "Eco", "kilo": "Kilo", "lima": "Lima",
           "oscar": "Óscar", "sierra": "Sierra", "tango": "Tango", "victor": "Víctor"},
    "en": {"culture": "en", "rate": 0,
           "0": "zero", "1": "one", "2": "two", "3": "three", "4": "four", "5": "five", "6": "six", "7": "seven",
           "8": "eight", "9": "nine",
           "alfa": "Alpha", "bravo": "Bravo", "delta": "Delta", "eco": "Echo", "kilo": "Kilo", "lima": "Lima",
           "oscar": "Oscar", "sierra": "Sierra", "tango": "Tango", "victor": "Victor"},
}
PREFERRED = {"es": ["Helena", "Laura", "Pablo"], "en": ["David", "Zira", "Mark"]}

PS = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$job = Get-Content -Raw -Encoding UTF8 '{job}' | ConvertFrom-Json
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$voices = $s.GetInstalledVoices() | Where-Object {{ $_.Enabled -and $_.VoiceInfo.Culture.Name.StartsWith($job.culture) }}
if (-not $voices) {{ Write-Output 'NOVOICE'; exit 0 }}
$pick = $voices[0].VoiceInfo.Name
foreach ($p in $job.preferred) {{ foreach ($v in $voices) {{ if ($v.VoiceInfo.Name -like "*$p*") {{ $pick = $v.VoiceInfo.Name; break }} }} ; if ($pick -like "*$p*") {{ break }} }}
$s.SelectVoice($pick)
$s.Rate = [int]$job.rate
$fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo({rate}, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
foreach ($it in $job.items) {{
  $s.SetOutputToWaveFile($it.path, $fmt)
  $s.Speak($it.text)
  $s.SetOutputToNull()
}}
Write-Output ('VOICE ' + $pick)
"""


def read_pcm(path: str) -> array.array:
    with wave.open(path, "rb") as w:
        assert w.getsampwidth() == 2 and w.getnchannels() == 1, path
        data = array.array("h")
        data.frombytes(w.readframes(w.getnframes()))
    if sys.byteorder == "big":
        data.byteswap()
    return data


def write_pcm(path: str, data: array.array) -> None:
    out = array.array("h", data)
    if sys.byteorder == "big":
        out.byteswap()
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(out.tobytes())


def trim_normalise(data: array.array, thr: float = 0.01, pad_s: float = 0.03, peak: float = 0.85) -> array.array:
    """Cut leading/trailing silence (below thr x peak), keep pad_s of margin, short fades, normalise to `peak`."""
    if not data:
        return data
    top = max(1, max(abs(v) for v in data))
    lim = thr * top
    first = next(i for i, v in enumerate(data) if abs(v) > lim)
    last = len(data) - next(i for i, v in enumerate(reversed(data)) if abs(v) > lim)
    pad = int(pad_s * RATE)
    seg = data[max(0, first - pad):min(len(data), last + pad)]
    k = peak * 32767.0 / top
    fade = int(0.008 * RATE)
    n = len(seg)
    out = array.array("h", [0] * n)
    for i, v in enumerate(seg):
        g = k
        if i < fade:
            g *= i / fade
        elif i > n - fade:
            g *= (n - i) / fade
        out[i] = max(-32767, min(32767, int(v * g)))
    return out


def tone(freqs, dur_each: float, gap: float = 0.05, amp: float = 0.5) -> array.array:
    out = array.array("h")
    for f in freqs:
        n = int(dur_each * RATE)
        fade = int(0.006 * RATE)
        for i in range(n):
            env = min(1.0, i / fade, (n - i) / fade)
            out.append(int(amp * 32767 * env * math.sin(2 * math.pi * f * i / RATE)))
        out.extend([0] * int(gap * RATE))
    return out


def tone_token(tok: str) -> array.array:
    if tok.isdigit():
        d = int(tok)
        return tone([330.0], 0.32) if d == 0 else tone([880.0] * d, 0.045, gap=0.035)
    i = LETTERS.index(tok)
    return tone([523.0 + 60 * (i % 5), 392.0 + 90 * (i // 5)], 0.12, gap=0.03)


def synth_language(lang: str, tmp: str, force_tones: bool) -> dict:
    spec = WORDS[lang]
    tokens = list(DIGITS) + list(LETTERS)
    raw = {t: os.path.join(tmp, f"{lang}_{t}.wav") for t in tokens}
    voice = None
    if not force_tones and sys.platform == "win32":
        job = {"culture": spec["culture"], "rate": spec["rate"], "preferred": PREFERRED[lang],
               "items": [{"path": raw[t], "text": spec[t]} for t in tokens]}
        jp = os.path.join(tmp, f"job_{lang}.json")
        with open(jp, "w", encoding="utf-8") as f:
            json.dump(job, f, ensure_ascii=False)
        sp = os.path.join(tmp, f"synth_{lang}.ps1")
        with open(sp, "w", encoding="utf-8-sig") as f:
            f.write(PS.format(job=jp, rate=RATE))
        try:
            res = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", sp],
                                 capture_output=True, text=True, timeout=300)
            for ln in res.stdout.splitlines():
                if ln.startswith("VOICE "):
                    voice = ln[6:].strip()
            if voice is None:
                print(lang, "no SAPI voice:", (res.stdout + res.stderr).strip()[:300])
        except (OSError, subprocess.SubprocessError) as e:
            print(lang, "PowerShell failed:", e)
    d = os.path.join(OUT, lang)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    durs = {}
    for t in tokens:
        if voice is not None and os.path.isfile(raw[t]):
            pcm = trim_normalise(read_pcm(raw[t]))
        else:
            pcm = tone_token(t)
        write_pcm(os.path.join(d, f"{t}.wav"), pcm)
        durs[t] = round(len(pcm) / RATE, 3)
    return {"engine": "SAPI" if voice else "tones", "voice": voice or "", "fallback": voice is None, "durations": durs}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tones", action="store_true", help="force the synthesised-tone fallback")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="atcsim_voice_")
    try:
        manifest = {"rate": RATE, "languages": {}}
        for lang in ("es", "en"):
            manifest["languages"][lang] = synth_language(lang, tmp, a.tones)
        write_pcm(os.path.join(OUT, "tone.wav"), tone([660.0, 990.0], 0.09, gap=0.02, amp=0.35))
        with open(os.path.join(OUT, "voice.json"), "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=1, ensure_ascii=False)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    total = sum(os.path.getsize(os.path.join(b, f)) for b, _, fs in os.walk(OUT) for f in fs)
    for lang, m in manifest["languages"].items():
        ds = m["durations"].values()
        print(f"{lang}: {m['engine']} {m['voice']}  clips {len(m['durations'])}  {min(ds):.2f}-{max(ds):.2f} s")
    print(f"assets/voice total {total / 1024:.0f} KB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
