"""Rebuild every downloadable: python tools/build_dist.py   (run from the sim folder; needs pygame-ce, pyinstaller, Pillow)

Writes to dist/:
  ATC-Sim-Setup.exe     Windows installer (IExpress self-extractor wrapping ATC-Sim.exe + install.bat + uninstall.bat)
  ATC-Sim-source.zip    source for macOS / Linux / anyone with Python 3.10+
Options: --skip-exe (only the source zip), --no-setup (skip the IExpress wrapper).
Nothing personal ships: no sim_stats.json, screenshots, caches, review notes or local paths in the zip.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST = os.path.join(ROOT, "dist")
BUILD = os.path.join(ROOT, "build")
sys.path.insert(0, ROOT)
from atcsim import __version__  # noqa: E402

SOURCE_README = """ATC Sim - radar sector simulator (source)

Python 3.10 or newer is required.

Windows        run.bat
macOS, Linux   sh run.sh

Manual:  python -m venv .venv  ->  .venv/bin/pip install -r requirements.txt  ->  .venv/bin/python main.py
Tests:   pip install pytest  ->  python -m pytest tests -q

Results are stored per user (Windows: %LOCALAPPDATA%\\ATC-Sim, macOS: ~/Library/Application Support/ATC-Sim,
Linux: ~/.local/share/ATC-Sim).
"""

RUN_SH = """#!/bin/sh
# ATC Sim launcher for macOS / Linux: private virtual environment in ~/.cache/atcsim-venv
cd "$(dirname "$0")" || exit 1
VENV="${XDG_CACHE_HOME:-$HOME/.cache}/atcsim-venv"
PY="$(command -v python3 || command -v python)"
[ -z "$PY" ] && { echo "Python 3.10+ not found"; exit 1; }
[ -x "$VENV/bin/python" ] || "$PY" -m venv "$VENV" || exit 1
"$VENV/bin/python" -c "import pygame" 2>/dev/null || "$VENV/bin/python" -m pip install -q -r requirements.txt || exit 1
exec "$VENV/bin/python" main.py
"""

SRC_INCLUDE_DIRS = ["atcsim", "assets", "tests", "tools"]
SKIP_DIRS = {"__pycache__", ".pytest_cache", "shots", "dist", "build", ".venv"}
SKIP_FILES = {"sim_stats.json", "atc_profile.json", "crash.log"}
SKIP_EXT = {".pyc", ".pyo", ".csv", ".log"}
# tools that only make sense inside the project (they write screenshots or drive personal stats files)
SKIP_TOOLS = {"screens_tour.py", "tutorial_ui.py", "e2e_sim.py"}


def crlf(data: bytes) -> bytes:
    return data.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")


def write_version_file() -> None:
    os.makedirs(BUILD, exist_ok=True)
    v = tuple(int(x) for x in (__version__.split(".") + ["0", "0", "0"])[:3]) + (0,)
    txt = f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={v}, prodvers={v}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1, subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', ''),
      StringStruct('FileDescription', 'ATC Sim'),
      StringStruct('FileVersion', '{__version__}'),
      StringStruct('InternalName', 'ATC-Sim'),
      StringStruct('OriginalFilename', 'ATC-Sim.exe'),
      StringStruct('ProductName', 'ATC Sim'),
      StringStruct('ProductVersion', '{__version__}')])]),
    VarFileInfo([VarStruct('Translation', [1033, 1200])])
  ]
)
"""
    with open(os.path.join(BUILD, "version_info.txt"), "w", encoding="utf-8") as f:
        f.write(txt)


def build_exe() -> str:
    subprocess.check_call([sys.executable, os.path.join(ROOT, "tools", "make_icon.py")], cwd=ROOT)
    write_version_file()
    subprocess.check_call([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--distpath", os.path.join(BUILD, "pyi"),
                           "--workpath", os.path.join(BUILD, "work"), os.path.join(ROOT, "tools", "atcsim.spec")], cwd=ROOT)
    exe = os.path.join(BUILD, "pyi", "ATC-Sim.exe")
    if not os.path.isfile(exe):
        raise SystemExit("PyInstaller did not produce ATC-Sim.exe")
    return exe


def build_setup(exe: str) -> str:
    stage = os.path.join(BUILD, "setup")
    shutil.rmtree(stage, ignore_errors=True)
    os.makedirs(stage)
    shutil.copy2(exe, os.path.join(stage, "ATC-Sim.exe"))
    for n in ("install.bat", "uninstall.bat"):
        with open(os.path.join(ROOT, "tools", "installer", n), "rb") as f:
            data = crlf(f.read())
        with open(os.path.join(stage, n), "wb") as f:
            f.write(data)
    target = os.path.join(DIST, "ATC-Sim-Setup.exe")
    if os.path.exists(target):
        os.remove(target)
    sed = f"""[Version]
Class=IEXPRESS
SEDVersion=3
[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=0
HideExtractAnimation=1
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=%DisplayLicense%
FinishMessage=%FinishMessage%
TargetName=%TargetName%
FriendlyName=%FriendlyName%
AppLaunched=%AppLaunched%
PostInstallCmd=%PostInstallCmd%
AdminQuietInstCmd=%AdminQuietInstCmd%
UserQuietInstCmd=%UserQuietInstCmd%
SourceFiles=SourceFiles
[Strings]
InstallPrompt=
DisplayLicense=
FinishMessage=
TargetName={target}
FriendlyName=ATC Sim
AppLaunched=cmd /c .\\install.bat
PostInstallCmd=<None>
AdminQuietInstCmd=cmd /c .\\install.bat /nolaunch
UserQuietInstCmd=cmd /c .\\install.bat /nolaunch
FILE0="ATC-Sim.exe"
FILE1="install.bat"
FILE2="uninstall.bat"
[SourceFiles]
SourceFiles0={stage}\\
[SourceFiles0]
%FILE0%=
%FILE1%=
%FILE2%=
"""
    sed_path = os.path.join(BUILD, "setup.sed")
    with open(sed_path, "w", encoding="ascii", newline="\r\n") as f:
        f.write(sed)
    subprocess.check_call([os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "iexpress.exe"), "/N", "/Q", sed_path])
    if not os.path.isfile(target):
        raise SystemExit("IExpress did not produce ATC-Sim-Setup.exe")
    return target


def build_source_zip() -> str:
    target = os.path.join(DIST, "ATC-Sim-source.zip")
    if os.path.exists(target):
        os.remove(target)
    top = "ATC-Sim"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        def add_bytes(name: str, data: bytes) -> None:
            zi = zipfile.ZipInfo(f"{top}/{name}", date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o755 if name.endswith(".sh") else 0o644) << 16
            z.writestr(zi, data)

        def add_file(rel: str) -> None:
            with open(os.path.join(ROOT, rel), "rb") as f:
                data = f.read()
            if rel.endswith((".bat", ".cmd")):
                data = crlf(data)
            add_bytes(rel.replace(os.sep, "/"), data)

        for name in ("main.py", "requirements.txt", "run.bat"):
            add_file(name)
        add_bytes("run.sh", RUN_SH.encode("utf-8"))
        add_bytes("README.txt", crlf(SOURCE_README.encode("utf-8")))
        for d in SRC_INCLUDE_DIRS:
            for base, dirs, files in os.walk(os.path.join(ROOT, d)):
                dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
                for fn in sorted(files):
                    rel = os.path.relpath(os.path.join(base, fn), ROOT)
                    if fn in SKIP_FILES or os.path.splitext(fn)[1] in SKIP_EXT:
                        continue
                    if d == "tools" and (fn in SKIP_TOOLS):
                        continue
                    add_file(rel)
    return target


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-exe", action="store_true")
    ap.add_argument("--no-setup", action="store_true")
    ap.add_argument("--reuse-exe", action="store_true", help="skip PyInstaller, reuse build/pyi/ATC-Sim.exe")
    a = ap.parse_args()
    os.makedirs(DIST, exist_ok=True)
    out = []
    if not a.skip_exe:
        if sys.platform != "win32":
            raise SystemExit("The Windows build must run on Windows (use --skip-exe for the source zip).")
        exe = os.path.join(BUILD, "pyi", "ATC-Sim.exe") if a.reuse_exe else build_exe()
        if a.no_setup:
            shutil.copy2(exe, os.path.join(DIST, "ATC-Sim.exe"))
            out.append(os.path.join(DIST, "ATC-Sim.exe"))
        else:
            out.append(build_setup(exe))
    out.append(build_source_zip())
    for p in out:
        print(f"{os.path.basename(p):24s} {os.path.getsize(p) / 1e6:6.1f} MB")


if __name__ == "__main__":
    main()
