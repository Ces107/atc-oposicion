"""Drive the real pygame UI headless with synthetic keyboard and mouse events.

`UIBot` is the core Bot, but every action is performed by posting key presses and mouse clicks, so the whole input
path (selection, arrows, typed values, right-click headings, task keys and buttons, transfer) is exercised.
"""
from __future__ import annotations

import os
import random
import sys
import tempfile
import time

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pygame  # noqa: E402

from atcsim.bot import Bot  # noqa: E402
from atcsim.core.geometry import angle_diff  # noqa: E402
from atcsim.core.tasks import KEYS  # noqa: E402
from atcsim.ui.app import App, GameScreen  # noqa: E402
from atcsim.ui.screens import BriefingScreen, DebriefScreen, MenuScreen  # noqa: E402

KEYCODES = {"y": pygame.K_y, "n": pygame.K_n, "a": pygame.K_a, "d": pygame.K_d, "space": pygame.K_SPACE,
            "1": pygame.K_1, "2": pygame.K_2, "3": pygame.K_3, "4": pygame.K_4, "5": pygame.K_5, "6": pygame.K_6}


def key(app: App, k: int, uni: str = "", mod: int = 0) -> None:
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k, mod=mod, unicode=uni))
    app.frame(0.0, draw=False)


def click(app: App, pos, button: int = 1) -> None:
    pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=pos, button=button))
    app.frame(0.0, draw=False)


class UIBot(Bot):
    def __init__(self, app: App, world, **kw):
        super().__init__(world, **kw)
        self.app = app
        self.ui_rng = random.Random(kw.get("seed", 0) + 99)
        self.miss = 0
        self.method_count = {"type": 0, "arrows": 0, "rclick": 0, "click_btn": 0, "key_btn": 0}

    @property
    def session(self):
        return self.app.screen.s

    def _redraw(self) -> None:
        self.session.draw(self.app.surface)

    def _select(self, cs: str) -> bool:
        s = self.session
        if s.world.selected == cs:
            return True
        self._redraw()
        a = self.w.aircraft.get(cs)
        if a is None:
            return False
        pos = s.scope.to_screen(a.x, a.y)
        click(self.app, pos, 1)
        if self.w.selected != cs:
            self.miss += 1
            s.select(cs)   # overlapping symbols: fall back to the strip / Tab equivalent
        return self.w.selected == cs

    def issue(self, cs, hdg=None, alt=None, spd=None, turn=None, resume=False, dct=None) -> bool:
        w = self.w
        if cs not in w.aircraft or not self._select(cs):
            return False
        before = len(w.clearances)
        s = self.session
        if resume:
            key(self.app, pygame.K_r)
        elif dct:
            self._redraw()
            fx = w.sector.fixes[dct]
            old = pygame.key.get_mods
            pygame.key.get_mods = lambda: pygame.KMOD_SHIFT       # Shift+click = direct-to
            try:
                click(self.app, s.scope.to_screen(*fx), 1)
            finally:
                pygame.key.get_mods = old
        else:
            if alt is not None:
                delta = round((alt - w.aircraft[cs].tgt_alt) / 1000.0)
                for _ in range(abs(delta)):
                    key(self.app, pygame.K_UP if delta > 0 else pygame.K_DOWN)
            if spd is not None:
                delta = round((spd - w.aircraft[cs].tgt_tas) / 10.0)
                for _ in range(abs(delta)):
                    key(self.app, pygame.K_PLUS if delta > 0 else pygame.K_MINUS)
            if hdg is not None:
                ac = w.aircraft[cs]
                base = ac.tgt_hdg if (not ac.nav and ac.tgt_hdg is not None) else ac.hdg
                method = self.ui_rng.choice(["type", "type", "arrows", "arrows", "rclick"])   # turns <= 60 deg: shortest = forced side
                self.method_count[method] += 1
                if method == "arrows":
                    delta = angle_diff(hdg, base)
                    n = int(round(delta / 5.0))
                    for _ in range(abs(n)):
                        key(self.app, pygame.K_RIGHT if n > 0 else pygame.K_LEFT)
                    if n == 0:
                        key(self.app, pygame.K_RIGHT)
                elif method == "rclick":
                    self._redraw()
                    from atcsim.core.geometry import vec_from_hdg
                    vx, vy = vec_from_hdg(hdg, 20.0)
                    click(self.app, s.scope.to_screen(ac.x + vx, ac.y + vy), 3)
                else:
                    key(self.app, pygame.K_h, "h")
                    txt = f"{int(round(hdg)) % 360 or 360}"
                    for ch in txt:
                        key(self.app, pygame.K_0 + int(ch), ch)
            key(self.app, pygame.K_RETURN)
            if s.typing is not None:
                key(self.app, pygame.K_ESCAPE)
        return len(w.clearances) > before

    def transfer(self, cs: str) -> None:
        if cs in self.w.aircraft and self._select(cs):
            key(self.app, pygame.K_t)

    def answer(self, task, choice: int) -> None:
        s = self.session
        if self.ui_rng.random() < 0.25:
            self._redraw()
            for r, action in s.hits:
                if action[0] == "answer" and action[1] == task.id and action[2] == choice:
                    click(self.app, r.center, 1)
                    self.method_count["click_btn"] += 1
                    return
        k = KEYS[task.kind][choice]
        key(self.app, KEYCODES[k], k if k != "space" else " ")
        self.method_count["key_btn"] += 1

    def audio_sum(self, value: int) -> None:
        s = self.session
        if s.typing is not None:
            key(self.app, pygame.K_ESCAPE)
        key(self.app, pygame.K_v, "v")
        for ch in str(int(value)):
            key(self.app, pygame.K_0 + int(ch), ch)
        key(self.app, pygame.K_RETURN)
        self.method_count["audio"] = self.method_count.get("audio", 0) + 1

    def audio_match(self) -> None:
        key(self.app, pygame.K_m, "m")
        self.method_count["audio"] = self.method_count.get("audio", 0) + 1


def new_app(stats_dir=None) -> App:
    d = stats_dir or tempfile.mkdtemp()
    return App(headless=True, stats_path=os.path.join(d, "sim_stats.json"))


def start_ladder(app: App, level: int, seed: int = 1234) -> None:
    """Menu -> Ladder row -> chosen level -> briefing -> Enter -> generated run, all with key presses."""
    assert isinstance(app.screen, MenuScreen)
    key(app, pygame.K_DOWN)
    key(app, pygame.K_DOWN)          # Ladder row (index 2)
    app.screen.level = 1
    for _ in range(level - 1):
        key(app, pygame.K_RIGHT)
    assert app.screen.level == level
    app.stats.data["next_seed"] = seed
    key(app, pygame.K_RETURN)
    assert isinstance(app.screen, BriefingScreen)
    key(app, pygame.K_RETURN)
    app.frame(0.016)                 # draws "Preparing traffic..."
    app.frame(0.016)                 # generates the run
    assert isinstance(app.screen, GameScreen), type(app.screen)


def play(app: App, bot_kwargs=None, dt: float = 0.1, draw_every: int = 12, act_every: int = 5,
         max_frames: int = 200000, shots=None, use_bot: bool = True):
    """Play the current GameScreen to the end. Returns (frames, wall_seconds, max_frame_ms)."""
    scr = app.screen
    assert isinstance(scr, GameScreen)
    bot = UIBot(app, scr.s.world, **(bot_kwargs or {})) if use_bot else None
    t0 = time.time()
    worst = 0.0
    n = 0
    shots = dict(shots or {})
    while isinstance(app.screen, GameScreen) and n < max_frames:
        f0 = time.perf_counter()
        app.frame(dt, draw=(n % draw_every == 0))
        worst = max(worst, time.perf_counter() - f0)
        if bot is not None and n % act_every == 0 and isinstance(app.screen, GameScreen):
            bot.act()
        n += 1
        for at, path in list(shots.items()):
            if isinstance(app.screen, GameScreen) and app.screen.s.world.t >= at:
                app.screen.draw(app.surface)
                pygame.image.save(app.surface, path)
                del shots[at]
    return n, time.time() - t0, worst * 1000.0, bot
