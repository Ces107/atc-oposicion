"""Strip planner calibration: scripted sessions through the real UI (headless) and a core table for every level.

python tools/calibrate_planner.py                 three UI sessions (levels 2, 5, 8), each played twice on the same seed:
                                                  perfect bot (must score 100) and a capacity-limited bot
python tools/calibrate_planner.py --levels 1,4,7 --seeds 3 --core   adds the core table (no pygame) for every level

Nothing is saved outside a temporary folder. The limited bot examines `--scan` strip pairs per real second and
overlooks an examined conflict with probability 0.05: a stand-in for a human's reading speed, not a measurement.
"""
from __future__ import annotations

import argparse
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from play_ui import key, new_app, play_planner, start_planner_ui  # noqa: E402
import pygame  # noqa: E402

from atcsim.core.planner import PLANNER_LEVELS, planner_spec  # noqa: E402
from atcsim.planner_bot import run_core  # noqa: E402


def load(level: int) -> dict:
    sp = planner_spec(level)
    real_min = (sp.window_min + 18) * sp.rs_per_min / 60.0
    return {"flights": sp.n_flights, "conflicts": sp.conflicts, "errors": sp.coord_errors, "real_min": real_min,
            "conf_per_min": sp.conflicts / real_min, "strips_per_min": sp.n_flights / real_min,
            "lead_s": sp.lead_min * sp.rs_per_min}


def ui_session(level: int, seed: int, perfect: bool, scan: float) -> dict:
    app = new_app(tempfile.mkdtemp())
    app.stats.settings()["audio"] = "auto"
    start_planner_ui(app, level, seed=seed)
    kw = dict(seed=seed) if perfect else dict(seed=seed, perfect=False, scan_per_s=scan, p_slip=0.05, audio_p=0.9)
    n, wall, worst, bot = play_planner(app, kw)
    r = app.screen.r
    out = {"score": r.score, "acc": round(r.accuracy, 1), "lost": r.lost, "found": f"{r.found}/{r.conflicts}",
           "coord": f"{r.coord_flagged}/{r.coord_errors}", "s_dec": r.s_per_decision, "cost": f"{r.cost_units:g}/{r.ref_cost:g}",
           "audio": (r.audio or {}).get("accuracy"), "mismatch": bot.mismatch, "keys": bot.keys,
           "frame_ms": round(worst, 1), "saved": len(app.stats.data["planner_runs"])}
    key(app, pygame.K_ESCAPE)
    pygame.display.quit()
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--levels", default="2,5,8")
    ap.add_argument("--seed", type=int, default=6100)
    ap.add_argument("--scan", type=float, default=0.5)
    ap.add_argument("--core", action="store_true")
    ap.add_argument("--seeds", type=int, default=4)
    a = ap.parse_args()
    bad = 0
    print("UI sessions (real key and mouse events, headless)")
    for lv in (int(x) for x in a.levels.split(",")):
        ld = load(lv)
        p = ui_session(lv, a.seed + lv, True, a.scan)
        q = ui_session(lv, a.seed + lv, False, a.scan)
        print(f"L{lv}: {ld['flights']} strips, {ld['conflicts']} conflicts, {ld['errors']} strip errors, {ld['real_min']:.1f} real min, "
              f"{ld['conf_per_min']:.2f} conflicts/min, {ld['strips_per_min']:.1f} strips/min, strip on board {ld['lead_s']:.0f} s before entry")
        print(f"     perfect : {p}")
        print(f"     limited : {q}")
        if p["score"] != 100.0 or p["mismatch"]:
            bad += 1
    if a.core:
        print("\nCore table (perfect / limited accuracy, mean of %d seeds)" % a.seeds)
        for sp in PLANNER_LEVELS:
            perf = [run_core(sp.level, 9000 + s)[1].score for s in range(a.seeds)]
            lim = [run_core(sp.level, 9000 + s, perfect=False, scan_per_s=a.scan, p_slip=0.05, bot_seed=s)[1].accuracy
                   for s in range(a.seeds)]
            print(f"L{sp.level:>2}  perfect score {sum(perf) / len(perf):5.1f}   limited accuracy {sum(lim) / len(lim):5.1f}")
    print("RESULT:", "perfect bot full marks everywhere" if not bad else f"{bad} session(s) below full marks")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
