"""Difficulty calibration table: idle player, sloppy bot and good bot on several seeds per level (core only, fast).

Usage: python tools/calibrate.py [seeds]
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atcsim.bot import Bot
from atcsim.core.generator import generate
from atcsim.core.scenario import level_spec
from atcsim.core.scoring import compute_result
from atcsim.core.world import World


def run(seed, level, mk):
    w = World(generate(seed, level))
    bot = mk(w)
    peak = 0
    while not w.finished and w.real_t < 4000:
        w.advance(0.5)
        peak = max(peak, len(w.aircraft))
        if bot is not None:
            bot.act()
    return compute_result(w), peak, w


def main(n_seeds=3):
    profiles = {
        "idle": lambda w: None,
        "sloppy": lambda w: Bot(w, 7, p_correct=0.8, p_skip=0.15, reaction_s=3.0, lead_s=100.0),
        "good": lambda w: Bot(w, 7, p_correct=0.97, p_skip=0.02, reaction_s=1.5, lead_s=200.0),
    }
    print(f"{'lvl':>3} {'name':<12}{'ac':>4}{'peak':>5}{'null':>5} | " + " | ".join(f"{p:^22}" for p in profiles))
    print(f"{'':>3} {'':<12}{'':>4}{'':>5}{'loss':>5} | " + " | ".join(f"{'score acc% loss met':^22}" for _ in profiles))
    for lv in range(1, 11):
        rows = {p: [] for p in profiles}
        peaks, nulls = [], []
        for seed in range(100, 100 + n_seeds):
            for p, mk in profiles.items():
                r, peak, w = run(seed, lv, mk)
                rows[p].append(r)
                if p == "idle":
                    peaks.append(peak)
                    nulls.append(w.scenario.null_losses)
        out = []
        for p in profiles:
            rs = rows[p]
            n = len(rs)
            out.append(f"{sum(r.score for r in rs) / n:5.0f} {sum(r.accuracy for r in rs) / n:5.0f} {sum(r.losses for r in rs) / n:4.1f} {sum(1 for r in rs if r.met)}/{n}")
        sp = level_spec(lv)
        print(f"{lv:>3} {sp.name:<12}{sp.n_aircraft:>4}{max(peaks):>5}{sum(nulls) / len(nulls):>5.1f} | " + " | ".join(f"{o:^22}" for o in out))


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 3)
