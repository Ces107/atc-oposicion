"""Frame-time profile of the real UI at level 10 (the heaviest load), drawing every frame at dt = 1/60 s.

The bot's own thinking time is excluded from the measurement: only App.frame() (events, update, draw) is timed.
Usage: python tools/profile_l10.py [level] [seconds_of_game] [--profile] [--real]
"""
import cProfile
import io
import os
import pstats
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from play_ui import *  # noqa: F401,F403


def main(level=10, game_seconds=240.0, profile=False, real=False):
    if real:      # real window (needs a display): includes the true cost of display.flip() and the 60 FPS clock
        import tempfile
        os.environ.pop("SDL_VIDEODRIVER", None)
        pygame.quit()
        app = App(headless=False, stats_path=os.path.join(tempfile.mkdtemp(), "s.json"))
    else:
        app = new_app()
    start_ladder(app, level, seed=4242)
    scr = app.screen
    bot = UIBot(app, scr.s.world, seed=3, p_correct=0.9, p_skip=0.05)
    dt = 1.0 / 60.0
    times = []
    n = 0
    pr = cProfile.Profile() if profile else None
    while isinstance(app.screen, GameScreen) and app.screen.s.world.real_t < game_seconds:
        if real:
            app.clock.tick(60)
        t0 = time.perf_counter()
        if pr:
            pr.enable()
        app.frame(dt, draw=True)
        if pr:
            pr.disable()
        times.append((time.perf_counter() - t0) * 1000.0)
        if n % 6 == 0 and isinstance(app.screen, GameScreen):
            bot.act()
        n += 1
    times.sort()
    k = len(times)
    w = scr.s.world
    print(f"level {level}: {k} frames, game time {w.real_t:.0f} s real / {w.t:.0f} s sim, max aircraft in sector during run ~{len(w.aircraft)}")
    print(f"frame ms: mean {sum(times) / k:.2f}  median {times[k // 2]:.2f}  p95 {times[int(k * .95)]:.2f}  p99 {times[int(k * .99)]:.2f}  max {times[-1]:.2f}")
    over = sum(1 for t in times if t > 16.7)
    print(f"frames over 16.7 ms (60 FPS budget): {over} ({100.0 * over / k:.1f}%)")
    if pr:
        s = io.StringIO()
        pstats.Stats(pr, stream=s).sort_stats("cumulative").print_stats(18)
        print(s.getvalue())
    return times


if __name__ == "__main__":
    lvl = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    secs = float(sys.argv[2]) if len(sys.argv) > 2 else 240.0
    main(lvl, secs, profile="--profile" in sys.argv, real="--real" in sys.argv)
