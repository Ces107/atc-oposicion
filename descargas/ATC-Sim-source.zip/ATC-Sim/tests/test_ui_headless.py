"""Headless tests of the real pygame UI (SDL dummy driver) driven by synthetic key and mouse events."""
import os
import random
import sys

import pytest

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))

import pygame  # noqa: E402

from play_ui import (GameScreen, DebriefScreen, MenuScreen, BriefingScreen, UIBot, click, key, new_app, play,  # noqa: E402
                     start_ladder)
from tutorial_ui import run_tutorial  # noqa: E402
from atcsim.core.persistence import StatsStore  # noqa: E402
from atcsim.ui.screens import HelpScreen, ReplayScreen, StatsScreen  # noqa: E402


def test_tutorial_can_be_completed_with_real_inputs():
    app = run_tutorial(None, verbose=False)
    assert isinstance(app.screen, MenuScreen)


@pytest.mark.parametrize("level,seed", [(1, 11), (3, 12), (5, 13), (8, 14), (10, 15)])
def test_full_bot_run_through_the_ui(level, seed, tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, level, seed)
    n, wall, worst, bot = play(app, dict(seed=level, p_correct=0.95, p_skip=0.03), dt=0.1, draw_every=15)
    assert isinstance(app.screen, DebriefScreen)
    r = app.screen.r
    assert r.items == r.correct + r.wrong + r.blank > 0
    assert 0.0 <= r.accuracy <= 100.0 and 0.0 <= r.score <= 100.0
    assert r.level == level and r.seed == seed
    assert r.thirds and len(r.thirds) == 3
    assert bot.miss <= 3                                # mouse selection nearly always hits the right symbol
    assert sum(bot.method_count.values()) > 0
    # persisted and consistent with the CSV
    st = StatsStore(str(tmp_path / "sim_stats.json"))
    assert len(st.data["runs"]) == 1
    rec = st.data["runs"][0]
    assert (rec["correct"], rec["wrong"], rec["blank"]) == (r.correct, r.wrong, r.blank)
    p = app.export_csv()
    assert p and os.path.exists(p)
    os.remove(p)
    # every debrief tab renders without error
    for k in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
        key(app, k)
        app.screen.draw(app.surface)
    if level <= 3:
        assert r.score >= 50                            # a competent controller does not fail the easy levels


def test_idle_player_fails_and_debrief_explains_losses(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 4, 21)
    n, wall, worst, bot = play(app, use_bot=False, dt=0.2, draw_every=25)
    d = app.screen
    assert isinstance(d, DebriefScreen)
    assert d.r.losses >= 2 and not d.r.met and d.r.score < 70
    assert len(d.losses) == d.r.losses
    for i in range(len(d.losses)):
        rep = d.report(i)
        assert rep["lines"] and rep["verdict"] in ("no action", "not seen")
        assert any("any instruction" in ln or "never predicted" in ln for ln in rep["lines"])
    assert d.decisions                                  # blanks: tasks were never answered
    # replay of a loss
    key(app, pygame.K_2)
    key(app, pygame.K_RETURN)
    assert isinstance(app.screen, ReplayScreen)
    for _ in range(40):
        app.frame(0.25)
    key(app, pygame.K_SPACE)
    key(app, pygame.K_LEFT)
    key(app, pygame.K_r)
    key(app, pygame.K_PLUS)
    key(app, pygame.K_ESCAPE)
    assert isinstance(app.screen, DebriefScreen)


def test_pause_freezes_the_simulation_and_abort_saves_nothing(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 2, 31)
    s = app.screen.s
    for _ in range(30):
        app.frame(0.1)
    key(app, pygame.K_p)
    assert s.paused and s.world.pauses == 1
    t0, r0 = s.world.t, s.world.real_t
    for _ in range(50):
        app.frame(0.1)
    assert s.world.t == t0 and s.world.real_t == r0        # no timers leak while paused
    key(app, pygame.K_p)
    assert not s.paused
    for _ in range(10):
        app.frame(0.1)
    assert s.world.t > t0
    key(app, pygame.K_ESCAPE)                              # nothing selected: opens the pause menu
    assert s.paused and s.pause_menu
    key(app, pygame.K_q)
    app.frame(0.1)
    assert isinstance(app.screen, MenuScreen)
    assert StatsStore(str(tmp_path / "sim_stats.json")).data["runs"] == []


def test_adaptive_state_moves_after_a_run(tmp_path):
    app = new_app(str(tmp_path))
    key(app, pygame.K_DOWN)                                # Adaptive row
    key(app, pygame.K_RETURN)
    assert isinstance(app.screen, BriefingScreen) and app.screen.mode == "Adaptive"
    key(app, pygame.K_RETURN)
    app.frame(0.02)
    app.frame(0.02)
    n, wall, worst, bot = play(app, dict(seed=5), dt=0.1, draw_every=30)
    r = app.screen.r
    ad = app.stats.data["adaptive"]
    if r.met:
        assert ad == {"level": 1, "ok": 1, "bad": 0}
    else:
        assert ad == {"level": 1, "ok": 0, "bad": 1}
    assert app.stats.data["runs"][0]["mode"] == "Adaptive"


def test_stats_help_menu_screens_render_and_export(tmp_path):
    app = new_app(str(tmp_path))
    app.frame(0.02)
    key(app, pygame.K_F1)
    assert isinstance(app.screen, HelpScreen)
    for _ in range(3):
        key(app, pygame.K_DOWN)
        app.frame(0.02)
    key(app, pygame.K_ESCAPE)
    assert isinstance(app.screen, MenuScreen)
    key(app, pygame.K_DOWN); key(app, pygame.K_DOWN); key(app, pygame.K_DOWN)
    key(app, pygame.K_RETURN)
    assert isinstance(app.screen, StatsScreen)
    key(app, pygame.K_e)
    path = app.screen.msg
    assert path.endswith(".csv") and os.path.exists(path)
    text = open(path, "rb").read().decode("utf-8-sig")
    assert text.split("\r\n")[0] == "Date;Module;Level;Correct;Wrong;Blank;Seconds per item;Accuracy %;Goal;Met"
    os.remove(path)
    key(app, pygame.K_ESCAPE)
    assert isinstance(app.screen, MenuScreen)


def test_random_input_fuzz_never_crashes(tmp_path):
    """Random keys, clicks and wheel events on every screen, for thousands of frames."""
    rng = random.Random(1234)
    keys = [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_RETURN, pygame.K_ESCAPE, pygame.K_SPACE,
            pygame.K_TAB, pygame.K_p, pygame.K_r, pygame.K_t, pygame.K_h, pygame.K_f, pygame.K_s, pygame.K_y, pygame.K_n,
            pygame.K_a, pygame.K_d, pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_0,
            pygame.K_PLUS, pygame.K_MINUS, pygame.K_BACKSPACE, pygame.K_PAGEDOWN, pygame.K_PAGEUP, pygame.K_e, pygame.K_n,
            pygame.K_q, pygame.K_F1]
    app = new_app(str(tmp_path))
    seen = set()
    for i in range(6000):
        r = rng.random()
        if r < 0.55:
            k = rng.choice(keys)
            uni = chr(k) if 32 <= k < 127 else ""
            mod = rng.choice([0, 0, pygame.KMOD_SHIFT, pygame.KMOD_CTRL])
            pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k, mod=mod, unicode=uni))
        elif r < 0.8:
            pygame.event.post(pygame.event.Event(pygame.MOUSEBUTTONDOWN, pos=(rng.randrange(0, 1440), rng.randrange(0, 810)),
                                                 button=rng.choice([1, 1, 3])))
        elif r < 0.85:
            pygame.event.post(pygame.event.Event(pygame.MOUSEWHEEL, x=0, y=rng.choice([-2, -1, 1, 2]), flipped=False))
        app.frame(rng.choice([0.0, 0.016, 0.1, 0.5]), draw=(i % 3 == 0))
        seen.add(type(app.screen).__name__)
        if app.quit:
            app.quit = False
    assert {"MenuScreen"} <= seen
    assert len(seen) >= 3          # the fuzz reached several different screens


def test_typed_entry_and_direct_to_and_right_click(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 1, 41)
    s = app.screen.s
    w = s.world
    for _ in range(200):
        app.frame(0.1)
        if w.aircraft:
            break
    assert w.aircraft and w.t < 60              # traffic appears within seconds
    cs = sorted(w.aircraft)[0]
    a = w.aircraft[cs]
    s.draw(app.surface)
    click(app, s.scope.to_screen(a.x, a.y))
    assert w.selected == cs
    # typed heading 090
    key(app, pygame.K_h, "h")
    for ch in "090":
        key(app, pygame.K_0 + int(ch), ch)
    assert s.typing == ("h", "090")
    key(app, pygame.K_RETURN)
    assert s.typing is None and w.clearances[-1].hdg == 90.0
    # typed nonsense heading is rejected with a visible message
    key(app, pygame.K_h, "h")
    for ch in "999":
        key(app, pygame.K_0 + int(ch), ch)
    key(app, pygame.K_RETURN)
    assert "Heading 0-360" in s.flash
    # right-click sets a proposal towards the cursor
    s.draw(app.surface)
    click(app, s.scope.to_screen(a.x, a.y + 20), 3)      # due north of the aircraft
    assert s.proposal is not None and s.proposal["hdg"] == 0.0
    # Esc cancels the proposal, second Esc deselects
    key(app, pygame.K_ESCAPE)
    assert s.proposal is None
    key(app, pygame.K_ESCAPE)
    assert w.selected is None


def test_task_buttons_can_be_clicked(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 2, 51)
    s = app.screen.s
    w = s.world
    for _ in range(4000):
        app.frame(0.1, draw=False)
        if w.tasks.tasks and any(t.kind != "memshow" for t in w.tasks.tasks):
            break
    assert w.tasks.tasks
    s.draw(app.surface)
    target = next(t for t in w.tasks.tasks if t.kind != "memshow")
    rect = next(r for r, act in s.hits if act[0] == "answer" and act[1] == target.id and act[2] == target.correct)
    click(app, rect.center)
    assert target.outcome == "correct"
    assert target not in w.tasks.tasks


def test_plain_click_near_a_fix_never_sends_but_shift_click_does(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 1, 61)
    s = app.screen.s
    w = s.world
    for _ in range(300):
        app.frame(0.1)
        if w.aircraft:
            break
    cs = sorted(w.aircraft)[0]
    a = w.aircraft[cs]
    s.draw(app.surface)
    click(app, s.scope.to_screen(a.x, a.y))
    assert w.selected == cs
    fix = a.route[-1][0]
    n0 = len(w.clearances)
    s.draw(app.surface)
    click(app, s.scope.to_screen(*w.sector.fixes[fix]))          # plain click
    assert len(w.clearances) == n0 and "Shift" in s.flash
    old = pygame.key.get_mods
    pygame.key.get_mods = lambda: pygame.KMOD_SHIFT
    try:
        click(app, s.scope.to_screen(*w.sector.fixes[fix]))
    finally:
        pygame.key.get_mods = old
    assert len(w.clearances) == n0 + 1 and w.clearances[-1].dct == fix


def test_menu_mouse_navigation(tmp_path):
    app = new_app(str(tmp_path))
    app.frame(0.02)
    m = app.screen
    ladder = m.rects[2]
    click(app, (ladder.right - 20, ladder.centery))          # right edge raises the level without starting
    click(app, (ladder.right - 20, ladder.centery))
    assert isinstance(app.screen, MenuScreen) and app.screen.level == 3
    click(app, (ladder.x + 20, ladder.centery))              # left edge lowers it
    assert app.screen.level == 2
    click(app, (ladder.centerx, ladder.centery))             # middle starts the briefing
    assert isinstance(app.screen, BriefingScreen) and app.screen.level == 2 and app.screen.mode == "Ladder"
    click(app, (700, 400))                                   # a click on the briefing starts the run
    app.frame(0.02)
    app.frame(0.02)
    assert isinstance(app.screen, GameScreen)
    assert app.stats.data["next_seed"] == 1001               # the seed counter advanced exactly once


def test_focus_loss_pauses_quietly_without_counting_as_assistance(tmp_path):
    app = new_app(str(tmp_path))
    start_ladder(app, 6, 71)
    s = app.screen.s
    for _ in range(20):
        app.frame(0.1)
    pygame.event.post(pygame.event.Event(pygame.WINDOWFOCUSLOST))
    app.frame(0.1)
    assert s.paused and s.auto_paused and s.world.pauses == 0
    t0 = s.world.t
    for _ in range(30):
        app.frame(0.1)
    assert s.world.t == t0
    key(app, pygame.K_p)
    assert not s.paused and s.world.pauses == 0              # no 'assisted' mark at level 6
    for _ in range(10):
        app.frame(0.1)
    assert s.world.t > t0
