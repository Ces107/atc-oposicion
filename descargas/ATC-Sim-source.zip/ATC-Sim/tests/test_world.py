import pytest

from atcsim.core.geometry import dist
from atcsim.core.world import EXIT_GATE_TOL, EXIT_LEVEL_TOL, World
from conftest import scenario, spec, world

WEST_EAST = ["LUNDA", "VELAR", "MIDAS", "REGAL", "NERVA"]


def head_on(alt_b=30000.0, delay=0.0, **kw):
    # two aircraft on the same airway in opposite directions (R2 forward and reverse)
    a = spec("AAA1", ["LUNDA", "VELAR", "MIDAS", "REGAL", "NERVA"], alt=30000, tas=300)
    b = spec("BBB2", ["NERVA", "REGAL", "MIDAS", "VELAR", "LUNDA"], alt=alt_b, tas=300)
    return world([a, b], pilot_delay=delay, **kw)


def test_head_on_loses_separation_and_records_minimum():
    w = head_on()
    while not w.finished:
        w.advance(1.0)
    assert len(w.losses) == 1
    ep = w.losses[0]
    assert ep.pair == ("AAA1", "BBB2")
    assert ep.min_h < 1.0                       # they fly through each other
    assert ep.end_t is not None and ep.end_t > ep.start_t


def test_vertical_separation_prevents_loss():
    w = head_on(alt_b=31000.0)                  # exactly 1000 ft apart: not a loss (strict < 1000)
    while not w.finished:
        w.advance(1.0)
    assert w.losses == []
    w2 = head_on(alt_b=30999.0)
    while not w2.finished:
        w2.advance(1.0)
    assert len(w2.losses) == 1


def test_prediction_warns_before_loss_and_records_lead():
    w = head_on()
    for _ in range(300):        # closing at 10 NM/min over ~119 NM: loss begins at ~654 s, so the 300 s horizon sees it from ~354 s
        w.advance(1.0)
    assert not w.predicted
    for _ in range(100):
        w.advance(1.0)
    assert w.predicted, "head-on pair should be predicted well before it happens"
    c = w.predicted[0]
    assert 0 < c.t_start < 300
    rec = w.records[("AAA1", "BBB2")]
    assert rec["first_t"] is not None and rec["first_lead"] > 0


def test_pilot_delay_uses_real_time_and_applies_once():
    w = head_on(delay=2.0)
    for _ in range(10):
        w.advance(1.0)
    ok, msg, cl = w.issue("AAA1", hdg=45)
    assert ok and cl is not None and not cl.applied
    old = w.aircraft["AAA1"].tgt_hdg
    w.advance(0.5)
    assert not cl.applied
    w.advance(3.0)
    assert cl.applied and w.aircraft["AAA1"].tgt_hdg == 45
    assert old != 45
    assert w.pending == []


def test_scale_makes_sim_time_faster_than_real():
    w = world([spec("A", WEST_EAST)], scale=4.0)
    w.advance(10.0)
    assert w.t == pytest.approx(40.0, abs=1.0)
    assert w.real_t == pytest.approx(10.0)


def test_issue_validation():
    w = head_on()
    for _ in range(5):
        w.advance(1.0)
    ok, msg, _ = w.issue("ZZZ", hdg=10)
    assert not ok and "not in the sector" in msg
    ok, msg, _ = w.issue("AAA1", alt=60000)
    assert not ok and "unable" in msg
    ok, msg, _ = w.issue("AAA1", spd=900)
    assert not ok and "unable" in msg
    ok, msg, _ = w.issue("AAA1", dct="NOPE")
    assert not ok
    ok, msg, _ = w.issue("AAA1")
    assert not ok
    ok, msg, cl = w.issue("AAA1", hdg=360)
    assert ok and "360" in msg
    ok, msg, cl = w.issue("AAA1", hdg=0, turn_dir="L")
    assert ok and "left heading 360" in msg


def test_heading_change_resolves_the_conflict():
    w = head_on()
    for _ in range(30):
        w.advance(1.0)
    ok, _, _ = w.issue("AAA1", hdg=w.aircraft["AAA1"].hdg + 30, turn_dir="R")
    assert ok
    while not w.finished:
        w.advance(1.0)
    assert w.losses == []


def exit_world(exit_alt=30000.0, alt=30000.0, route=("MOREA", "CANTO", "MIDAS", "ORISA")):
    return world([spec("EXT1", list(route), alt=alt, exit_alt=exit_alt, tas=400)], tasks=False)


def test_handoff_correct_gate_and_level():
    w = exit_world()
    while not w.finished:
        w.advance(1.0)
    assert len(w.handoffs) == 1
    h = w.handoffs[0]
    assert h["gate_ok"] and h["level_ok"] and h["outcome"] == "correct"
    assert h["gate_dist"] < 1.0


def test_handoff_level_tolerance_exact_boundary():
    w = exit_world(exit_alt=30000 + EXIT_LEVEL_TOL)    # 200 ft off: still ok
    while not w.finished:
        w.advance(1.0)
    assert w.handoffs[0]["level_ok"]
    w = exit_world(exit_alt=30000 + EXIT_LEVEL_TOL + 1)
    while not w.finished:
        w.advance(1.0)
    assert not w.handoffs[0]["level_ok"] and w.handoffs[0]["outcome"] == "wrong"


def test_handoff_wrong_gate_when_vectored():
    w = exit_world()
    for _ in range(10):
        w.advance(1.0)
    w.issue("EXT1", hdg=0)         # fly north instead of following the route
    while not w.finished:
        w.advance(1.0)
    h = w.handoffs[0]
    assert not h["gate_ok"] and h["gate_dist"] > EXIT_GATE_TOL and h["outcome"] == "wrong"


def test_missing_transfer_is_a_blank_item():
    w = exit_world()
    while not w.finished:
        w.advance(1.0)
    blanks = [t for t in w.tasks.log if t.kind == "transfer" and t.outcome == "blank"]
    assert len(blanks) == 1 and blanks[0].note == "left without transfer"
    assert w.task_stats["transfer"]["blank"] == 1


def test_transfer_window_and_frequency_choice():
    w = world([spec("EXT1", ["MOREA", "CANTO", "MIDAS", "ORISA"], tas=400)], tasks=True)
    w.advance(2.0)
    ok, msg, _ = w.request_transfer("EXT1")
    assert not ok and "not within" in msg
    while dist((w.aircraft["EXT1"].x, w.aircraft["EXT1"].y), w.sector.fixes["ORISA"]) > 19:
        w.advance(1.0)
    ok, msg, t = w.request_transfer("EXT1")
    assert ok and t is not None
    assert w.aircraft["EXT1"].freq_next in t.options
    w.tasks.answer(t.id, t.correct)
    assert w.aircraft["EXT1"].transferred
    assert w.aircraft["EXT1"].freq_now == w.aircraft["EXT1"].freq_next
    assert not w.request_transfer("EXT1")[0]
    while not w.finished:
        w.advance(1.0)
    assert w.task_stats["transfer"] == {"correct": 1, "wrong": 0, "blank": 0}


def test_wrong_frequency_counts_wrong_and_blocks_retry():
    w = world([spec("EXT1", ["MOREA", "CANTO", "MIDAS", "ORISA"], tas=400)], tasks=True)
    w.advance(2.0)
    while dist((w.aircraft["EXT1"].x, w.aircraft["EXT1"].y), w.sector.fixes["ORISA"]) > 19:
        w.advance(1.0)
    ok, msg, t = w.request_transfer("EXT1")
    w.tasks.answer(t.id, (t.correct + 1) % 3)
    assert not w.aircraft["EXT1"].transferred
    assert not w.request_transfer("EXT1")[0]
    while not w.finished:
        w.advance(1.0)
    assert w.task_stats["transfer"]["wrong"] == 1 and w.task_stats["transfer"].get("blank", 0) == 0


def test_restricted_zone_incursion_recorded_only_while_active():
    route = ["ORISA", "DORNA", "VELAR", "LUNDA"]     # R5 passes through zone R-31
    w = world([spec("ZON1", route, tas=400)], level=5, zone=True)
    while not w.finished:
        w.advance(1.0)
    assert len(w.zone_episodes) == 1
    assert w.zone_episodes[0]["end_t"] is not None
    sc = scenario([spec("ZON1", route, tas=400)], level=5)     # zone never active
    w2 = World(sc, tasks=False, pilot_delay=0.0)
    while not w2.finished:
        w2.advance(1.0)
    assert w2.zone_episodes == []
    sc3 = scenario([spec("ZON1", route, tas=400)], level=2, zone=True)   # level 2 has no zone
    w3 = World(sc3, tasks=False, pilot_delay=0.0)
    while not w3.finished:
        w3.advance(1.0)
    assert w3.zone_episodes == []


def test_what_if_reports_conflict_without_changing_state():
    w = head_on()
    for _ in range(400):
        w.advance(1.0)
    before = w.aircraft["AAA1"].tgt_hdg
    conf, zone = w.what_if("AAA1", hdg=w.aircraft["AAA1"].hdg + 50)
    assert conf == []
    conf2, _ = w.what_if("AAA1")            # unchanged: still the head-on conflict
    assert len(conf2) == 1
    assert w.aircraft["AAA1"].tgt_hdg == before


def test_level_change_safety_check():
    a = spec("AAA1", WEST_EAST, alt=30000, tas=300)
    b = spec("BBB2", list(reversed(WEST_EAST)), alt=32000, tas=300)
    w = world([a, b])
    for _ in range(400):
        w.advance(1.0)
    assert w.level_change_is_safe("AAA1", 28000)
    assert not w.level_change_is_safe("AAA1", 32000)      # climbing into the opposing traffic


def test_replay_snapshots_recorded():
    w = head_on()
    for _ in range(60):
        w.advance(1.0)
    clip = w.replay_clip(10, 20)
    assert clip and all(10 <= t <= 20 for t, _ in clip)
    assert {row[0] for row in clip[0][1]} == {"AAA1", "BBB2"}


def test_direct_to_rejects_waypoints_already_behind_the_aircraft():
    w = world([spec("D1", WEST_EAST, tas=400)])
    for _ in range(600):
        w.advance(1.0)
        if w.aircraft["D1"].route_idx >= 3:
            break
    ok, msg, _ = w.issue("D1", dct="VELAR")
    assert not ok and "behind" in msg
    ok, msg, cl = w.issue("D1", dct="NERVA")
    assert ok and w.aircraft["D1"].route_idx == 4


def test_misheard_readback_is_flown_unless_flagged():
    from dataclasses import replace
    for flag, expected_final in ((True, 100.0), (False, None)):
        w = world([spec("R1", WEST_EAST, tas=300)], tasks=True)
        w.advance(2.0)
        w.spec = replace(w.spec, readback_error_rate=1.0)
        w.force_readback = True
        ok, _, cl = w.issue("R1", hdg=100)
        assert ok and cl.applied and cl.wrong_field == "hdg"
        ac = w.aircraft["R1"]
        assert ac.tgt_hdg != 100.0                      # the pilot flies what he "heard"
        assert abs(ac.tgt_hdg - 100.0) in (10.0, 20.0, 30.0)
        t = w.tasks.open_of_kind("readback")[0]
        assert t.correct == 1 and str(int(ac.tgt_hdg)) in t.prompt
        w.tasks.answer(t.id, 1 if flag else 0)
        if flag:
            assert ac.tgt_hdg == expected_final and not cl.uncorrected
        else:
            assert ac.tgt_hdg != 100.0 and cl.uncorrected


def test_forced_turn_never_becomes_a_near_complete_circle_after_pilot_delay():
    w = world([spec("T1", WEST_EAST, tas=300)], pilot_delay=0.0)
    w.advance(2.0)
    ac = w.aircraft["T1"]
    ac.hdg = 111.0                    # the aircraft has already turned past the 110 the controller asked for
    ac.nav = False
    ok, _, cl = w.issue("T1", hdg=110, turn_dir="R")
    assert ok and ac.turn_dir is None            # short turn, not 359 degrees to the right
    ac.hdg = 90.0
    ok, _, cl = w.issue("T1", hdg=200, turn_dir="R")
    assert ac.turn_dir == "R"                    # a genuine right turn keeps its direction
    ac.hdg = 90.0
    ok, _, cl = w.issue("T1", hdg=20, turn_dir="R")   # 290 degrees the long way: explicit and allowed
    assert ac.turn_dir == "R"
