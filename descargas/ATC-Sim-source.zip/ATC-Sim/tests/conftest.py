import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from atcsim.core.aircraft import Aircraft  # noqa: E402
from atcsim.core.scenario import AircraftSpec, Scenario  # noqa: E402
from atcsim.core.world import World  # noqa: E402


def make_ac(cs="AAA1", x=0.0, y=0.0, alt=30000.0, hdg=0.0, tas=300.0, code="B738", **kw):
    return Aircraft(callsign=cs, type_code=code, x=x, y=y, alt=alt, hdg=hdg, tas=tas, tgt_alt=alt, tgt_tas=tas,
                    nav=False, tgt_hdg=hdg, **kw)


def spec(cs, route, t=0.0, alt=30000.0, exit_alt=None, tas=300.0, code="B738"):
    return AircraftSpec(cs, code, "T", list(route), t, alt, alt if exit_alt is None else exit_alt, tas)


def scenario(specs, level=5, seed=1, wind=(0.0, 0.0), scale=1.0, zone=False):
    sc = Scenario(seed, level, list(specs), wind[0], wind[1], scale, max([s.spawn_time for s in specs] or [0.0]))
    if zone:
        sc.zone_from = 0.0
    return sc


def world(specs, **kw):
    tasks = kw.pop("tasks", False)
    delay = kw.pop("pilot_delay", 0.0)
    return World(scenario(specs, **kw), tasks=tasks, pilot_delay=delay)


import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated_user_data(tmp_path_factory, monkeypatch):
    """No test may touch the real per-user folder (%LOCALAPPDATA%\ATC-Sim)."""
    monkeypatch.setenv("SIM_DATA_DIR", str(tmp_path_factory.mktemp("userdata")))
