import pytest

from atcsim.bot import Bot, play
from atcsim.core.generator import GATE_SPACING_S, generate, null_run_losses
from atcsim.core.perf import TYPES
from atcsim.core.scenario import LEVELS, level_spec, make_rng
from atcsim.core.scoring import compute_result
from atcsim.core.world import World


def test_rng_streams_are_independent_and_reproducible():
    a1 = [make_rng(5, "x").random() for _ in range(3)]
    a2 = [make_rng(5, "x").random() for _ in range(3)]
    assert a1 == a2
    assert make_rng(5, "x").random() != make_rng(5, "y").random()
    assert make_rng(5, "x").random() != make_rng(6, "x").random()


@pytest.mark.parametrize("level", range(1, 11))
def test_generation_deterministic_and_valid(level):
    s1 = generate(11, level)
    s2 = generate(11, level)
    assert s1 == s2
    assert generate(12, level) != s1
    spec = level_spec(level)
    assert len(s1.specs) == spec.n_aircraft
    cs = [s.callsign for s in s1.specs]
    assert len(set(cs)) == len(cs)
    for s in s1.specs:
        t = TYPES[s.type_code]
        assert t.v_min <= s.tas <= t.v_max
        assert 10000 <= s.entry_alt <= t.ceiling and 10000 <= s.exit_alt <= t.ceiling
        assert s.spawn_time >= 0
    # gate spacing
    by_gate = {}
    for s in s1.specs:
        by_gate.setdefault(s.route[0], []).append(s.spawn_time)
    for ts in by_gate.values():
        ts.sort()
        assert all(b - a >= GATE_SPACING_S - 1e-6 for a, b in zip(ts, ts[1:]))


@pytest.mark.parametrize("level", [1, 4, 7, 10])
def test_null_run_matches_recorded_losses_and_design_band(level):
    sc = generate(3, level)
    assert null_run_losses(sc) == sc.null_losses
    target = level_spec(level).design_conflicts
    assert sc.null_losses >= max(1, int(target * 0.7))


def test_designed_pair_really_conflicts_at_low_level():
    sc = generate(21, 2)
    w = World(sc, tasks=False, pilot_delay=0.0, record=False)
    w.predict_enabled = False
    while not w.finished:
        w.advance_sim(5.0)
    pairs = {ep.pair for ep in w.losses}
    designed = {tuple(sorted(p)) for p in sc.designed_pairs}
    assert pairs & designed


def test_full_run_is_deterministic_including_tasks_and_delays():
    def run():
        sc = generate(5, 4)
        w = World(sc)
        play(w, Bot(w, seed=3, p_correct=0.9, p_skip=0.1))
        r = compute_result(w)
        return (r.correct, r.wrong, r.blank, r.losses, round(r.score, 6), len(w.clearances), len(w.events),
                [(round(t, 3), k) for t, k, _ in w.events[:200]])
    assert run() == run()


def test_difficulty_is_monotonic_for_idle_and_for_bot():
    idle = []
    for lv in (1, 4, 7, 10):
        sc = generate(9, lv)
        w = World(sc)
        play(w, None)
        idle.append(compute_result(w).score)
    assert idle[0] > idle[-1]
    assert all(a >= b for a, b in zip(idle, idle[1:]))
    bot = []
    for lv in (1, 5, 10):
        sc = generate(9, lv)
        w = World(sc)
        play(w, Bot(w, seed=1, p_correct=0.95, p_skip=0.03))
        bot.append(compute_result(w).score)
    assert bot[0] > bot[1] >= bot[2]


@pytest.mark.parametrize("level", range(1, 11))
@pytest.mark.parametrize("profile", ["idle", "sloppy"])
def test_run_invariants_over_levels(level, profile):
    """Whatever the player does, the bookkeeping must be consistent."""
    sc = generate(500 + level, level)
    w = World(sc)
    bot = None if profile == "idle" else Bot(w, seed=level, p_correct=0.7, p_skip=0.2, reaction_s=4.0, lead_s=90.0)
    play(w, bot, step_real=0.5)
    assert w.finished
    assert w.tasks.tasks == []                                   # nothing left open
    assert w.spawned == len(sc.specs) and w.pending_spawns == []
    assert w.exited == len(w.handoffs) == w.spawned - len(w.aircraft)
    r = compute_result(w)
    assert r.items == r.correct + r.wrong + r.blank
    assert 0.0 <= r.score <= 100.0 and 0.0 <= r.accuracy <= 100.0
    n_tasks = sum(1 for t in w.tasks.log if t.outcome in ("correct", "wrong", "blank"))
    assert n_tasks == sum(sum(v.values()) for v in w.task_stats.values())
    handoff_items = r.components.get("Handoff", {"correct": 0, "wrong": 0, "blank": 0})
    assert sum(handoff_items.values()) == len(w.handoffs)
    for ep in w.losses:
        assert ep.end_t is not None and ep.min_h < 5.0 and ep.min_v < 1000.0
    assert r.losses == len(w.losses)
    # every aircraft got exactly one transfer item (correct, wrong or blank)
    tr = sum(sum(w.task_stats.get("transfer", {"correct": 0, "wrong": 0, "blank": 0}).values()) for _ in [0])
    assert tr == len(w.handoffs)
    if profile == "idle":
        assert r.blank > 0 and not r.met
