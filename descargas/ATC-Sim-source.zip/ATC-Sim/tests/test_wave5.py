"""Wave 5: persisted thirds/unneeded/commands, endurance text, paired-seed dual-task cost, optional coach profile."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from atcsim.bot import Bot, play
from atcsim.core.coach import load_profile
from atcsim.core.generator import generate
from atcsim.core.persistence import StatsStore, result_to_record
from atcsim.core.scoring import (RADAR_ONLY, RunResult, compute_result, dual_task_cost, endurance_text,
                                 latest_pair_cost, thirds_schema)
from atcsim.core.world import World


def _run(seed, level, tasks, mode):
    w = World(generate(seed, level), tasks=tasks)
    play(w, Bot(w, seed=1, p_correct=0.9), step_real=0.5)
    return w, compute_result(w, mode)


def test_thirds_schema_grouping_and_null():
    timed = [(float(i), "correct" if i % 3 else "wrong") for i in range(9)]
    th = thirds_schema(timed, 9.0, 90.0)
    assert [g["n"] for g in th] == [3, 3, 3]
    assert sum(g["c"] for g in th) == 6 and all(g["b"] == 0 for g in th) and th[0]["s"] == 30.0
    assert thirds_schema(timed[:8], 9.0, 90.0) is None
    late = thirds_schema([(9.0, "blank")] + timed[:8], 9.0, 9.0)     # t == end goes to third 3, never index 3
    assert late[2]["b"] == 1 and sum(g["n"] for g in late) == 9


def test_record_persists_thirds_unneeded_commands_and_reloads(tmp_path):
    w, r = _run(31, 4, True, "Ladder")
    assert r.thirds_data is not None
    assert sum(g["n"] for g in r.thirds_data) == r.items
    p = str(tmp_path / "s.json")
    st = StatsStore(p)
    rec = st.add_run(r, ts=1_700_000_000.0)
    assert rec["thirds"] == r.thirds_data and rec["unneeded"] == r.unneeded and rec["commands"] == r.commands
    assert sum(g["c"] for g in rec["thirds"]) == r.correct
    assert StatsStore(p).data["runs"] == [rec]


def test_old_records_and_bad_thirds_load(tmp_path):
    p = tmp_path / "s.json"
    good = {"ts": 2.0, "level": 3, "correct": 5, "wrong": 1, "blank": 0,
            "thirds": [{"n": 2, "c": 2, "b": 0, "s": 1.0}] * 3, "unneeded": 2, "commands": 9}
    bad1 = {"ts": 3.0, "level": 3, "correct": 5, "wrong": 1, "blank": 0, "thirds": [1, 2, 3]}
    bad2 = {"ts": 4.0, "level": 3, "correct": 5, "wrong": 1, "blank": 0, "thirds": [{"n": 1, "c": 5, "b": 0, "s": 1}] * 3}
    old = {"ts": 1.0, "level": 3, "correct": 5, "wrong": 1, "blank": 0}
    p.write_text(json.dumps({"version": 2, "runs": [old, good, bad1, bad2]}), encoding="utf-8")
    runs = StatsStore(str(p)).data["runs"]
    assert [x["thirds"] is None for x in runs] == [True, False, True, True]
    assert runs[0]["unneeded"] == 0 and runs[1]["commands"] == 9


def test_csv_unchanged_by_thirds(tmp_path):
    _, r = _run(31, 3, True, "Ladder")
    st = StatsStore(str(tmp_path / "s.json"))
    st.add_run(r, ts=1_700_000_000.0)
    out = str(tmp_path / "o.csv")
    assert st.export_csv(out)
    lines = open(out, encoding="utf-8-sig", newline="").read().split("\r\n")
    assert lines[0] == "Date;Module;Level;Correct;Wrong;Blank;Seconds per item;Accuracy %;Goal;Met"
    assert len(lines[1].split(";")) == 10


def test_endurance_text():
    ok = [{"n": 10, "c": 9, "b": 0, "s": 1}, {"n": 10, "c": 9, "b": 0, "s": 1}, {"n": 10, "c": 6, "b": 1, "s": 1}]
    assert "-30 points" in endurance_text(ok) and "fading" in endurance_text(ok)
    small = [{"n": 3, "c": 3, "b": 0, "s": 1}] * 3
    assert "too few" in endurance_text(small)
    assert "not enough" in endurance_text(None)


def test_paired_seed_same_traffic_and_cost(tmp_path):
    sc1, sc2 = generate(77, 5), generate(77, 5)
    assert sc1 == sc2                                    # same seed -> same traffic
    w_full, r_full = _run(77, 5, True, "Ladder")
    w_ro, r_ro = _run(77, 5, False, RADAR_ONLY)
    assert r_ro.aircraft == r_full.aircraft
    st = StatsStore(str(tmp_path / "s.json"))
    a = st.add_run(r_full)
    b = st.add_run(r_ro)
    assert "5" not in st.data["best"] or st.data["best"]["5"]["ts"] == a["ts"]   # radar-only never becomes a best
    c = dual_task_cost(b, a)
    assert c is not None and abs(c["cost_points"] - (c["radar_only"] - c["full"])) < 1e-9
    assert latest_pair_cost(st.data["runs"], b) == c and latest_pair_cost(st.data["runs"], a) == c


def test_dual_task_cost_rejects_bad_pairs():
    def rec(mode, seed, level, c, w):
        return {"mode": mode, "seed": seed, "level": level, "components": {"Separation": {"correct": c, "wrong": w, "blank": 0}}}
    ro, full = rec(RADAR_ONLY, 1, 5, 10, 0), rec("Ladder", 1, 5, 8, 2)
    assert dual_task_cost(ro, full)["cost_points"] == 20.0
    assert dual_task_cost(ro, rec("Ladder", 2, 5, 8, 2)) is None
    assert dual_task_cost(ro, rec("Ladder", 1, 4, 8, 2)) is None
    assert dual_task_cost(full, ro) is None and dual_task_cost({}, {}) is None
    assert dual_task_cost(ro, {"mode": "Ladder", "seed": 1, "level": 5, "components": {}}) is None


def test_radar_only_skipped_by_streak(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    r = RunResult(3, 1, "Ladder", correct=9, wrong=0, blank=0, real_seconds=10.0)
    r.met = True
    st.add_run(r)
    r2 = RunResult(3, 1, RADAR_ONLY, correct=1, wrong=5, blank=0, real_seconds=10.0)
    st.add_run(r2)
    assert st.clean_streak() == 1


def test_coach_profile_valid_and_malformed(tmp_path):
    p = tmp_path / "atc_profile.json"
    assert load_profile(str(p)) is None                                     # missing
    p.write_text(json.dumps({"generated": "x", "weakest": "H4", "suggestedSimLevel": 4,
                             "abilities": {"H4": {"S": 61.4, "confidence": "Low", "trend": "up"}}}), encoding="utf-8")
    c = load_profile(str(p))
    assert c["level"] == 4 and "H4" in c["message"] and "61" in c["message"]
    bad_texts = ["{ nope", "[1,2]", "null", '{"suggestedSimLevel": 99}', '{"suggestedSimLevel": "x", "weakest": 5}',
                 '{"suggestedSimLevel": true}', '{"suggestedSimLevel": NaN}', "", "\x00\x01\xff"]
    for t in bad_texts:
        p.write_bytes(t.encode("utf-8", "surrogateescape") if isinstance(t, str) else t)
        assert load_profile(str(p)) is None, t
    p.write_text('{"weakest": "S4", "suggestedSimLevel": 0, "abilities": 7}', encoding="utf-8")
    c = load_profile(str(p))
    assert c["level"] is None and "S4" in c["message"]
    p.write_bytes(b"\xff\xfe\x00bad")
    assert load_profile(str(p)) is None


def test_app_uses_suggested_level_only_without_history(tmp_path):
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    from atcsim.ui.app import App
    prof = tmp_path / "atc_profile.json"
    prof.write_text('{"weakest": "H3", "suggestedSimLevel": 6}', encoding="utf-8")
    app = App(headless=True, stats_path=str(tmp_path / "a.json"), profile_path=str(prof))
    assert app.stats.data["adaptive"]["level"] == 6 and app.coach["level"] == 6
    st = StatsStore(str(tmp_path / "b.json"))
    r = RunResult(2, 1, "Ladder", correct=5, wrong=0, blank=0, real_seconds=5.0)
    st.add_run(r)
    app2 = App(headless=True, stats_path=str(tmp_path / "b.json"), profile_path=str(prof))
    assert app2.stats.data["adaptive"]["level"] == 1
    prof.write_text("garbage", encoding="utf-8")
    app3 = App(headless=True, stats_path=str(tmp_path / "c.json"), profile_path=str(prof))
    assert app3.coach is None and app3.stats.data["adaptive"]["level"] == 1
