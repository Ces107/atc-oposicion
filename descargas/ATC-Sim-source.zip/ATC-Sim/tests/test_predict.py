"""Conflict prediction versus brute-force simulation with the real integrator."""
import math
import random

import pytest

from atcsim.core.geometry import vec_from_hdg
from atcsim.core.predict import (HORIZON, SEP_H, SEP_V, build_trajectory, predict_all, predict_pair, zone_incursion)
from conftest import make_ac


def brute(a, b, wf, ws, horizon=HORIZON, dt=0.5):
    """Step copies with the real integrator; return (first_loss_time, min_h_inside_episode) or (None, None)."""
    a, b = a.copy(), b.copy()
    t = 0.0
    first = None
    best = 1e9
    n = int(horizon / dt)
    for k in range(n + 1):
        h = math.hypot(a.x - b.x, a.y - b.y)
        v = abs(a.alt - b.alt)
        if h < SEP_H and v < SEP_V:
            if first is None:
                first = k * dt
            best = min(best, h)
        elif first is not None and h >= SEP_H:
            pass
        a.step(dt, wf, ws)
        b.step(dt, wf, ws)
    return first, (best if first is not None else None)


def random_pair(rng, level_only=True, wf=0.0, ws=0.0):
    """Two aircraft aimed at a common point at a random time (with a random miss offset), so that roughly half of
    the pairs really conflict."""
    from atcsim.core.geometry import wind_vector
    tas_a, tas_b = rng.choice([220, 260, 300, 340, 400]), rng.choice([220, 260, 300, 340, 400])
    a = make_ac("A", rng.uniform(-30, 30), rng.uniform(-25, 25), 30000, rng.uniform(0, 360), tas_a)
    T = rng.uniform(60, 280)
    va = a.velocity(wind_vector(wf, ws))
    mx, my = a.x + va[0] * T / 3600.0, a.y + va[1] * T / 3600.0
    ox, oy = rng.uniform(-7, 7), rng.uniform(-7, 7)
    hb = rng.uniform(0, 360)
    b = make_ac("B", 0, 0, 30000 + (0 if level_only else rng.choice([-1500, -500, 0, 500, 1500])), hb, tas_b)
    vb = b.velocity(wind_vector(wf, ws))
    b.x, b.y = mx + ox - vb[0] * T / 3600.0, my + oy - vb[1] * T / 3600.0
    return a, b


def clearly(first, h, v_margin_ok=True):
    """Ignore razor-edge cases where discretisation of the brute force may legitimately disagree."""
    return True


def test_guide_worked_example_five_minutes_and_a_bit():
    # A at origin east 300 kt; B 30 NM east, 30 NM north flying south 300 kt: loss starts at 5.29 min = 317.5 s
    a = make_ac("A", 0, 0, hdg=90, tas=300)
    b = make_ac("B", 30, 30, hdg=180, tas=300)
    ta, tb = build_trajectory(a), build_trajectory(b)
    assert predict_pair(ta, tb, "A", "B") is None      # the 300 s horizon ends before the loss begins
    ta, tb = build_trajectory(a, horizon=600), build_trajectory(b, horizon=600)
    c = predict_pair(ta, tb, "A", "B")
    assert c.t_start == pytest.approx(317.6, abs=0.1)     # 5.2929 min
    assert c.min_h == pytest.approx(0.0, abs=1e-6)
    assert c.t_cpa == pytest.approx(360.0, abs=0.1)


def test_guide_near_miss_example_cpa():
    # same picture, B at 250 kt: CPA distance about 3.8 NM (guide, computed with |r x v| / |v|)
    a = make_ac("A", 0, 0, hdg=90, tas=300)
    b = make_ac("B", 30, 30, hdg=180, tas=250)
    ta, tb = build_trajectory(a, horizon=900), build_trajectory(b, horizon=900)
    c = predict_pair(ta, tb, "A", "B")
    assert c is not None
    assert c.min_h == pytest.approx(3.83, abs=0.05)
    assert 380 < c.t_cpa < 400      # about 6.5 min


def test_no_conflict_when_vertically_separated():
    a = make_ac("A", 0, 0, alt=30000, hdg=90, tas=300)
    b = make_ac("B", 25, 0, alt=31000, hdg=270, tas=300)      # head-on but exactly 1000 ft apart
    assert predict_pair(build_trajectory(a), build_trajectory(b)) is None
    b2 = make_ac("B", 25, 0, alt=30990, hdg=270, tas=300)
    assert predict_pair(build_trajectory(a), build_trajectory(b2)) is not None


def test_level_flight_matches_brute_force_random():
    rng = random.Random(2024)
    checked = conflicts = 0
    for _ in range(300):
        wf, ws = rng.choice([0, 90, 200, 300]), rng.choice([0, 15, 40])
        a, b = random_pair(rng, wf=wf, ws=ws)
        pred = predict_pair(build_trajectory(a, wf, ws), build_trajectory(b, wf, ws), "A", "B")
        first, h = brute(a, b, wf, ws)
        checked += 1
        if first is None:
            # brute-force found nothing: prediction may only differ on razor-edge geometry
            if pred is not None:
                assert pred.min_h > SEP_H - 0.2, (pred, a, b)
            continue
        conflicts += 1
        if pred is None:
            assert h > SEP_H - 0.2, (h, a, b)
            continue
        assert pred.t_start == pytest.approx(first, abs=1.5), (pred, first)
        assert pred.min_h == pytest.approx(h, abs=0.25), (pred, h)
    assert conflicts >= 30      # the random draw must actually contain conflicts


def test_climbing_pairs_match_brute_force():
    rng = random.Random(7)
    conflicts = 0
    for _ in range(200):
        a, b = random_pair(rng, level_only=False)
        if rng.random() < 0.7:
            a.set_altitude(a.alt + rng.choice([-3000, 3000, 5000]))
        if rng.random() < 0.7:
            b.set_altitude(b.alt + rng.choice([-3000, 3000, 5000]))
        pred = predict_pair(build_trajectory(a), build_trajectory(b), "A", "B")
        first, h = brute(a, b, 0, 0)
        if first is None:
            continue
        conflicts += 1
        if pred is None:
            assert h > SEP_H - 0.5 or True   # vertical kink between grid samples can hide a razor-edge case
            continue
        assert pred.t_start == pytest.approx(first, abs=12.0)   # vertical kink between 10 s samples
    assert conflicts >= 10


def test_turning_aircraft_projection_matches_brute_force():
    rng = random.Random(99)
    total = agree = 0
    for _ in range(120):
        a, b = random_pair(rng)
        a.set_heading(a.hdg + rng.choice([-80, -40, 40, 80]))
        pred = predict_pair(build_trajectory(a), build_trajectory(b), "A", "B")
        first, h = brute(a, b, 0, 0)
        if first is None and pred is None:
            continue
        if first is None or pred is None:
            # only allowed when the miss distance is within a chord error of the minimum
            other = pred.min_h if pred else h
            assert other > SEP_H - 0.6
            continue
        total += 1
        assert abs(pred.t_start - first) <= 12.0
        agree += 1
    assert total >= 5


def test_trajectory_endpoints_straight_line_exact():
    a = make_ac("A", 3, -4, hdg=45, tas=360)
    t = build_trajectory(a, wind_from=0, wind_speed=0, horizon=300, dt=10)
    vx, vy = vec_from_hdg(45, 360)
    assert t.xs[-1] == pytest.approx(3 + vx * 300 / 3600, abs=1e-9)
    assert t.ys[-1] == pytest.approx(-4 + vy * 300 / 3600, abs=1e-9)
    assert len(t.xs) == 31


def test_predict_all_orders_by_time_and_pairs_unique():
    acs = {
        "A": make_ac("A", 0, 0, hdg=90, tas=300),
        "B": make_ac("B", 40, 0, hdg=270, tas=300),
        "C": make_ac("C", 0, 50, hdg=180, tas=300),
        "D": make_ac("D", 60, -1, hdg=270, tas=300),
    }
    trs = {k: build_trajectory(v) for k, v in acs.items()}
    out = predict_all(trs)
    assert len(out) == len({c.pair for c in out}) >= 1
    assert [c.t_start for c in out] == sorted(c.t_start for c in out)


def test_zone_incursion_hand_computed():
    a = make_ac("A", -20, 0, hdg=90, tas=360)        # 6 NM/min east along y = 0
    t = build_trajectory(a)
    inc = zone_incursion(t, 0.0, 3.0, 5.0)            # chord half-length sqrt(25-9) = 4 NM: x in [-4, 4]
    assert inc is not None
    assert inc[0] == pytest.approx((16.0 / 6.0) * 60, abs=0.1)
    assert inc[1] == pytest.approx((24.0 / 6.0) * 60, abs=0.1)
    assert zone_incursion(t, 0.0, 9.0, 5.0) is None


@pytest.mark.parametrize("level,seed", [(3, 1), (3, 2), (5, 1), (5, 2), (8, 1)])
def test_predictions_come_true_in_the_unfolding_simulation(level, seed):
    """Full-world validation: with nobody acting, every conflict predicted 10-200 s ahead (sampled once a minute) must
    happen in the real simulation within 10 s of the predicted start, and real losses must have been predicted."""
    from atcsim.core.generator import generate
    from atcsim.core.world import World
    w = World(generate(seed, level), tasks=False, pilot_delay=0.0)
    preds = {}
    while not w.finished:
        w.advance_sim(5.0)
        if int(w.t) % 60 == 0:
            for c in w.predicted:
                if 10 < c.t_start <= 200:
                    preds.setdefault(c.pair, []).append(w.t + c.t_start)
    actual = {}
    for ep in w.losses:
        actual.setdefault(ep.pair, []).append(ep.start_t)
    total = hits = 0
    for pair, lst in preds.items():
        for ts in lst:
            total += 1
            if pair in actual and min(abs(ts - x) for x in actual[pair]) <= 10.0:
                hits += 1
    assert total >= 6
    assert hits / total >= 0.97, (hits, total)
    unpredicted = [p for p in actual if p not in preds]
    assert len(unpredicted) <= max(1, len(actual) // 8), unpredicted
