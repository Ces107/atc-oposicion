"""Strip planner mode: generator, an independent conflict sweep, world rules, scoring, save/load, ladder, UI.

The reference conflict finder below (`sweep_pairs`) does NOT use the module's analytic checker: it recomputes every
time from knots and nautical miles, samples every aircraft once per second of the exercise clock, marks the time
window each one "holds" each point (half the minimum either side) and looks for sign changes of the along-track
distance between two aircraft on the same segment at the same level.
"""
import copy
import json
import os
import random
import shutil
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))

from atcsim.core.planner import (GATES, INNER, LEVELS_BY_PARITY, MAX_REF_COST, PARITY, PLANNER_LEVELS, SEGMENTS,
                                 SEP_MIN, SPEED_NM_MIN, THINK_MIN, Flight, PlannerWorld, best_plan, best_resolution,
                                 compute_planner_result, find_conflicts, first_conflict, generate_planner, pair_key,
                                 parity_of, planner_spec, route_length, route_options)
from atcsim.core.persistence import CSV_COLUMNS, StatsStore, runs_to_csv
from atcsim.core.scoring import adaptive_update
from atcsim.planner_bot import PlannerBot, run_core

SIM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# ---- independent reference ------------------------------------------------------------------------------------
def _sec_times(f):
    """Seconds of the exercise clock over each route point, from knots and NM (not from Flight.times)."""
    r = f.routes[f.route_i]
    t = (f.entry_t + f.delay) * 60.0
    out = [t]
    for a, b in zip(r, r[1:]):
        t += SEGMENTS[frozenset((a, b))] / (f.speed / 3600.0)
        out.append(t)
    assert all(abs(x - round(x)) < 1e-6 for x in out)
    return [int(round(x)) for x in out]


def sweep_pairs(flights):
    """Conflicting pairs by brute force (1-second samples)."""
    half = int(SEP_MIN * 60 / 2)
    occ = {}                     # (point, second) -> [(cs, levels)]
    seg = {}                     # (segment, level) -> {cs: {second: along-track NM from the segment's first name}}
    for f in flights:
        r = f.routes[f.route_i]
        ts = _sec_times(f)
        lv = f.levels
        for i, p in enumerate(r):
            here = set()
            if i > 0:
                here.add(lv[i - 1])
            if i < len(lv):
                here.add(lv[i])
            for s in range(ts[i] - half, ts[i] + half):
                occ.setdefault((p, s), []).append((f.cs, here))
        for i in range(len(r) - 1):
            a, b = r[i], r[i + 1]
            key = tuple(sorted((a, b)))
            ln = SEGMENTS[frozenset((a, b))]
            d = seg.setdefault((key, lv[i]), {}).setdefault(f.cs, {})
            for s in range(ts[i] + 1, ts[i + 1]):
                frac = (s - ts[i]) / (ts[i + 1] - ts[i])
                d[s] = frac * ln if a == key[0] else (1.0 - frac) * ln
    pairs = set()
    for occupants in occ.values():
        for i in range(len(occupants)):
            for j in range(i + 1, len(occupants)):
                (ca, la), (cb, lb) = occupants[i], occupants[j]
                if ca != cb and la & lb:
                    pairs.add(pair_key(ca, cb))
    for byc in seg.values():
        names = sorted(byc)
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                xa, xb = byc[names[i]], byc[names[j]]
                prev = None
                for s in sorted(set(xa) & set(xb)):
                    dlt = xa[s] - xb[s]
                    if abs(dlt) < 1e-9 or (prev is not None and prev[0] == s - 1 and prev[1] * dlt < 0):
                        pairs.add(pair_key(names[i], names[j]))
                        break
                    prev = (s, dlt)
    return pairs


def corrected(flights):
    out = copy.deepcopy(flights)
    for f in out:
        if f.err == "L":
            f.levels[-1] = f.xfl
    return out


def mk(cs, route, speed, entry, fl, levels=None):
    f = Flight(cs, "A320", speed, entry, [list(route)], fl, fl, fl)
    if levels:
        f.levels = list(levels)
    return f


# ---- the route structure --------------------------------------------------------------------------------------
def test_segments_and_speeds_give_half_minutes():
    assert set(SEGMENTS.values()) <= {24, 36, 48}
    for ln in SEGMENTS.values():
        for v in SPEED_NM_MIN.values():
            assert (ln / v * 2) == int(ln / v * 2)          # every segment time is a whole or half minute
    for kt, v in SPEED_NM_MIN.items():
        assert v == kt / 60.0


def test_routes_primary_shortest_and_alternative_over_other_points():
    for a in GATES:
        for b in GATES:
            if a == b:
                continue
            opts = route_options(a, b)
            assert opts[0][0] == a and opts[0][-1] == b
            assert all(p in INNER for p in opts[0][1:-1])
            if len(opts) == 2:
                assert opts[1][1:-1] != opts[0][1:-1]
                assert route_length(opts[0]) <= route_length(opts[1]) <= route_length(opts[0]) + 48


# ---- hand-computed conflicts ----------------------------------------------------------------------------------
def test_common_point_under_three_minutes_is_a_conflict_three_is_not():
    a = mk("AAA1", ["OLMAR", "ARVEN", "BOLMA", "ESTAN"], 480, 10.0, 300)      # ARVEN at 14.5
    b = mk("BBB2", ["NORIX", "ARVEN", "CUREL", "SOLBE"], 360, 13.0, 300)      # ARVEN at 17.0: 2.5 apart
    c = first_conflict(a, b)
    assert c is not None and c.kind == "punto" and c.where == "ARVEN" and c.t == 14.5
    b.entry_t = 13.5                                                           # 3.0 apart: separated
    assert first_conflict(a, b) is None
    b.entry_t = 13.0
    b.levels = [310, 310, 310]                                                 # 1000 ft apart
    assert first_conflict(a, b) is None


def test_level_change_over_a_point_counts_both_levels():
    a = mk("AAA1", ["OLMAR", "ARVEN", "BOLMA", "ESTAN"], 480, 10.0, 310, levels=[300, 310, 310])
    b = mk("BBB2", ["NORIX", "ARVEN", "CUREL", "SOLBE"], 360, 13.0, 300)
    assert first_conflict(a, b).where == "ARVEN"                               # a still holds 300 over ARVEN
    a.levels = [310, 310, 300]                                                 # changes later, over BOLMA
    assert first_conflict(a, b) is None


def test_overtaking_on_a_common_segment():
    slow = mk("SLO1", ["NORIX", "ARVEN", "CUREL", "SOLBE"], 240, 10.0, 300)   # ARVEN 16, CUREL 28
    fast = mk("FST1", ["NORIX", "ARVEN", "CUREL", "SOLBE"], 480, 16.0, 300)   # ARVEN 19, CUREL 25
    cs = [c for c in [first_conflict(slow, fast)] if c]
    assert cs and cs[0].kind == "alcance" and cs[0].where == "ARVEN-CUREL"
    assert cs[0].t == pytest.approx(22.0)                                      # 4(t-10-6) = 8(t-16-3)
    fast.entry_t = 18.0                                                        # CUREL 27 vs 28: passes it, and 1' apart
    assert first_conflict(slow, fast).kind == "alcance"
    fast.entry_t = 28.0                                                        # SOLBE 43 vs 40: still 3' behind at the exit
    assert first_conflict(slow, fast) is None
    fast.entry_t = 7.0                                                         # 3' ahead at NORIX and pulling away
    assert first_conflict(slow, fast) is None
    assert sweep_pairs([slow, fast]) == set()


def test_head_on_on_a_common_segment():
    a = mk("EST1", ["OLMAR", "ARVEN", "BOLMA", "ESTAN"], 360, 0.0, 300)       # ARVEN 6, BOLMA 12
    b = mk("WST1", ["ESTAN", "BOLMA", "ARVEN", "OLMAR"], 360, 2.0, 300)       # BOLMA 6, ARVEN 12
    c = first_conflict(a, b)
    assert c.kind == "frente" and c.where == "ARVEN-BOLMA" and c.t == pytest.approx(9.0)
    b.entry_t = 12.0                                                           # now they meet on BOLMA-ESTAN instead
    c = first_conflict(a, b)
    assert c.kind == "frente" and c.where == "BOLMA-ESTAN" and c.t == pytest.approx(14.0)
    b.entry_t = 19.0                                                           # enters 3' after a has left over ESTAN
    assert first_conflict(a, b) is None
    assert sweep_pairs([a, b]) == set()


# ---- generator ------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("level", range(1, 11))
def test_designed_conflicts_match_the_independent_sweep(level):
    for seed in (11, 12, 13):
        sc = generate_planner(seed, level)
        designed = set(sc.designed)
        assert len(designed) == planner_spec(level).conflicts
        assert sweep_pairs(sc.flights) == designed
        assert sweep_pairs(corrected(sc.flights)) == designed      # correcting an XFL error never adds a conflict
        assert set(find_conflicts(sc.flights)) == designed


def test_checker_agrees_with_sweep_on_random_plans():
    rng = random.Random(5)
    checked = 0
    for seed in range(20, 30):
        sc = generate_planner(seed, rng.choice([4, 6, 8, 10]))
        for _ in range(4):
            fl = copy.deepcopy(sc.flights)
            for f in fl:
                r = rng.random()
                if r < 0.15:
                    f.delay = float(rng.randint(1, 6))
                elif r < 0.25 and len(f.routes) > 1:
                    f.route_i = 1
                    f.levels = [f.rfl] * (len(f.route) - 1)
                elif r < 0.45:
                    i = rng.randrange(len(f.levels))
                    f.levels[i] += rng.choice([-10, 10])
            assert set(find_conflicts(fl)) == sweep_pairs(fl)
            checked += 1
    assert checked == 40


def test_generator_is_deterministic_and_seeds_differ():
    a, b = generate_planner(77, 6), generate_planner(77, 6)
    key = lambda sc: [(f.cs, f.entry_t, f.routes, f.speed, f.rfl, f.xfl, f.err, f.time_err) for f in sc.flights]
    assert key(a) == key(b) and set(a.designed) == set(b.designed)
    assert key(generate_planner(78, 6)) != key(a)


@pytest.mark.parametrize("level", [1, 3, 5, 7, 10])
def test_generated_strips_follow_the_format(level):
    sp = planner_spec(level)
    for seed in (1, 2):
        sc = generate_planner(seed, level)
        assert len(sc.flights) == sp.n_flights
        assert len({f.cs for f in sc.flights}) == sp.n_flights
        assert sum(1 for f in sc.flights if f.err) == sp.coord_errors
        members = [cs for p in sc.designed for cs in p]
        assert len(members) == len(set(members))                    # designed pairs never share an aircraft
        for f in sc.flights:
            for t in f.times() + [f.shown_exit()]:
                assert t * 2 == int(t * 2)                          # :00 or :30
            assert f.speed in SPEED_NM_MIN
            assert f.entry_t >= sp.lead_min                         # its strip is on the board before it enters
            if f.err == "T":
                assert f.shown_exit() != f.t_exit and f.xfl == f.shown_xfl
                assert parity_of(f.xfl) == PARITY[f.exit]
            elif f.err == "L":
                assert parity_of(f.shown_xfl) != PARITY[f.exit] and parity_of(f.xfl) == PARITY[f.exit]
                assert f.rfl == f.shown_xfl and abs(f.xfl - f.shown_xfl) == 10
            else:
                assert f.shown_exit() == f.t_exit and f.shown_xfl == f.xfl == f.rfl
                assert f.rfl in LEVELS_BY_PARITY[PARITY[f.exit]]
        by = {f.cs: f for f in sc.flights}
        for p, c in sc.designed.items():
            seen = max(sc.appear(by[p[0]]), sc.appear(by[p[1]]))
            assert c.t >= seen + THINK_MIN - 1e-9                   # always time to see it coming
            act = best_resolution(by, p, seen + 1.0)
            assert act is not None and act.cost <= MAX_REF_COST + 0.1


def test_all_three_kinds_are_designed():
    kinds = set()
    for seed in range(5):
        kinds |= {c.kind for c in generate_planner(seed, 6).designed.values()}
    assert kinds == {"punto", "alcance", "frente"}


# ---- world rules ----------------------------------------------------------------------------------------------
def run_idle(level, seed):
    w = PlannerWorld(generate_planner(seed, level))
    while not w.finished:
        w.advance(0.5)
    return w, compute_planner_result(w)


def test_idle_player_loses_every_designed_conflict_and_misses_every_strip_error():
    w, r = run_idle(5, 3)
    n = planner_spec(5).conflicts
    assert r.lost == n and r.missed == n and r.found == 0 and r.created == 0
    assert r.components["Separación"] == {"correct": 0, "wrong": n, "blank": 0}
    assert r.components["Detección"] == {"correct": 0, "wrong": 0, "blank": n}
    assert r.components["Coordinación"]["blank"] == planner_spec(5).coord_errors
    assert r.accuracy == 0.0 and not r.met and r.score < 20
    assert set(w.exited) == set(w.flights)


@pytest.mark.parametrize("level", range(1, 11))
def test_perfect_bot_scores_full_marks(level):
    for seed in (101, 102):
        w, r = run_core(level, seed)
        assert r.score == 100.0 and r.accuracy == 100.0 and r.met, (level, seed, r.breakdown)
        assert r.found == r.conflicts and r.lost == 0 and r.coord_flagged == r.coord_errors
        assert r.cost_units <= r.ref_cost + r.conflicts + 1e-9


def _at(w, t):
    while w.t < t and not w.finished:
        w.advance(0.05)


def test_declarations_false_alarms_and_duplicates():
    sc = generate_planner(9, 4)
    w = PlannerWorld(sc)
    p, c = next(iter(sorted(sc.designed.items(), key=lambda kv: kv[1].t)))
    _at(w, max(w.appear(p[0]), w.appear(p[1])) + 0.1)
    assert w.declare(*p)[0] == "correct"
    assert w.declare(*p) == (None, "ya")
    board = [cs for cs in w.on_board()]
    other = next(((a, b) for a in board for b in board if a < b and pair_key(a, b) not in sc.designed
                  and pair_key(a, b) not in w.conflicts()), None)
    assert other is not None
    assert w.declare(*other)[0] == "wrong"
    assert w.declare(other[0], other[0])[0] is None
    r = compute_planner_result(w)
    assert r.false_alarms == 1 and r.components["Detección"]["wrong"] == 1


def test_declaring_after_the_conflict_happened_does_not_count():
    sc = generate_planner(9, 4)
    w = PlannerWorld(sc)
    p, c = min(sc.designed.items(), key=lambda kv: kv[1].t)
    _at(w, c.t + 0.1)
    assert p in w.happened
    assert w.declare(*p) == (None, "tarde")


def test_flags_right_wrong_and_too_late():
    sc = generate_planner(4, 6)
    w = PlannerWorld(sc)
    bad = [f for f in sc.flights if f.err]
    lerr = next((f for f in bad if f.err == "L"), None)
    _at(w, w.appear(bad[0].cs) + 0.1)
    good = next(f for f in sc.flights if not f.err and w.visible(f.cs) and f.entry_t > w.t)
    assert w.flag(bad[0].cs)[0] == "correct"
    assert w.flag(bad[0].cs) == (None, "ya")
    assert w.flag(good.cs)[0] == "wrong"
    late = bad[-1]
    _at(w, w.flights[late.cs].t_entry + 0.1)
    if late.cs not in w.flags:
        assert w.flag(late.cs) == (None, "tarde")
    if lerr is not None:
        w2 = PlannerWorld(sc)
        _at(w2, w2.appear(lerr.cs) + 0.1)
        assert w2.flag(lerr.cs)[0] == "correct"
        f = w2.flights[lerr.cs]
        assert f.levels[-1] == f.xfl == f.shown_xfl and f.exit_ok()


def test_changes_only_before_the_aircraft_gets_there():
    sc = generate_planner(21, 5)
    w = PlannerWorld(sc)
    f = sc.flights[0]
    _at(w, f.entry_t + 0.1)
    assert w.apply(f.cs, delay=2.0)[:2] == (False, "tarde")
    assert w.apply(f.cs, levels=[f.levels[0] + 10] + f.levels[1:])[:2] == (False, "tarde")
    g = next(x for x in sc.flights if x.entry_t > w.t + 2 and w.visible(x.cs))
    ok, msg, eff = w.apply(g.cs, delay=1.0)
    assert ok and w.flights[g.cs].t_entry == g.entry_t + 1.0
    assert w.apply(g.cs, delay=1.0)[:2] == (False, "=")


def test_last_segment_changed_breaks_the_exit_and_created_conflicts_count():
    sc = generate_planner(31, 3)
    w = PlannerWorld(sc)
    f = next(x for x in sc.flights if not x.err and all(x.cs not in p for p in sc.designed))
    _at(w, w.appear(f.cs) + 0.1)
    lv = list(w.flights[f.cs].levels)
    lv[-1] += 10
    ok, _, _ = w.apply(f.cs, levels=lv)
    assert ok
    while not w.finished:
        w.advance(0.5)
    r = compute_planner_result(w)
    assert r.exits_checked == 1 and r.exits_ok == 0
    assert r.components["Salida"] == {"correct": 0, "wrong": 1, "blank": 0}
    assert any("XFL" in t for t, _ in r.breakdown)


def test_a_conflict_created_by_the_player_is_a_loss_marked_created():
    sc = generate_planner(8, 1)
    w = PlannerWorld(sc)
    # make one free aircraft meet another one: same level, same entry gate, same time
    free = [f for f in sc.flights if all(f.cs not in p for p in sc.designed) and not f.err]
    a, b = free[0], free[1]
    _at(w, max(w.appear(a.cs), w.appear(b.cs)) + 0.1)
    if w.flights[b.cs].t_entry <= w.t:
        pytest.skip("strip already entered")
    fb = w.flights[b.cs]
    found = False
    for d in range(0, 40):
        for lv in LEVELS_BY_PARITY["par"] + LEVELS_BY_PARITY["impar"]:
            ok, _, eff = w.apply(b.cs, delay=float(d), levels=[lv] * len(fb.levels))
            if ok and eff.get("created"):
                found = True
                break
        if found:
            break
    assert found
    while not w.finished:
        w.advance(0.5)
    r = compute_planner_result(w)
    assert r.created >= 1 and r.lost >= r.created


def test_resolution_cost_within_allowance_costs_nothing_and_excess_costs_points():
    w, r = run_core(4, 55)
    assert not any("Coste" in t for t, _ in r.breakdown)
    sc = generate_planner(55, 4)
    w = PlannerWorld(sc)
    for f in sc.flights:                                  # hold every aircraft 8 minutes: needless delay
        _at(w, w.appear(f.cs) + 0.05)
        if w.flights[f.cs].t_entry > w.t:
            w.apply(f.cs, delay=8.0)
    while not w.finished:
        w.advance(0.5)
    r = compute_planner_result(w)
    assert r.delay_min >= 8.0 * 5
    assert any("Coste" in t and v == -15.0 for t, v in r.breakdown)


def test_best_plan_finds_a_two_step_fix_when_one_is_not_enough():
    slow = mk("SLO1", ["SOLBE", "CUREL", "BOLMA", "ESTAN"], 240, 10.0, 310)
    fast = mk("FST1", ["SOLBE", "CUREL", "BOLMA", "ESTAN"], 480, 18.0, 310)
    by = {slow.cs: slow, fast.cs: fast}
    p = pair_key(slow.cs, fast.cs)
    assert p in find_conflicts([slow, fast])
    plan = best_plan(by, p, 0.0)
    assert plan
    for a in plan:
        f = by[a.cs]
        f.delay, f.route_i, f.levels = a.delay, a.route_i, list(a.levels)
    assert p not in find_conflicts([slow, fast])


# ---- spoken task inside the planner ---------------------------------------------------------------------------
def test_spoken_task_runs_with_the_planner_and_never_changes_its_items():
    from atcsim.core.audio_task import AudioTask
    w1, r1 = run_core(5, 64, audio=AudioTask("sum", 5, 64))
    w2, r2 = run_core(5, 64)
    assert r1.audio and r1.audio["n"] > 5 and r1.audio["wrong"] == 0
    assert r1.audio["blank"] <= 1                         # only an item cut by the end of the run
    assert (r1.correct, r1.wrong, r1.blank, r1.score) == (r2.correct, r2.wrong, r2.blank, r2.score)
    assert r2.audio is None
    w = PlannerWorld(generate_planner(64, 5), audio=AudioTask("code", 5, 64))
    t0 = w.audio.t
    w.advance(0)                                          # no time passes while paused (the screen does not advance)
    assert w.audio.t == t0
    w.advance(30.0)
    assert w.audio.t == pytest.approx(t0 + 30.0)


# ---- ladder ---------------------------------------------------------------------------------------------------
def test_ladder_is_monotonic():
    L = PLANNER_LEVELS
    assert [s.level for s in L] == list(range(1, 11))
    for a, b in zip(L, L[1:]):
        assert b.n_flights > a.n_flights and b.conflicts >= a.conflicts and b.coord_errors >= a.coord_errors
        assert b.rs_per_min < a.rs_per_min and b.lead_min <= a.lead_min
        assert b.show_etos <= a.show_etos and b.check_aid <= a.check_aid
    load = [s.conflicts / ((s.window_min + 18) * s.rs_per_min / 60.0) for s in L]
    assert all(y > x for x, y in zip(load, load[1:]))           # conflicts per real minute rise at every step


def test_difficulty_rises_for_a_capacity_limited_player():
    acc = {}
    for lv in (2, 5, 8):
        vals = [run_core(lv, s, perfect=False, scan_per_s=0.5, p_slip=0.05, bot_seed=s)[1].accuracy
                for s in (301, 302, 303)]
        acc[lv] = sum(vals) / len(vals)
    assert acc[2] > acc[5] > acc[8], acc


def test_adaptive_rule_is_the_same_as_the_radar_modes():
    s = {"level": 1, "ok": 0, "bad": 0}
    s = adaptive_update(s, True)
    s = adaptive_update(s, True)
    assert s["level"] == 2


# ---- save and load --------------------------------------------------------------------------------------------
def test_old_stats_file_loads_and_exports_as_before(tmp_path):
    old = {"version": 2, "runs": [{"ts": 1.7e9, "mode": "Ladder", "level": 3, "seed": 5, "correct": 8, "wrong": 1,
                                   "blank": 1, "spi": 9.0, "accuracy": 80.0, "goal": "g", "met": False}],
           "adaptive": {"level": 2, "ok": 1, "bad": 0}}
    p = tmp_path / "sim_stats.json"
    p.write_text(json.dumps(old), encoding="utf-8")
    st = StatsStore(str(p))
    assert st.data["planner_runs"] == [] and st.data["planner_adaptive"] == {"level": 1, "ok": 0, "bad": 0}
    assert st.data["planner_best"] == {} and len(st.data["runs"]) == 1
    assert runs_to_csv(st.data["runs"], st.data["audio_solo"], st.data["planner_runs"]) == runs_to_csv(st.data["runs"])


def test_the_real_personal_stats_file_still_loads(tmp_path):
    src = os.path.join(SIM, "sim_stats.json")
    if not os.path.exists(src):
        pytest.skip("no personal stats file here")
    dst = tmp_path / "copy.json"
    shutil.copyfile(src, dst)                             # read a copy: the personal file is never opened for writing
    raw = json.loads(dst.read_text(encoding="utf-8"))
    st = StatsStore(str(dst))
    assert not st.warning
    assert len(st.data["runs"]) == len(raw.get("runs", []))
    assert st.data["planner_runs"] == []


def test_planner_run_round_trip_csv_and_malformed_rows(tmp_path):
    from atcsim.core.audio_task import AudioTask
    path = str(tmp_path / "s.json")
    st = StatsStore(path)
    w, r = run_core(5, 64, audio=AudioTask("sum", 5, 64))
    r.mode = "Adaptive"
    rec = st.add_planner_run(r, ts=1.8e9, voice="es")
    st.data["planner_runs"].append({"ts": "bad"})
    st.data["planner_runs"].append({"ts": 1.8e9, "level": 3})
    st.save()
    st2 = StatsStore(path)
    assert len(st2.data["planner_runs"]) == 1
    got = st2.data["planner_runs"][0]
    for k in ("level", "seed", "correct", "wrong", "blank", "score", "found", "missed", "false_alarms", "lost",
              "coord_errors", "coord_flagged", "exits_ok", "decisions", "cost_units", "ref_cost"):
        assert got[k] == rec[k], k
    assert got["audio"]["variant"] == "sum" and got["audio"]["voice"] == "es"
    assert st2.data["planner_best"]["5"]["score"] == 100.0
    csv = runs_to_csv(st2.data["runs"], st2.data["audio_solo"], st2.data["planner_runs"])
    lines = csv.strip("\r\n").split("\r\n")
    assert lines[0] == ";".join(CSV_COLUMNS)
    row = lines[1].split(";")
    assert len(row) == 10 and row[1] == "Strip Planner (Adaptive)" and row[2] == "5"
    assert row[6] == f"{rec['s_decision']:.2f}" and row[7] == "100.0" and row[9] == "Yes"
    au = lines[2].split(";")
    assert au[1] == "Spoken task: digit sums (with planner)" and len(au) == 10
    assert "Radar Sector Sim" not in csv
    out = tmp_path / "x.csv"
    assert st2.export_csv(str(out))
    assert "Strip Planner (Adaptive)" in out.read_text(encoding="utf-8-sig")


def test_solo_baseline_sets_the_cost_of_a_planner_run(tmp_path):
    from atcsim.core.audio_task import AudioTask
    st = StatsStore(str(tmp_path / "s.json"))
    w, r = run_core(5, 64, audio=AudioTask("sum", 5, 64))
    st.add_planner_run(r, ts=1.8e9)
    solo = dict(r.audio)
    solo["accuracy"] = 100.0
    st.add_audio_solo(solo, seed=64, ts=1.8e9 + 60)
    assert st.data["planner_runs"][-1]["audio"]["cost"]["cost_points"] == pytest.approx(100.0 - r.audio["accuracy"])


# ---- UI (headless, real key and mouse events) -----------------------------------------------------------------
def _app(tmp_path):
    from play_ui import new_app
    return new_app(str(tmp_path))


def test_ui_full_run_perfect_bot_saves_and_exports(tmp_path):
    import pygame
    from play_ui import key, play_planner, start_planner_ui
    from atcsim.ui.planner_ui import PlannerDebriefScreen
    from atcsim.ui.screens import MenuScreen
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    start_planner_ui(app, 2, seed=4242)
    n, wall, worst, bot = play_planner(app, dict(seed=1))
    assert isinstance(app.screen, PlannerDebriefScreen)
    assert bot.mismatch == 0 and bot.method_count["click"] > 0
    r = app.screen.r
    assert r.score == 100.0 and r.met and r.audio and r.audio["n"] > 0
    assert len(app.stats.data["planner_runs"]) == 1 and app.stats.data["runs"] == []
    for k in (pygame.K_2, pygame.K_3, pygame.K_1):
        key(app, k)
        app.screen.draw(app.surface)
    key(app, pygame.K_e)
    assert app.screen.msg.endswith(".csv") and os.path.exists(app.screen.msg)
    with open(app.screen.msg, encoding="utf-8-sig") as f:
        assert "Strip Planner (Ladder);2;" in f.read()
    key(app, pygame.K_ESCAPE)
    assert isinstance(app.screen, MenuScreen) and app.screen.plevel == 2


def test_ui_adaptive_mode_moves_up_after_two_clean_runs(tmp_path):
    import pygame
    from play_ui import key, play_planner, start_planner_ui
    app = _app(tmp_path)
    for i in range(2):
        start_planner_ui(app, 1, seed=500 + i, adaptive=True)
        play_planner(app, dict(seed=i))
        assert app.screen.r.met
        key(app, pygame.K_ESCAPE)
    assert app.stats.data["planner_adaptive"]["level"] == 2
    assert app.stats.data["adaptive"] == {"level": 1, "ok": 0, "bad": 0}         # the radar ladder is untouched


def test_ui_keys_declare_flag_change_pause_help_abandon(tmp_path):
    import pygame
    from play_ui import click, key, start_planner_ui
    from atcsim.ui.planner_ui import PlannerScreen
    from atcsim.ui.screens import MenuScreen
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "off"
    start_planner_ui(app, 3, seed=99)
    scr = app.screen
    w = scr.w
    assert w.audio is None
    # wait until a designed pair is on the board
    p = min(w.designed, key=lambda q: w.designed[q].t)
    while not (w.visible(p[0]) and w.visible(p[1])):
        app.frame(0.1, draw=False)
    scr.draw(app.surface)
    rows = dict((cs, r) for r, cs in scr.rows)
    click(app, (rows[p[0]].x + 40, rows[p[0]].centery))
    assert scr.sel == p[0]
    key(app, pygame.K_c, "c")
    assert scr.pick == p[0]
    click(app, (rows[p[1]].x + 40, rows[p[1]].centery))
    key(app, pygame.K_c, "c")
    assert p in w.declared and scr.pick is None
    # level of a segment: arrows + Enter
    f = w.flights[p[1]]
    seg = scr.seg
    before = list(f.levels)
    key(app, pygame.K_UP)
    assert scr.pend["levels"][seg] == before[seg] + 10 and f.levels == before     # nothing changes before Enter
    key(app, pygame.K_ESCAPE)
    assert scr.pend is None
    key(app, pygame.K_UP)
    key(app, pygame.K_RETURN)
    assert f.levels[seg] == before[seg] + 10 and len(w.edits) == 1
    # delay and route on a strip that has not entered yet
    g = next((x for x in w.on_board() if w.editable(x)["delay"]), None)
    if g is not None:
        scr.select(g)
        key(app, pygame.K_PLUS, "+")
        key(app, pygame.K_PLUS, "+")
        key(app, pygame.K_MINUS, "-")
        key(app, pygame.K_RETURN)
        assert w.flights[g].delay == 1.0
        if len(w.flights[g].routes) > 1:
            key(app, pygame.K_r, "r")
            key(app, pygame.K_RETURN)
            assert w.flights[g].route_i == 1
    # help overlay, pause freezes the clock, Esc menu, abandon saves nothing
    key(app, pygame.K_F1)
    assert scr.help
    scr.draw(app.surface)
    key(app, pygame.K_F1)
    key(app, pygame.K_p)
    t = w.t
    for _ in range(20):
        app.frame(0.1, draw=False)
    assert w.t == t and w.pauses == 1
    scr.draw(app.surface)
    key(app, pygame.K_p)
    key(app, pygame.K_ESCAPE)                 # deselect
    key(app, pygame.K_ESCAPE)                 # pause menu
    assert scr.pause_menu
    key(app, pygame.K_q)
    app.frame(0.0, draw=False)
    assert isinstance(app.screen, MenuScreen)
    assert app.stats.data["planner_runs"] == []


def test_ui_spoken_task_keys_in_the_planner(tmp_path):
    import pygame
    from play_ui import key, start_planner_ui
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    start_planner_ui(app, 4, seed=12)
    scr = app.screen
    au = scr.w.audio
    assert au is not None and au.variant == "sum"
    while au.open_item is None or au.t < au.open_item.end:
        app.frame(0.1, draw=False)
    it = au.open_item
    key(app, pygame.K_v, "v")
    for ch in str(it.truth):
        key(app, pygame.K_0 + int(ch), ch)
    scr.draw(app.surface)
    key(app, pygame.K_RETURN)
    assert it.outcome == "correct"
    t = scr.w.t
    app.frame(0.5, draw=False)
    assert scr.w.t > t                         # the board kept running


def test_menu_plan_rows(tmp_path):
    import pygame
    from play_ui import key
    from atcsim.ui.planner_ui import PlannerBriefingScreen
    from atcsim.ui.screens import PLAN_AD_ROW, PLAN_ROW
    app = _app(tmp_path)
    m = app.screen
    m.sel = PLAN_ROW
    key(app, pygame.K_RIGHT)
    key(app, pygame.K_RIGHT)
    assert m.plevel == 3
    key(app, pygame.K_7, "7")
    assert m.plevel == 7
    m.draw(app.surface)
    m.sel = PLAN_AD_ROW
    m.draw(app.surface)
    key(app, pygame.K_RETURN)
    assert isinstance(app.screen, PlannerBriefingScreen) and app.screen.mode == "Adaptive" and app.screen.level == 1
    key(app, pygame.K_F1)
    app.screen.draw(app.surface)
    key(app, pygame.K_ESCAPE)
    assert app.screen.sel == PLAN_AD_ROW
    key(app, pygame.K_ESCAPE)
    assert app.screen.items()[-1][0] == "Quit" and app.screen.sel == len(app.screen.items()) - 1
