import pytest

from atcsim.core.scenario import LEVELS, level_spec
from atcsim.core.scoring import RunResult, adaptive_update, compute_result, default_adaptive
from atcsim.core.tasks import TTC_BUCKETS, ttc_bucket
from atcsim.core.world import World
from conftest import scenario, spec, world

WE = ["LUNDA", "VELAR", "MIDAS", "REGAL", "NERVA"]


def two_way(alt_b=30000.0, tasks=False, level=5):
    a = spec("AAA1", WE, alt=30000, tas=300)
    b = spec("BBB2", list(reversed(WE)), alt=alt_b, tas=300)
    w = world([a, b], tasks=tasks, level=level)
    w.readbacks = False      # tests create their own read-back tasks
    return w


def finish(w):
    while not w.finished:
        w.advance(1.0)
    return w


# ---- tasks ------------------------------------------------------------------------------
def test_ttc_buckets_edges():
    assert [ttc_bucket(s) for s in (0, 59.9, 60, 119.9, 120, 179.9, 180, 239.9, 240, 900)] == [0, 0, 1, 1, 2, 2, 3, 3, 4, 4]
    assert len(TTC_BUCKETS) == 6


def test_task_expiry_counts_blank_and_answer_after_expiry_is_ignored():
    w = two_way(tasks=True)
    w.advance(2.0)
    ok, _, cl = w.issue("AAA1", hdg=300)
    t = w.tasks.create_readback(cl, "heading 300", False)
    assert t.is_open and t.correct == 0
    w.advance(t.time_total + 1.0)
    assert not t.is_open and t.outcome == "blank"
    assert w.tasks.answer(t.id, 0) is None
    assert w.task_stats["readback"]["blank"] == 1


def test_task_correct_wrong_and_double_answer():
    w = two_way(tasks=True)
    w.advance(2.0)
    _, _, cl = w.issue("AAA1", hdg=300)
    t = w.tasks.create_readback(cl, "heading 300", False)
    assert w.tasks.answer(t.id, 5) is None            # out-of-range choice rejected, task still open
    assert t.is_open
    assert w.tasks.answer(t.id, 1).outcome == "wrong"
    assert w.tasks.answer(t.id, 0) is None            # cannot answer twice
    assert w.task_stats["readback"] == {"correct": 0, "wrong": 1, "blank": 0}


def test_wrong_readback_flagged_fixes_heading_missed_keeps_wrong():
    w = two_way(tasks=True)
    w.advance(2.0)
    ok, _, cl = w.issue("AAA1", hdg=100)
    ac = w.aircraft["AAA1"]
    # force a misheard read-back: apply 130 as if the pilot misheard, then the controller flags it
    ac.set_heading(130)
    cl.wrong_field, cl.heard = "hdg", "heading 130"
    t = w.tasks.create_readback(cl, "heading 130", True)
    assert t.correct == 1
    w.tasks.answer(t.id, 1)                            # "Incorrect": the pilot is told again
    assert ac.tgt_hdg == 100
    # second case: not flagged
    ok, _, cl2 = w.issue("AAA1", hdg=200)
    ac.set_heading(230)
    cl2.wrong_field, cl2.heard = "hdg", "heading 230"
    t2 = w.tasks.create_readback(cl2, "heading 230", True)
    w.tasks.answer(t2.id, 0)
    assert ac.tgt_hdg == 230 and cl2.uncorrected


def test_level_request_correct_answer_reflects_safety():
    w = two_way(alt_b=32000.0, tasks=True)
    for _ in range(400):
        w.advance(1.0)
    assert w.level_change_is_safe("AAA1", 28000)
    assert not w.level_change_is_safe("AAA1", 32000)


def test_finish_marks_open_tasks_blank():
    w = two_way(tasks=True)
    w.advance(2.0)
    _, _, cl = w.issue("AAA1", hdg=300)
    t = w.tasks.create_readback(cl, "heading 300", False)
    w.finish()
    assert t.outcome == "blank" and w.finished


# ---- scoring ----------------------------------------------------------------------------
def test_empty_run_has_zero_items_no_division_by_zero():
    w = world([spec("A", WE)])
    r = compute_result(w)
    assert r.items == 0 and r.accuracy == 0.0 and r.seconds_per_item == 0.0
    assert r.met is False and r.score == 100.0
    assert r.worst_component() is None


def test_single_correct_handoff_without_transfer_is_half_accuracy():
    a = spec("AAA1", WE, alt=30000, tas=300)
    w = world([a], tasks=False)
    finish(w)
    r = compute_result(w)
    # one handoff at the right gate and level, one blank transfer
    assert r.correct == 1 and r.blank == 1 and r.wrong == 0
    assert not r.met                                  # 50 % < goal
    assert r.losses == 0


def test_loss_penalty_depends_on_depth_and_counts_wrong_item():
    r = compute_result(finish(two_way()))
    assert r.losses == 1
    assert r.components["Separation"] == {"correct": 0, "wrong": 1, "blank": 0}
    pen = [v for (txt, v) in r.breakdown if txt.startswith("Loss of separation")][0]
    assert pen == pytest.approx(-(10 + 12 * (1 - r.breakdown[0][1] * 0)) , abs=3.0) or -22.0 <= pen <= -10.0
    assert -22.0 <= pen <= -10.0
    assert r.score <= 100 - 10


def test_resolved_conflict_counts_correct():
    w = two_way()
    for _ in range(400):
        w.advance(1.0)
    assert w.predicted
    w.issue("AAA1", hdg=w.aircraft["AAA1"].hdg + 40, turn_dir="R")
    finish(w)
    r = compute_result(w)
    assert r.losses == 0
    assert r.components["Separation"]["correct"] == 1
    assert r.components["Separation"]["wrong"] == 0


def test_seconds_per_item_and_accuracy():
    r = RunResult(5, 1, "Ladder", correct=8, wrong=1, blank=1, real_seconds=50.0)
    assert r.items == 10 and r.accuracy == 80.0 and r.seconds_per_item == 5.0


def test_thirds_partition_all_items():
    r = compute_result(finish(two_way()))
    assert len(r.thirds) == 3


def test_unneeded_instruction_penalty_capped():
    w = world([spec("A", WE)])
    w.advance(3.0)
    for i in range(30):
        w.issue("A", spd=280 + (i % 2) * 10)
    finish(w)
    r = compute_result(w)
    assert r.unneeded >= 20
    pen = [v for (txt, v) in r.breakdown if "no predicted need" in txt][0]
    assert pen == -8.0


def test_adaptive_ladder_rules():
    s = default_adaptive()
    s = adaptive_update(s, True)
    assert s == {"level": 1, "ok": 1, "bad": 0}
    s = adaptive_update(s, True)
    assert s["level"] == 2 and s["ok"] == 0
    s = {"level": 5, "ok": 0, "bad": 0}
    for _ in range(2):
        s = adaptive_update(s, True)
    assert s["level"] == 5 and s["ok"] == 2           # levels 5+ need 3
    s = adaptive_update(s, True)
    assert s["level"] == 6
    s = adaptive_update(s, False)
    assert s == {"level": 6, "ok": 0, "bad": 1}
    s = adaptive_update(s, True)
    assert s["bad"] == 0                              # a success resets the failure streak
    s = adaptive_update(s, False)
    s = adaptive_update(s, False)
    assert s["level"] == 5 and s["bad"] == 0
    assert adaptive_update({"level": 1, "ok": 0, "bad": 1}, False)["level"] == 1   # never below 1
    assert adaptive_update({"level": 10, "ok": 2, "bad": 0}, True)["level"] == 10  # never above 10
    assert adaptive_update(s, True, assisted=True) == s                              # assisted runs do not count


def test_level_table_is_a_ladder():
    assert [l.level for l in LEVELS] == list(range(1, 11))
    for a, b in zip(LEVELS, LEVELS[1:]):
        assert b.n_aircraft > a.n_aircraft
        assert b.scale >= a.scale
        assert b.design_conflicts >= a.design_conflicts
        assert b.task_gap_s < a.task_gap_s
        assert b.aids <= a.aids
        assert b.task_deadline_s <= a.task_deadline_s
    assert level_spec(0).level == 1 and level_spec(99).level == 10


def test_ttc_task_includes_no_conflict_near_miss_and_correct_buckets():
    """A pair passing 7 NM apart is a near miss (answer 'No conflict'); a pair passing 2 NM apart is a real conflict
    whose answer is the minute bucket of its predicted time to loss."""
    from conftest import make_ac
    from atcsim.core.tasks import ttc_bucket
    w = world([spec("X", WE)], tasks=True, level=5)
    w.aircraft.clear()
    for ac in (make_ac("A", -25, 0, hdg=90, tas=360), make_ac("B", 25, 7, hdg=270, tas=360),          # near miss: 7 NM
               make_ac("C", -25, 30, hdg=90, tas=360), make_ac("D", 25, 32, hdg=270, tas=360)):      # conflict: 2 NM
        w.aircraft[ac.callsign] = ac
    w._refresh_prediction()
    assert {c.pair for c in w.predicted} == {("C", "D")}
    kinds = set()
    for _ in range(80):
        w.tasks.tasks.clear()
        t = w.tasks._create_ttc()
        assert t is not None
        if t.data.get("near_miss"):
            assert t.data["pair"] == ("A", "B")
            assert t.correct == len(t.options) - 1 and t.options[t.correct] == "No conflict"
            kinds.add("near")
        else:
            assert t.data["pair"] == ("C", "D")
            assert t.correct == ttc_bucket(t.data["t_start"])
            kinds.add("real")
    assert kinds == {"near", "real"}
