import math

import pytest

from atcsim.core import geometry as g


def test_norm360():
    assert g.norm360(-10) == 350
    assert g.norm360(360) == 0
    assert g.norm360(725) == 5
    assert g.norm360(0) == 0


@pytest.mark.parametrize("target,cur,expected", [
    (10, 350, 20), (350, 10, -20), (180, 0, 180), (0, 180, 180), (90, 90, 0), (1, 359, 2), (270, 90, 180),
])
def test_angle_diff(target, cur, expected):
    assert g.angle_diff(target, cur) == pytest.approx(expected)


def test_angle_diff_range():
    for a in range(0, 360, 7):
        for b in range(0, 360, 11):
            d = g.angle_diff(a, b)
            assert -180 < d <= 180
            assert g.norm360(b + d) == pytest.approx(g.norm360(a), abs=1e-9)


def test_vectors():
    assert g.vec_from_hdg(90, 100) == pytest.approx((100, 0), abs=1e-9)
    assert g.vec_from_hdg(180, 100) == pytest.approx((0, -100), abs=1e-9)
    assert g.hdg_from_vec(1, 1) == pytest.approx(45)
    assert g.hdg_from_vec(-1, 0) == pytest.approx(270)
    assert g.hdg_from_vec(0, 0) == 0


def test_bearing_and_dist():
    assert g.bearing((0, 0), (0, 10)) == 0
    assert g.bearing((0, 0), (10, 0)) == 90
    assert g.dist((0, 0), (3, 4)) == 5


def test_point_in_polygon():
    sq = [(0, 0), (10, 0), (10, 10), (0, 10)]
    assert g.point_in_polygon((5, 5), sq)
    assert not g.point_in_polygon((11, 5), sq)
    assert not g.point_in_polygon((5, -0.1), sq)
    tri = [(0, 0), (10, 0), (0, 10)]
    assert g.point_in_polygon((2, 2), tri)
    assert not g.point_in_polygon((8, 8), tri)


def test_segment_intersection():
    hit = g.segment_intersection((0, 0), (10, 10), (0, 10), (10, 0))
    assert hit is not None
    u, v, p = hit
    assert (u, v) == (pytest.approx(0.5), pytest.approx(0.5))
    assert p == pytest.approx((5, 5))
    assert g.segment_intersection((0, 0), (1, 1), (5, 0), (5, 10)) is None
    assert g.segment_intersection((0, 0), (10, 0), (0, 1), (10, 1)) is None  # parallel


def test_closest_approach_hand_computed():
    # guide example: relative position (30,30) NM, relative velocity (-5,-5) NM/min -> CPA at 6 min, distance 0
    t, d = g.closest_approach(30, 30, -5, -5)
    assert t == pytest.approx(6.0) and d == pytest.approx(0.0, abs=1e-9)
    t, d = g.closest_approach(10, 0, 1, 0)      # diverging: clamps to t = 0
    assert t == 0 and d == 10
    assert g.closest_approach(3, 4, 0, 0) == (0.0, 5.0)


def test_interval_inside_circle_matches_guide_example():
    # phase2 guide: distance = 1.414 * |30 - 5t|; equals 5 NM at t = 6 -/+ 0.7071 min
    iv = g.interval_inside_circle(30, 30, -5, -5, 5.0, 0, 20)
    assert iv is not None
    assert iv[0] == pytest.approx(6 - 5 / (5 * math.sqrt(2)), abs=1e-9)   # 5.2929
    assert iv[1] == pytest.approx(6 + 0.7071067, abs=1e-6)
    assert g.interval_inside_circle(30, 0, 0, 5, 5.0, 0, 100) is None      # passes 30 NM away


def test_interval_abs_below():
    assert g.interval_abs_below(0, 0, 1000, 0, 10) == (0, 10)
    assert g.interval_abs_below(2000, 0, 1000, 0, 10) is None
    lo, hi = g.interval_abs_below(3000, -100, 1000, 0, 100)
    assert (lo, hi) == (pytest.approx(20), pytest.approx(40))


def test_heading_for_track_hand_computed():
    # wind from 270 at 30 kt, TAS 300, track 000: WCA = asin(30/300) = 5.739 deg into the wind (west)
    hdg, gs = g.heading_for_track(0, 300, 270, 30)
    assert hdg == pytest.approx(360 - math.degrees(math.asin(0.1)), abs=1e-9)
    assert gs == pytest.approx(300 * math.cos(math.asin(0.1)), abs=1e-9)
    hdg, gs = g.heading_for_track(0, 300, 180, 40)     # pure tailwind
    assert hdg == pytest.approx(0, abs=1e-9) and gs == pytest.approx(340)
    hdg, gs = g.heading_for_track(0, 300, 0, 40)       # headwind
    assert gs == pytest.approx(260)
    assert g.heading_for_track(0, 100, 270, 150) is None


def test_heading_for_track_makes_good_the_track():
    for track in range(0, 360, 25):
        for wf in range(0, 360, 40):
            r = g.heading_for_track(track, 250, wf, 35)
            assert r is not None
            hdg, gs = r
            vx, vy = g.vec_from_hdg(hdg, 250)
            wx, wy = g.wind_vector(wf, 35)
            assert abs(g.angle_diff(g.hdg_from_vec(vx + wx, vy + wy), track)) < 1e-6
            assert math.hypot(vx + wx, vy + wy) == pytest.approx(gs, abs=1e-6)
