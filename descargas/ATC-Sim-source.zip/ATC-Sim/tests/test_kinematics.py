import math

import pytest

from atcsim.core.aircraft import Aircraft
from atcsim.core.geometry import angle_diff, dist
from atcsim.core.perf import turn_rate
from conftest import make_ac


def run(ac, seconds, wf=0.0, ws=0.0, dt=1.0):
    for _ in range(int(round(seconds / dt))):
        ac.step(dt, wf, ws)


def test_turn_rate_hand_computed():
    # omega = g tan(25 deg) / v; at 250 kt (128.611 m/s): 4.5728 / 128.611 rad/s = 2.0372 deg/s
    assert turn_rate(250) == pytest.approx(2.0372, abs=1e-3)
    assert turn_rate(120) == 3.0     # capped at rate one
    assert turn_rate(450) < turn_rate(250)


def test_straight_flight_distance():
    a = make_ac(hdg=0, tas=300)
    run(a, 60)
    assert (a.x, a.y) == pytest.approx((0.0, 5.0), abs=1e-9)     # 300 kt = 5 NM/min
    b = make_ac(hdg=90, tas=240)
    run(b, 900)
    assert (b.x, b.y) == pytest.approx((60.0, 0.0), abs=1e-9)


def test_wind_drift_hand_computed():
    a = make_ac(hdg=0, tas=300)
    run(a, 3600, wf=270, ws=30)     # wind from the west pushes 30 NM east in an hour
    assert a.x == pytest.approx(30.0, abs=1e-6)
    assert a.y == pytest.approx(300.0, abs=1e-6)
    assert a.ground_speed((30, 0)) == pytest.approx(math.hypot(300, 30))


def test_ninety_degree_turn_duration_and_radius():
    a = make_ac(hdg=0, tas=250)
    a.set_heading(90)
    ticks = 0
    while abs(angle_diff(90, a.hdg)) > 1e-9 and ticks < 200:
        a.step(1.0)
        ticks += 1
    assert ticks == 45          # 90 / 2.0372 = 44.18 s -> 45 one-second ticks
    R = 250.0 / (math.radians(turn_rate(250)) * 3600.0)   # radius = v / omega
    assert R == pytest.approx(1.953, abs=0.005)
    # the last 1 s tick only needs 0.18 s of turning, then flies straight east for the remaining 0.82 s
    t_turn = 90.0 / turn_rate(250)
    extra = (45 - t_turn) * 250.0 / 3600.0
    assert a.y == pytest.approx(R, abs=0.01)
    assert a.x == pytest.approx(R + extra, abs=0.01)


def test_full_circle_returns_to_start():
    a = make_ac(hdg=1.0, tas=250)
    a.set_heading(0, "R")       # forced right turn from 001 to 000 is 359 degrees
    steps = 0
    while a.turn_dir is not None and steps < 2000:
        a.step(0.5)
        steps += 1
    assert steps * 0.5 == pytest.approx(359.0 / turn_rate(250), abs=1.0)
    assert dist((a.x, a.y), (0, 0)) < 0.2


def test_forced_direction_takes_long_way():
    a = make_ac(hdg=350, tas=300)
    a.set_heading(10, "L")
    t = 0
    while a.turn_dir is not None:
        a.step(1.0)
        t += 1
    assert t == pytest.approx(340.0 / turn_rate(300), abs=1.5)


def test_climb_descend_rates():
    a = make_ac(alt=30000, code="A320")
    a.set_altitude(33000)
    run(a, 60)
    assert a.alt == pytest.approx(30000 + 2200, abs=1e-6)
    run(a, 25)   # 3000 ft at 2200 fpm = 81.82 s
    assert a.alt == 33000
    a.set_altitude(31000)
    run(a, 30)   # descent 2400 fpm = 40 ft/s, 30 s = 1200 ft
    assert a.alt == pytest.approx(33000 - 1200)


def test_acceleration_and_limits():
    a = make_ac(tas=300, code="A320")
    a.set_speed(350)
    run(a, 30)
    assert a.tas == pytest.approx(330)          # 1 kt/s
    run(a, 40)
    assert a.tas == 350
    a.set_speed(900)
    assert a.tgt_tas == 470                      # clamped to the type maximum
    a.set_speed(10)
    assert a.tgt_tas == 220


def test_nav_follows_route_with_wind_and_captures():
    route = (("A", 0.0, 0.0), ("B", 0.0, 20.0), ("C", 20.0, 20.0))
    a = Aircraft("N1", "B738", 0, 0, 30000, 0, 300, 30000, 300, route=route, route_idx=1, nav=True)
    a.hdg = a.desired_heading(270, 30)
    assert 340 < a.hdg < 360    # crabbed west of north
    xs = []
    for _ in range(300):
        a.step(1.0, 270, 30)
        xs.append(a.x)
        if a.route_idx >= 2:
            break
    assert a.route_idx == 2     # captured B
    assert max(abs(x) for x in xs[:150]) < 0.35    # stayed on the line x = 0


def test_direct_to_and_resume():
    route = (("A", 0.0, 0.0), ("B", 0.0, 20.0), ("C", 20.0, 20.0))
    a = Aircraft("N1", "B738", 0, 0, 30000, 0, 300, 30000, 300, route=route, route_idx=1, nav=True)
    a.set_heading(90)
    assert a.nav is False
    a.resume_nav()
    assert a.nav is True and a.route_idx == 1
    assert a.direct_to("C") and a.route_idx == 2
    assert not a.direct_to("ZZZ")


def test_copy_is_independent():
    a = make_ac()
    b = a.copy()
    b.step(10)
    b.flags["x"] = 1
    assert a.y == 0 and "x" not in a.flags


def test_resume_skips_waypoints_already_passed():
    route = (("A", 0.0, 0.0), ("B", 0.0, 20.0), ("C", 20.0, 20.0), ("D", 20.0, 0.0))
    a = Aircraft("N1", "B738", 30.0, 22.0, 30000, 90, 300, 30000, 300, route=route, route_idx=1, nav=False)
    a.resume_nav()
    # hand check: past B along B->C (offset (30,2) . (20,0) > 0) but not yet past C along C->D (offset (10,2) . (0,-20) < 0)
    assert a.route_idx == 2 and a.nav
    b = Aircraft("N2", "B738", -5.0, 10.0, 30000, 0, 300, 30000, 300, route=route, route_idx=1, nav=False)
    b.resume_nav()
    assert b.route_idx == 1                # B is still ahead
    c = Aircraft("N3", "B738", 20.0, -5.0, 30000, 180, 300, 30000, 300, route=route, route_idx=3, nav=False)
    c.resume_nav()
    assert c.route_idx == 3 and c.nav      # last waypoint: never skipped
