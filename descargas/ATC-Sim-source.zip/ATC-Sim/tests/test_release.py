"""Release hygiene: per-user data location, no writes into the source tree, short on-screen text, icon present."""
import os

import pytest

from atcsim.core import paths
from atcsim.core.persistence import StatsStore, default_path
from atcsim.core.tutorial import build_steps

PKG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def test_stats_default_path_is_per_user_not_in_package(monkeypatch, tmp_path):
    monkeypatch.setenv("SIM_DATA_DIR", str(tmp_path / "d"))
    p = default_path()
    assert os.path.dirname(p) == str(tmp_path / "d")
    assert os.path.isdir(os.path.dirname(p))


def test_default_data_dir_outside_source_tree(monkeypatch):
    monkeypatch.delenv("SIM_DATA_DIR", raising=False)
    d = os.path.abspath(paths.user_data_dir(create=False))
    assert not d.startswith(PKG)
    assert d.endswith(paths.APP_DIR)


def test_csv_export_goes_next_to_the_stats_file(tmp_path):
    from atcsim.ui.app import App
    app = App(headless=True, stats_path=str(tmp_path / "sim_stats.json"))
    p = app.export_csv()
    assert p and os.path.dirname(p) == str(tmp_path)


def test_tutorial_captions_are_short():
    for st in build_steps():
        assert len(st.text) <= 95, st.title
        assert len(st.title) <= 40


def test_icon_assets_exist():
    for n in ("icon.png", "icon.ico"):
        assert os.path.getsize(os.path.join(PKG, "assets", n)) > 1000


def test_window_minimise_pauses_run(tmp_path):
    import pygame
    from atcsim.ui.app import App, GameScreen
    app = App(headless=True, stats_path=str(tmp_path / "s.json"))
    app.start_run("Ladder", 1, 5)
    assert isinstance(app.screen, GameScreen)
    pygame.event.post(pygame.event.Event(pygame.WINDOWMINIMIZED))
    app.frame(0.1, draw=False)
    assert app.screen.s.paused


def test_empty_and_rapid_input_never_crash(tmp_path):
    import pygame
    from atcsim.ui.app import App
    app = App(headless=True, stats_path=str(tmp_path / "s.json"))
    app.start_run("Ladder", 2, 7)
    for k in [pygame.K_RETURN, pygame.K_h, pygame.K_RETURN, pygame.K_f, pygame.K_BACKSPACE, pygame.K_s, pygame.K_ESCAPE,
              pygame.K_t, pygame.K_r, pygame.K_TAB, pygame.K_RETURN, pygame.K_h, pygame.K_RETURN] * 20:
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k, mod=0, unicode=""))
    app.frame(0.05)
