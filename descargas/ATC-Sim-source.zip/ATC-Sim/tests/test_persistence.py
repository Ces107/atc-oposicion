import json
import os

import pytest

from atcsim.core.persistence import CSV_COLUMNS, StatsStore, result_to_record, runs_to_csv
from atcsim.core.scoring import RunResult


def result(level=3, c=8, w=1, b=1, secs=50.0, met=False):
    r = RunResult(level, 42, "Ladder", correct=c, wrong=w, blank=b, real_seconds=secs)
    r.goal_text = "accuracy >= 88% and 0 losses"
    r.met = met
    r.score = 77.5
    r.components = {"Separation": {"correct": 2, "wrong": 0, "blank": 0}}
    return r


def test_csv_header_exact():
    assert ";".join(CSV_COLUMNS) == "Date;Module;Level;Correct;Wrong;Blank;Seconds per item;Accuracy %;Goal;Met"


def test_round_trip(tmp_path):
    p = str(tmp_path / "s.json")
    st = StatsStore(p)
    rec = st.add_run(result(), ts=1_700_000_000.0)
    st2 = StatsStore(p)
    assert st2.data["runs"] == [rec] and st2.warning == ""
    assert st2.data["best"]["3"]["score"] == 77.5
    assert not os.path.exists(p + ".tmp")


def test_best_only_improves(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    st.add_run(result())
    lo = result()
    lo.score = 10
    st.add_run(lo)
    assert st.data["best"]["3"]["score"] == 77.5


def test_csv_content_and_bom(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    st.add_run(result(met=True), ts=1_700_000_000.0)
    out = str(tmp_path / "o.csv")
    assert st.export_csv(out)
    raw = open(out, "rb").read()
    assert raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig")
    lines = text.split("\r\n")
    assert lines[0] == "Date;Module;Level;Correct;Wrong;Blank;Seconds per item;Accuracy %;Goal;Met"
    f = lines[1].split(";")
    assert len(f) == 10
    assert f[2] == "3" and f[3] == "8" and f[4] == "1" and f[5] == "1"
    assert f[6] == "5.00" and f[7] == "80.0" and f[9] == "Yes"
    assert f[0][2] == "/" and f[0][5] == "/" and f[0][10] == " " and f[0][13] == ":"
    assert text.endswith("\r\n")


def test_csv_quotes_fields_with_separator():
    rec = result_to_record(result())
    rec["goal"] = 'a;b "c"'
    line = runs_to_csv([rec]).split("\r\n")[1]
    assert '"a;b ""c"""' in line


def test_corrupt_file_is_kept_and_replaced(tmp_path):
    p = tmp_path / "s.json"
    p.write_text("{ not json", encoding="utf-8")
    st = StatsStore(str(p))
    assert st.data["runs"] == [] and "unreadable" in st.warning
    assert any(n.startswith("s.json.corrupt-") for n in os.listdir(tmp_path))
    st.add_run(result())
    assert StatsStore(str(p)).data["runs"]


def test_non_object_json_handled(tmp_path):
    p = tmp_path / "s.json"
    p.write_text("[1,2,3]", encoding="utf-8")
    st = StatsStore(str(p))
    assert st.data["runs"] == []


def test_migration_from_version_1_and_bad_rows(tmp_path):
    p = tmp_path / "s.json"
    old = {"version": 1, "runs": [
        {"ts": 1.0, "level": 2, "correct": 5, "wrong": 1, "blank": 0},
        {"ts": "bad"},
        "junk",
        {"ts": 2.0, "level": 9, "correct": 1, "wrong": 1, "blank": 1, "met": True, "mode": "Adaptive"},
    ], "adaptive": {"level": 99, "ok": 1, "bad": 0}}
    p.write_text(json.dumps(old), encoding="utf-8")
    st = StatsStore(str(p))
    assert len(st.data["runs"]) == 2
    assert st.data["runs"][0]["mode"] == "Ladder" and st.data["runs"][0]["spi"] == 0.0
    assert st.data["adaptive"]["level"] == 10          # clamped
    assert st.data["version"] == 2


def test_unwritable_path_reports_warning(tmp_path):
    st = StatsStore(str(tmp_path / "no" / "such" / "dir" / "s.json"))
    ok = st.save()
    assert not ok and "Could not save" in st.warning
    assert st.data["runs"] == []            # in-memory data still usable
    st.add_run(result())
    assert len(st.data["runs"]) == 1


def test_seed_counter_and_streak(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    assert st.next_seed() == 1000 and st.next_seed() == 1001
    st.add_run(result(met=True))
    st.add_run(result(met=True))
    assert st.clean_streak() == 2
    st.add_run(result(met=False))
    assert st.clean_streak() == 0
