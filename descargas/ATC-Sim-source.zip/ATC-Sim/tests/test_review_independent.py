"""Independent reviewer tests (SIM2). Written without reusing the original test helpers' logic: reference
implementations here are brute-force / closed-form and share no code with atcsim.core.predict."""
import math
import os
import random
import subprocess
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from atcsim.core.aircraft import Aircraft  # noqa: E402
from atcsim.core.generator import generate  # noqa: E402
from atcsim.core.perf import TYPES, turn_rate  # noqa: E402
from atcsim.core.predict import build_trajectory, predict_pair  # noqa: E402
from atcsim.core.scenario import LEVELS, Scenario  # noqa: E402
from atcsim.core.world import World  # noqa: E402


def mk(cs, x, y, alt, hdg, tas, tgt_alt=None, code="B738"):
    return Aircraft(callsign=cs, type_code=code, x=x, y=y, alt=alt, hdg=hdg, tas=tas,
                    tgt_alt=alt if tgt_alt is None else tgt_alt, tgt_tas=tas, nav=False, tgt_hdg=hdg)


# ---------------------------------------------------------------------------------------------
# 1. CPA / loss of separation: brute force reference versus core prediction on random straight pairs
# ---------------------------------------------------------------------------------------------
def ref_pos(a, t, wind_from, wind_kt):
    """closed form ground position after t seconds of steady flight (own formula, no core imports)."""
    h = math.radians(a.hdg)
    wd = math.radians(wind_from + 180.0)
    vx = a.tas * math.sin(h) + wind_kt * math.sin(wd)
    vy = a.tas * math.cos(h) + wind_kt * math.cos(wd)
    d = a.tgt_alt - a.alt
    rate = (TYPES[a.type_code].climb_fpm if d > 0 else TYPES[a.type_code].descent_fpm) / 60.0
    z = a.alt + math.copysign(min(abs(d), rate * t), d) if d else a.alt
    return a.x + vx * t / 3600.0, a.y + vy * t / 3600.0, z


def ref_first_loss(a, b, wf, wk, horizon=300.0, dt=0.05):
    """(t_first, min_h_over_episode_start) using fine sampling; None when no loss. Uses strict < like the rules."""
    n = int(horizon / dt)
    for k in range(n + 1):
        t = k * dt
        ax, ay, az = ref_pos(a, t, wf, wk)
        bx, by, bz = ref_pos(b, t, wf, wk)
        if math.hypot(ax - bx, ay - by) < 5.0 and abs(az - bz) < 1000.0:
            return t
    return None


def ref_margin(a, b, wf, wk, horizon=300.0, dt=0.05):
    """smallest 'closeness margin' over the window: max(h - 5, (v - 1000) / 200) minimum. |margin| small => ambiguous."""
    best = 1e9
    for k in range(int(horizon / dt) + 1):
        t = k * dt
        ax, ay, az = ref_pos(a, t, wf, wk)
        bx, by, bz = ref_pos(b, t, wf, wk)
        m = max(math.hypot(ax - bx, ay - by) - 5.0, (abs(az - bz) - 1000.0) / 300.0)
        best = min(best, m)
    return best


def test_predict_matches_bruteforce_random_pairs():
    rng = random.Random(20260925)
    agree = 0
    checked = 0
    for _ in range(400):
        wf = rng.uniform(0, 360)
        wk = rng.choice([0.0, 10.0, 30.0, 40.0])
        a = mk("A", rng.uniform(-30, 30), rng.uniform(-30, 30), rng.choice([28000, 30000, 30500, 31000]),
               rng.uniform(0, 360), rng.uniform(230, 460), tgt_alt=rng.choice([None, 28000, 32000, 36000]))
        b = mk("B", rng.uniform(-30, 30), rng.uniform(-30, 30), rng.choice([28000, 30000, 30500, 31000, 32500]),
               rng.uniform(0, 360), rng.uniform(230, 460), tgt_alt=rng.choice([None, 28000, 32000, 36000]))
        m = ref_margin(a, b, wf, wk)
        if abs(m) < 0.06:
            continue                    # razor-thin cases are legitimately ambiguous at a 10 s grid
        ta = build_trajectory(a, wf, wk)
        tb = build_trajectory(b, wf, wk)
        c = predict_pair(ta, tb, "A", "B")
        ref = ref_first_loss(a, b, wf, wk)
        checked += 1
        assert (c is not None) == (ref is not None), (a, b, wf, wk, c, ref, m)
        if c is not None:
            assert abs(c.t_start - ref) < 0.5, (c.t_start, ref)
            assert c.min_h < 5.0 + 1e-9
        agree += 1
    assert checked > 150 and agree == checked


def test_exact_minima_are_not_losses():
    """Exactly 5.000 NM or exactly 1000 ft is separated; the tiniest bit less is a loss (core world monitor)."""
    def run(dx, dz):
        sc = Scenario(1, 5, [], 0.0, 0.0, 1.0, 0.0)
        w = World(sc, tasks=False, pilot_delay=0.0)
        w.aircraft["A"] = mk("A", 0.0, 0.0, 30000.0, 0.0, 300.0)
        w.aircraft["B"] = mk("B", dx, 0.0, 30000.0 + dz, 0.0, 300.0)
        w.aircraft["A"].spawn_time = w.aircraft["B"].spawn_time = -100.0
        w._check_separation()
        return len(w.active_loss)
    assert run(5.0, 0.0) == 0
    assert run(4.999999, 0.0) == 1
    assert run(0.0, 1000.0) == 0
    assert run(0.0, 999.0) == 1
    assert run(3.0, 999.9) == 1
    assert run(3.0, 1000.0) == 0
    assert run(-5.0, 0.0) == 0
    assert run(3.0, -999.0) == 1


def test_predict_exact_minima_boundary():
    """Head-on pair passing with an offset of exactly 5 NM must not be predicted; 4.9 must."""
    def pred(offset):
        a = mk("A", 0.0, 0.0, 30000.0, 0.0, 400.0)
        b = mk("B", offset, 40.0, 30000.0, 180.0, 400.0)
        return predict_pair(build_trajectory(a), build_trajectory(b), "A", "B")
    assert pred(5.0) is None
    assert pred(4.9) is not None
    assert pred(-4.9) is not None
    assert pred(-5.0) is None


def test_vertical_only_and_level_change_conflict():
    a = mk("A", 0.0, 0.0, 30000.0, 0.0, 400.0)
    b = mk("B", 0.0, 60.0, 31000.0, 180.0, 400.0)       # exactly 1000 ft apart, head-on: not a conflict
    assert predict_pair(build_trajectory(a), build_trajectory(b), "A", "B") is None
    b2 = mk("B", 0.0, 60.0, 32000.0, 180.0, 400.0, tgt_alt=30000.0)   # descends into A's level before meeting
    c = predict_pair(build_trajectory(a), build_trajectory(b2), "A", "B")
    assert c is not None


# ---------------------------------------------------------------------------------------------
# 2. Turn geometry
# ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("tas", [170, 250, 300, 400, 470])
def test_turn_is_a_circle_of_radius_v_over_omega(tas):
    a = mk("A", 0.0, 0.0, 30000.0, 0.0, float(tas), code="A320" if tas > 250 else "AT72")
    a.tas = a.tgt_tas = float(max(tas, 200)) if a.type_code == "A320" else float(min(tas, 285))
    a.set_heading(90.0 + 360.0 * 0, "R")
    # full right turn of 360 deg: target 0 with forced R after having left it
    a.tgt_hdg = 359.9
    a.turn_dir = "R"
    a.hdg = 0.0
    omega = turn_rate(a.tas)                         # deg/s
    v_nm_s = a.tas / 3600.0
    radius = v_nm_s / math.radians(omega)
    xs, ys = [], []
    for _ in range(int(360.0 / omega) - 2):
        a.step(1.0)
        xs.append(a.x)
        ys.append(a.y)
    cx, cy = radius, 0.0                             # right turn from heading north: centre is to the east
    for x, y in zip(xs, ys):
        assert abs(math.hypot(x - cx, y - cy) - radius) < 0.02 * radius + 0.02, (x, y, radius)


def test_turn_rate_law_and_cap():
    assert turn_rate(250.0) == pytest.approx(math.degrees(9.80665 * math.tan(math.radians(25)) / (250 * 0.514444)), rel=1e-9)
    assert turn_rate(100.0) == 3.0
    assert turn_rate(0.0) == 3.0               # no division by zero
    for v in range(150, 500, 10):
        assert turn_rate(v + 10) <= turn_rate(v)


def test_heading_change_takes_diff_over_rate_seconds_and_direction():
    a = mk("A", 0, 0, 30000, 350.0, 250.0)
    a.set_heading(20.0, None)                  # shortest way is right 30 deg through north
    for _ in range(3):
        a.step(1.0)
    assert 350.0 < a.hdg or a.hdg < 20.0
    assert abs(((a.hdg - 350.0 + 180) % 360) - 180) == pytest.approx(3 * turn_rate(250.0), abs=1e-6)
    b = mk("B", 0, 0, 30000, 10.0, 250.0)
    b.set_heading(350.0, "R")                  # forced right: long way round
    b.step(1.0)
    assert 10.0 < b.hdg < 20.0
    for _ in range(200):
        b.step(1.0)
    assert b.hdg == pytest.approx(350.0, abs=1e-6)


# ---------------------------------------------------------------------------------------------
# 3. Wind drift: fixed heading drifts; nav holds the ground track
# ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("wf,wk", [(0, 40), (90, 40), (270, 25), (180, 40), (45, 33)])
def test_ground_track_equals_vector_sum(wf, wk):
    a = mk("A", 0.0, 0.0, 30000.0, 60.0, 400.0)
    for _ in range(600):
        a.step(1.0, wf, wk)
    h = math.radians(60.0)
    wd = math.radians(wf + 180.0)
    ex = (400 * math.sin(h) + wk * math.sin(wd)) * 600 / 3600.0
    ey = (400 * math.cos(h) + wk * math.cos(wd)) * 600 / 3600.0
    assert a.x == pytest.approx(ex, abs=1e-6) and a.y == pytest.approx(ey, abs=1e-6)


@pytest.mark.parametrize("wf", [0, 60, 130, 200, 290])
def test_nav_holds_track_in_crosswind(wf):
    wp = [("A", 0.0, 0.0), ("B", 0.0, 80.0)]
    a = Aircraft("N", "B738", 0.0, 0.0, 30000.0, 0.0, 400.0, 30000.0, 400.0, route=tuple(wp), route_idx=1, nav=True)
    a.hdg = a.desired_heading(wf, 40.0)
    worst = 0.0
    for _ in range(1000):
        a.step(1.0, wf, 40.0)
        worst = max(worst, abs(a.x))
        if a.route_idx >= 2:
            break
    assert worst < 0.3, worst
    assert a.route_idx >= 2


# ---------------------------------------------------------------------------------------------
# 4. Scoring invariants on full noisy runs
# ---------------------------------------------------------------------------------------------
def _noisy_run(level, seed, rnd):
    from atcsim.core.scoring import compute_result
    sc = generate(seed, level)
    w = World(sc)
    cs_list = []
    n = 0
    while not w.finished and n < 5000:
        n += 1
        w.advance(0.25)
        if rnd.random() < 0.15 and w.aircraft:
            cs = rnd.choice(sorted(w.aircraft))
            w.select(cs)
            r = rnd.random()
            if r < 0.4:
                w.issue(cs, hdg=rnd.uniform(0, 360), turn_dir=rnd.choice([None, "L", "R"]))
            elif r < 0.6:
                w.issue(cs, alt=rnd.choice([24000, 30000, 34000, 38000]))
            elif r < 0.7:
                w.issue(cs, resume=True)
            elif r < 0.8:
                w.request_transfer(cs)
        for t in list(w.tasks.tasks):
            if rnd.random() < 0.05:
                w.tasks.answer(t.id, rnd.randrange(len(t.options)) if t.options else 0)
    return w, compute_result(w, "Ladder")


@pytest.mark.parametrize("level,seed", [(1, 11), (3, 12), (5, 13), (8, 14)])
def test_scoring_invariants_random_play(level, seed):
    rnd = random.Random(seed)
    w, r = _noisy_run(level, seed, rnd)
    assert w.finished
    comp_total = sum(sum(c.values()) for c in r.components.values())
    assert r.items == comp_total == r.correct + r.wrong + r.blank
    # independent recount of the items straight from the raw world records
    sep = sum(1 for rec in w.records.values() if rec["first_t"] is not None or rec["lost"])
    tasks = sum(1 for t in w.tasks.log if t.outcome in ("correct", "wrong", "blank"))
    exp = sep + len(w.zone_episodes) + len(w.handoffs) + tasks
    assert r.items == exp
    assert 0.0 <= r.accuracy <= 100.0
    assert 0.0 <= r.score <= 100.0
    # every aircraft is accounted for exactly once as a handoff
    assert len(w.handoffs) == w.spawned == len(w.scenario.specs)
    cs = [h["callsign"] for h in w.handoffs]
    assert len(cs) == len(set(cs))
    # exactly one transfer outcome per aircraft (no double counting between task engine and exit)
    per_ac = {}
    for t in w.tasks.log:
        if t.kind == "transfer" and t.outcome in ("correct", "wrong", "blank"):
            per_ac[t.aircraft] = per_ac.get(t.aircraft, 0) + 1
    assert all(v == 1 for v in per_ac.values()), per_ac
    assert len(per_ac) == w.spawned, (len(per_ac), w.spawned)
    # a blank handoff only from forced end
    assert all(h["outcome"] != "blank" or h["forced"] for h in w.handoffs)
    # goal logic
    assert r.met == (r.accuracy >= LEVELS[level - 1].goal_accuracy * 100 and r.losses == 0 and r.items > 0)
    # losses: independent detection from the snapshots (every 2 s) must not find MORE distinct episodes than recorded
    seen = set()
    for t, snap in w.snapshots:
        for i in range(len(snap)):
            for j in range(i + 1, len(snap)):
                a, b = snap[i], snap[j]
                if math.hypot(a[1] - b[1], a[2] - b[2]) < 4.99 and abs(a[3] - b[3]) < 990:
                    seen.add(tuple(sorted((a[0], b[0]))))
    recorded = {ep.pair for ep in w.losses}
    assert seen <= recorded, seen - recorded
    for ep in w.losses:
        assert ep.min_h < 5.0 and ep.min_v < 1000.0


def test_rating_thirds_and_components_consistent():
    rnd = random.Random(5)
    w, r = _noisy_run(4, 77, rnd)
    for name, c in r.components.items():
        assert min(c.values()) >= 0
    for th in r.thirds:
        assert th is None or 0.0 <= th <= 100.0


# ---------------------------------------------------------------------------------------------
# 5. Determinism and generator
# ---------------------------------------------------------------------------------------------
def _digest(level, seed):
    sc = generate(seed, level)
    return [(s.callsign, s.route_name, round(s.spawn_time, 3), s.entry_alt, s.exit_alt, s.tas) for s in sc.specs], \
        sc.wind_from, sc.null_losses


def test_generator_deterministic_across_hash_seeds():
    code = ("import sys;sys.path.insert(0,%r);from atcsim.core.generator import generate;"
            "s=generate(4242,7);print([(x.callsign,x.route_name,round(x.spawn_time,3),x.entry_alt,x.exit_alt) for x in s.specs],s.wind_from,s.null_losses)" % ROOT)
    outs = []
    for hs in ("0", "1", "12345"):
        env = dict(os.environ, PYTHONHASHSEED=hs)
        outs.append(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, env=env).stdout)
    assert outs[0] and outs[0] == outs[1] == outs[2]


@pytest.mark.parametrize("level", range(1, 11))
def test_generator_shape_every_level(level):
    for seed in (1, 2, 3):
        sc = generate(seed, level)
        spec = LEVELS[level - 1]
        assert len(sc.specs) == spec.n_aircraft, (level, seed, len(sc.specs))
        names = [s.callsign for s in sc.specs]
        assert len(set(names)) == len(names)
        assert all(len(n) <= 7 for n in names)
        assert min(s.spawn_time for s in sc.specs) <= 9.0
        # no two aircraft enter the same gate less than 150 s apart
        by_gate = {}
        for s in sc.specs:
            by_gate.setdefault(s.route[0], []).append(s.spawn_time)
        for g, ts in by_gate.items():
            ts.sort()
            assert all(b - a >= 149.99 for a, b in zip(ts, ts[1:])), (g, ts)
        for s in sc.specs:
            ceil = TYPES[s.type_code].ceiling
            assert 3000 < s.entry_alt <= ceil and 3000 < s.exit_alt <= ceil
            assert TYPES[s.type_code].v_min <= s.tas <= TYPES[s.type_code].v_max


def test_level_ladder_monotone():
    for f in ("n_aircraft", "scale", "wind_kt", "design_conflicts", "level_change_share", "readback_error_rate",
              "pilot_delay_s", "window_s"):
        vals = [getattr(l, f) for l in LEVELS]
        assert vals == sorted(vals), f
    for f in ("task_gap_s", "task_deadline_s", "aids"):
        vals = [getattr(l, f) for l in LEVELS]
        assert vals == sorted(vals, reverse=True), f


# ---------------------------------------------------------------------------------------------
# 6. Persistence / CSV
# ---------------------------------------------------------------------------------------------
def test_csv_header_and_rows(tmp_path):
    from atcsim.core.persistence import StatsStore, CSV_COLUMNS
    from atcsim.core.scoring import RunResult
    p = tmp_path / "s.json"
    st = StatsStore(str(p))
    r = RunResult(3, 9, "Ladder", correct=7, wrong=2, blank=1, real_seconds=100.0, met=False, goal_text="accuracy >= 88% and 0 losses")
    st.add_run(r)
    out = tmp_path / "e.csv"
    assert st.export_csv(str(out))
    raw = out.read_bytes()
    assert raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig")
    lines = text.strip().split("\r\n")
    assert lines[0] == "Date;Module;Level;Correct;Wrong;Blank;Seconds per item;Accuracy %;Goal;Met"
    assert CSV_COLUMNS == lines[0].split(";")
    row = lines[1].split(";")
    assert len(row) == 10 and row[2] == "3" and row[3:6] == ["7", "2", "1"] and row[6] == "10.00" and row[7] == "70.0" and row[9] == "No"


@pytest.mark.parametrize("payload", [
    b"", b"{", b"[]", b"null", b'{"runs": 5}', b'{"runs": [1, "x", {"ts": "NaN"}]}',
    b'{"runs": [{"ts": NaN, "level": 1, "correct": 1, "wrong": 0, "blank": 0}]}',
    b'{"runs": [{"ts": 1e300, "level": 1, "correct": 1, "wrong": 0, "blank": 0}]}',
    b'{"adaptive": {"level": 99, "ok": "x", "bad": 0}}', b"\xff\xfe\x00garbage", b'{"best": {"1": 5}}',
    b'{"runs": [{"ts": 1, "level": 1, "correct": 1, "wrong": 0, "blank": 0, "components": {"Handoff": 3}}]}',
])
def test_corrupt_stats_never_crash_and_csv_still_exports(tmp_path, payload):
    from atcsim.core.persistence import StatsStore
    p = tmp_path / "s.json"
    p.write_bytes(payload)
    st = StatsStore(str(p))
    assert isinstance(st.data["runs"], list)
    assert 1 <= st.data["adaptive"]["level"] <= 10
    out = tmp_path / "e.csv"
    assert st.export_csv(str(out))            # must not raise on NaN / huge timestamps
    for x in st.data["runs"]:
        for v in (x["components"] or {}).values():
            assert isinstance(v, dict)


# ---------------------------------------------------------------------------------------------
# 7. Session-level regressions found by the review
# ---------------------------------------------------------------------------------------------
def _session(level=1, seed=3):
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    import pygame
    pygame.init()
    pygame.display.set_mode((100, 100))
    from atcsim.ui.session import GameSession
    w = World(generate(seed, level))
    w.advance(5.0)
    s = GameSession(w, "Ladder")
    s.update(0.0)
    cs = sorted(w.aircraft)[0]
    w.select(cs)
    return s, w, cs


def test_arrow_sequence_right_right_right_left_turns_the_short_way():
    import pygame
    s, w, cs = _session()
    for _ in range(3):
        s.on_key(pygame.K_RIGHT, 0)
    s.on_key(pygame.K_LEFT, 0)
    p = s.proposal
    base = w.aircraft[cs].hdg
    assert p["hdg"] == pytest.approx((round(base) + 10) % 360, abs=1.01)
    assert p["turn"] == "R", "net +10 degrees must be flown as a right turn, not a 350 degree left turn"
    s.on_key(pygame.K_LEFT, 0)
    s.on_key(pygame.K_LEFT, 0)
    s.on_key(pygame.K_LEFT, 0)
    assert s.proposal["turn"] == "L"


def test_non_ascii_digit_does_not_crash_typing():
    import pygame
    s, w, cs = _session()
    s.on_key(pygame.K_h, 0, "h")
    s.on_key(pygame.K_2, 0, "²")          # superscript two: str.isdigit() is True, int() fails
    s.on_key(pygame.K_RETURN, 0)


def test_late_readback_flag_does_not_undo_a_newer_instruction():
    s, w, cs = _session(level=5)
    ac = w.aircraft[cs]
    w.force_readback = True
    w.tutorial_mode = False
    ok, _, cl = w.issue(cs, hdg=(ac.hdg + 40) % 360)
    w.advance(5.0)
    cl.wrong_field = "hdg"
    ok2, _, cl2 = w.issue(cs, hdg=(ac.hdg + 90) % 360)
    w.advance(5.0)
    newer = w.aircraft[cs].tgt_hdg
    from atcsim.core.tasks import Task
    t = Task(99, "readback", "x", ["Correct", "Incorrect"], 1, 5, 5, 0.0, cs, {"clearance": cl.id, "wrong": True},
             outcome="correct")
    w.on_task_finished(t)
    assert w.aircraft[cs].tgt_hdg == newer


# ---------------------------------------------------------------------------------------------
# 8. UI regressions: label overlap at high traffic, quit/pause, feedback, fit mode, menu Esc
# ---------------------------------------------------------------------------------------------
def test_labels_do_not_overlap_in_busy_level10_scenes():
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    import pygame
    pygame.init()
    pygame.display.set_mode((100, 100))
    from atcsim.ui.session import GameSession
    w = World(generate(4110, 10))
    s = GameSession(w, "Ladder")
    surf = pygame.Surface((1440, 810))
    worst = 0
    peak = 0
    for step in range(3000):
        w.advance(0.5)
        s.update(0.5)
        if step % 40 == 0 and len(w.aircraft) >= 12:
            s.draw(surf)
            rects = list(s.scope.label_rects.items())
            peak = max(peak, len(rects))
            bad = 0
            for i in range(len(rects)):
                for j in range(i + 1, len(rects)):
                    if rects[i][1].colliderect(rects[j][1]):
                        bad += 1
            for cs, r in rects:
                assert s.scope.rect.contains(r), (cs, r)
            worst = max(worst, bad)
        if w.finished:
            break
    assert peak >= 15
    assert worst <= 2, worst


def test_q_quits_from_manual_pause_and_menu_esc_does_not_quit(tmp_path):
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    import pygame
    from atcsim.ui.app import App, GameScreen
    from atcsim.ui.screens import MenuScreen
    app = App(headless=True, stats_path=str(tmp_path / "s.json"))
    def key(k, uni=""):
        pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k, mod=0, unicode=uni))
        app.frame(0.0, draw=False)
    key(pygame.K_ESCAPE)
    assert not app.quit and isinstance(app.screen, MenuScreen)
    app.start_run("Ladder", 1, 5)
    assert isinstance(app.screen, GameScreen)
    key(pygame.K_p, "p")
    assert app.screen.s.paused
    key(pygame.K_q, "q")
    assert isinstance(app.screen, MenuScreen)


def test_task_result_feedback_appears():
    s, w, cs = _session(level=3)
    t = w.tasks._create_alert()
    assert t is not None
    w.tasks.answer(t.id, 0)
    s.update(0.01)
    assert s.feedback and s.feedback[-1][0].startswith("OK")
    t2 = w.tasks._create_alert()
    w.tasks._expire(t2)
    s.update(0.01)
    assert any(f[0].startswith("MISSED") for f in s.feedback)


def test_fit_mode_maps_mouse_to_logical_coordinates(tmp_path, monkeypatch):
    import pygame
    from atcsim.ui.app import App
    monkeypatch.setenv("SIM_DESKTOP", "1366x768")
    app = App(headless=True, stats_path=str(tmp_path / "s.json"))
    assert app.fit
    app.frame(0.0)
    ox, oy, k = app._view
    win = pygame.display.get_surface().get_size()
    assert 0.5 < k < 1.0 and win[0] <= 1366 - 40 + 1 and win[1] <= 768 - 120 + 1
    px, py = int(ox + 700 * k), int(oy + 400 * k)
    lx, ly = app._to_logical((px, py))
    assert abs(lx - 700) <= 2 and abs(ly - 400) <= 2


def test_ttc_near_miss_is_clearly_outside_5nm():
    from atcsim.core.predict import predict_all
    s, w, cs = _session(level=6, seed=8)
    bad = 0
    for _ in range(400):
        w.advance(1.0)
        t = w.tasks._create_ttc()
        if t is not None and t.data.get("near_miss"):
            assert t.data["min_h"] >= 6.0
        if w.finished:
            break


def test_adaptive_state_machine_properties():
    from atcsim.core.scoring import adaptive_update, default_adaptive
    rnd = random.Random(1)
    st = default_adaptive()
    for _ in range(5000):
        met = rnd.random() < 0.6
        assisted = rnd.random() < 0.1
        new = adaptive_update(st, met, assisted)
        assert 1 <= new["level"] <= 10 and new["ok"] >= 0 and new["bad"] >= 0
        assert abs(new["level"] - st["level"]) <= 1
        if assisted:
            assert new == st
        if met and not assisted:
            assert new["level"] >= st["level"] and new["bad"] == 0
        if not met and not assisted:
            assert new["level"] <= st["level"] and new["ok"] == 0
        st = new
    # exact ladder: level 4 needs two clean runs, level 5 needs three
    s = {"level": 4, "ok": 0, "bad": 0}
    s = adaptive_update(s, True); assert s["level"] == 4
    s = adaptive_update(s, True); assert s["level"] == 5
    for i in range(2):
        s = adaptive_update(s, True); assert s["level"] == 5
    s = adaptive_update(s, True); assert s["level"] == 6
