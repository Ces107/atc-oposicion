"""Spoken secondary task: scheduling, scoring, persistence (old files still load), CSV rows, on/off, UI keys, clips."""
import json
import os
import sys
import wave

import pytest

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))

from atcsim.core.audio_task import (AUDIO_LEVELS, DEFAULT_ON_FROM, DIGITS, LETTERS, AudioTask, audio_cost, latest_solo,  # noqa: E402
                                    resolve_variant, summarize)
from atcsim.core.generator import generate  # noqa: E402
from atcsim.core.persistence import CSV_COLUMNS, StatsStore, runs_to_csv  # noqa: E402
from atcsim.core.scoring import RunResult, compute_result  # noqa: E402
from atcsim.core.world import World  # noqa: E402


def run_until(au, pred, step=0.05, limit=600.0):
    while not pred(au):
        au.tick(step)
        assert au.t < limit, "condition never reached"


def answered_open(au):
    return au.open_item is not None and au.t >= au.open_item.end


# ---- variant and on/off -------------------------------------------------------------------------------------
def test_resolve_variant_default_on_from_level_5_and_alternates():
    assert DEFAULT_ON_FROM == 5
    for lv in range(1, 5):
        assert resolve_variant("auto", lv, 10) is None and resolve_variant("auto", lv, 11) is None
    for lv in range(5, 11):
        assert resolve_variant("auto", lv, 10) == "sum" and resolve_variant("auto", lv, 11) == "code"
    for lv in (1, 5, 10):
        assert resolve_variant("sum", lv, 11) == "sum" and resolve_variant("code", lv, 10) == "code"
        assert resolve_variant("off", lv, 10) is None


def test_difficulty_grows_with_level():
    for a, b in zip(AUDIO_LEVELS, AUDIO_LEVELS[1:]):
        assert b.sum_len[0] >= a.sum_len[0] and b.sum_len[1] >= a.sum_len[1]
        assert b.code_len >= a.code_len
        assert b.gap_s <= a.gap_s and b.token_gap_s <= a.token_gap_s and b.window_s <= a.window_s
    assert AUDIO_LEVELS[-1].sum_len[1] > AUDIO_LEVELS[0].sum_len[1] and AUDIO_LEVELS[-1].gap_s < AUDIO_LEVELS[0].gap_s


# ---- scheduling ---------------------------------------------------------------------------------------------
def test_same_seed_same_items_and_cues():
    def trace(seed):
        au = AudioTask("sum", 6, seed)
        cues = []
        for _ in range(4000):
            au.tick(0.05)
            cues += au.pop_cues()
        return [(i.tokens, i.truth) for i in au.items], cues
    assert trace(7) == trace(7)
    assert trace(7) != trace(8)


@pytest.mark.parametrize("variant", ["sum", "code"])
@pytest.mark.parametrize("level", [1, 5, 10])
def test_items_never_overlap_and_tokens_are_spaced(variant, level):
    au = AudioTask(variant, level, 3)
    for _ in range(int(400 / 0.05)):
        au.tick(0.05)
    sp = au.spec
    assert len(au.items) >= 5
    for it in au.items:
        if variant == "sum":
            assert sp.sum_len[0] <= len(it.tokens) <= sp.sum_len[1]
            assert it.truth == sum(int(x) for x in it.tokens) and all(x in DIGITS[1:] for x in it.tokens)
        else:
            assert len(it.tokens) == sp.code_len and it.tokens[0] in LETTERS and all(x in DIGITS for x in it.tokens[1:])
        for k in range(1, len(it.onsets)):
            assert it.onsets[k] - it.onsets[k - 1] == pytest.approx(au.dur[it.tokens[k - 1]] + sp.token_gap_s)
        assert it.deadline == pytest.approx(it.end + sp.window_s)
    for a, b in zip(au.items, au.items[1:]):
        assert b.start > a.closed_at >= a.start                 # one item at a time, the next starts after the close


def test_rate_grows_with_level():
    def per_min(level):
        au = AudioTask("sum", level, 5)
        for _ in range(int(600 / 0.05)):
            au.tick(0.05)
        return len(au.items) / 10.0
    assert per_min(10) > 1.5 * per_min(1)


def test_code_target_announced_first_and_hidden_later_at_level_5():
    au = AudioTask("code", 5, 9)
    first = []
    for _ in range(60):
        au.tick(0.05)
        first += au.pop_cues()
    assert first[0] == "tone" and first[1:] == au.target
    assert au.show_target
    run_until(au, lambda a: a.t > a.target_end + 11)
    assert not au.show_target
    assert AudioTask("code", 2, 9).show_target                 # low levels keep it on screen


def test_distractors_differ_by_one_token_or_a_swap_from_level_5():
    au = AudioTask("code", 7, 4)
    for _ in range(int(900 / 0.05)):
        au.tick(0.05)
    non = [i for i in au.items if not i.truth]
    assert non and any(i.truth for i in au.items)
    for i in non:
        diff = sum(1 for x, y in zip(i.tokens, au.target) if x != y)
        swapped = sorted(i.tokens[1:]) == sorted(au.target[1:]) and i.tokens[0] == au.target[0]
        assert diff == 1 or (diff == 2 and swapped), (i.tokens, au.target)


# ---- scoring ------------------------------------------------------------------------------------------------
def test_sum_correct_wrong_blank_and_response_time():
    au = AudioTask("sum", 5, 1)
    assert au.answer_sum(5) is None                            # nothing spoken yet
    run_until(au, answered_open)
    it = au.open_item
    au.tick(0.5)
    got = au.answer_sum(it.truth)
    assert got is it and it.outcome == "correct" and it.response_s == pytest.approx(au.t - it.end, abs=1e-6)
    assert au.answer_sum(it.truth) is None                     # closed: a second answer is ignored
    run_until(au, answered_open)
    au.answer_sum(au.open_item.truth + 1)
    assert au.log[-1].outcome == "wrong"
    run_until(au, answered_open)
    third = au.open_item
    run_until(au, lambda a: a.open_item is None)
    assert third.outcome == "blank" and third.response_s is None
    s = au.summary()
    assert (s["n"], s["correct"], s["wrong"], s["blank"]) == (3, 1, 1, 1)
    assert s["accuracy"] == pytest.approx(33.3, abs=0.1) and s["rt_s"] == pytest.approx(0.5, abs=0.06)


def test_code_hits_false_alarms_misses_and_ignored_items():
    au = AudioTask("code", 5, 2)
    assert au.press_match() is None
    for _ in range(int(1200 / 0.05)):
        au.tick(0.05)
        it = au.open_item
        if it is not None and au.t >= it.end and it.id % 3 != 0:
            au.press_match()                                   # press on two thirds of the items, target or not
    hits = sum(1 for i in au.log if i.truth and i.outcome == "correct")
    misses = sum(1 for i in au.log if i.truth and i.outcome == "blank")
    fas = sum(1 for i in au.log if not i.truth and i.outcome == "wrong")
    ign = sum(1 for i in au.log if not i.truth and i.outcome == "info")
    assert hits and misses and fas and ign
    s = au.summary()
    assert (s["correct"], s["wrong"], s["blank"]) == (hits, fas, misses) and s["ignored"] == ign
    assert s["n"] == hits + fas + misses                       # ignored non-targets are not items


def test_idle_player_scores_zero_on_codes():
    au = AudioTask("code", 6, 12)
    for _ in range(int(600 / 0.05)):
        au.tick(0.05)
    au.finish()
    s = au.summary()
    assert s["n"] > 0 and s["correct"] == 0 and s["accuracy"] == 0.0 and s["blank"] == s["n"]


def test_finish_closes_started_item_and_drops_unstarted():
    au = AudioTask("sum", 5, 3)
    run_until(au, lambda a: a.current is not None and a.t >= a.current.start + 0.1)
    it = au.current
    au.finish()
    assert it.outcome == "blank" and au.current is None and au.finished and not au.cues
    au.tick(5.0)
    assert len(au.log) == 1
    au2 = AudioTask("sum", 5, 3)
    run_until(au2, lambda a: a.current is not None)
    assert au2.t < au2.current.start
    au2.finish()
    assert au2.items == [] and au2.log == []


def test_max_items_and_done():
    au = AudioTask("sum", 3, 4, max_items=3, gap_scale=0.25, start_s=1.0)
    run_until(au, lambda a: a.done)
    assert len(au.items) == 3 and len(au.log) == 3


def test_audio_cost_and_latest_solo():
    dual = {"variant": "sum", "level": 5, "n": 10, "accuracy": 70.0, "rt_s": 2.0}
    solo = {"variant": "sum", "level": 5, "n": 8, "accuracy": 87.5, "rt_s": 1.2, "ts": 5.0}
    c = audio_cost(dual, solo)
    assert c["cost_points"] == pytest.approx(17.5) and c["cost_rt_s"] == pytest.approx(0.8) and c["solo_accuracy"] == 87.5
    assert audio_cost(dual, dict(solo, level=6)) is None and audio_cost(dual, dict(solo, variant="code")) is None
    assert audio_cost(dual, dict(solo, n=0)) is None
    assert audio_cost(dual, dict(solo, rt_s=None))["cost_rt_s"] is None
    sols = [dict(solo, ts=1.0, accuracy=50.0), dict(solo, variant="code"), dict(solo, ts=3.0), dict(solo, level=4)]
    assert latest_solo(sols, "sum", 5)["ts"] == 3.0 and latest_solo(sols, "sum", 7) is None


# ---- world and scoring integration --------------------------------------------------------------------------
def test_audio_runs_with_the_world_and_never_changes_radar_items():
    sc = generate(2024, 5)
    plain = World(sc, tasks=True)
    with_audio = World(generate(2024, 5), tasks=True)
    with_audio.audio = AudioTask("sum", 5, 2024)
    for w in (plain, with_audio):
        while not w.finished and w.real_t < 3000:
            w.advance(0.25)
    assert with_audio.audio.finished and with_audio.audio.t == pytest.approx(with_audio.real_t)
    a, b = compute_result(plain), compute_result(with_audio)
    assert (a.correct, a.wrong, a.blank, a.score, a.met) == (b.correct, b.wrong, b.blank, b.score, b.met)
    assert a.audio is None and b.audio["variant"] == "sum" and b.audio["n"] > 0 and b.audio["blank"] == b.audio["n"]


def test_pause_freezes_the_spoken_task(tmp_path):
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "code"
    app.start_run("Ladder", 5, 77)
    s = app.screen.s
    au = s.world.audio
    for _ in range(20):
        app.frame(0.1, draw=False)
    assert au.t == pytest.approx(s.world.real_t) and au.t > 1.5
    t, n_cues = au.t, len(au.cues)
    s.paused = True
    for _ in range(50):
        app.frame(0.1, draw=False)
    assert au.t == t and len(au.cues) == n_cues
    s.paused = False
    app.frame(0.1, draw=False)
    assert au.t > t


# ---- persistence --------------------------------------------------------------------------------------------
def _old_record(**kw):
    rec = {"ts": 1_700_000_000.0, "mode": "Ladder", "level": 5, "seed": 3, "correct": 8, "wrong": 1, "blank": 1, "spi": 5.0,
           "accuracy": 80.0, "score": 70.0, "losses": 0, "zone": 0, "goal": "g", "met": False}
    rec.update(kw)
    return rec


def test_old_stats_file_without_audio_fields_loads(tmp_path):
    p = tmp_path / "sim_stats.json"
    p.write_text(json.dumps({"version": 2, "runs": [_old_record()], "adaptive": {"level": 4, "ok": 1, "bad": 0}}), encoding="utf-8")
    st = StatsStore(str(p))
    assert not st.warning and len(st.data["runs"]) == 1
    assert st.data["runs"][0]["audio"] is None
    assert st.data["audio_solo"] == [] and st.settings() == {"audio": "auto", "voice": "es"}
    assert st.data["adaptive"]["level"] == 4
    out = tmp_path / "o.csv"
    assert st.export_csv(str(out))
    lines = out.read_bytes().decode("utf-8-sig").strip().split("\r\n")
    assert len(lines) == 2 and lines[0] == ";".join(CSV_COLUMNS)   # no audio: exactly the old CSV


def test_malformed_audio_fields_are_dropped_not_fatal(tmp_path):
    p = tmp_path / "s.json"
    bad_runs = [_old_record(audio="x"), _old_record(audio={"variant": "zzz"}), _old_record(audio={"variant": "sum", "correct": "a"}),
                _old_record(audio={"variant": "sum", "level": 5, "correct": 3, "wrong": 1, "blank": 0, "rt_s": float("nan")})]
    p.write_text(json.dumps({"runs": bad_runs, "audio_solo": [1, {"variant": "code"}, {"variant": "sum", "ts": 1e300}],
                             "settings": {"audio": "loud", "voice": "fr"}}), encoding="utf-8")
    st = StatsStore(str(p))
    assert len(st.data["runs"]) == 4 and all(r["audio"] is None for r in st.data["runs"])
    assert st.data["audio_solo"] == [] and st.settings() == {"audio": "auto", "voice": "es"}
    assert st.export_csv(str(tmp_path / "e.csv"))


def test_run_with_audio_round_trip_cost_and_csv(tmp_path):
    p = str(tmp_path / "s.json")
    st = StatsStore(p)
    solo = {"variant": "sum", "level": 5, "n": 8, "correct": 7, "wrong": 1, "blank": 0, "accuracy": 87.5, "rt_s": 1.1, "rt_median_s": 1.0}
    st.add_audio_solo(solo, seed=50, voice="es", ts=1_700_000_000.0)
    r = RunResult(5, 51, "Ladder", correct=40, wrong=5, blank=5, real_seconds=500.0, goal_text="accuracy >= 90% and 0 losses")
    r.audio = {"variant": "sum", "level": 5, "n": 20, "correct": 15, "wrong": 3, "blank": 2, "accuracy": 75.0, "rt_s": 1.9,
               "rt_median_s": 1.8, "spoken": 20}
    rec = st.add_run(r, ts=1_700_000_100.0, voice="es")
    assert rec["audio"]["cost"]["cost_points"] == pytest.approx(12.5) and rec["audio"]["cost"]["cost_rt_s"] == pytest.approx(0.8)
    st2 = StatsStore(p)                                         # reload
    a = st2.data["runs"][0]["audio"]
    assert a["variant"] == "sum" and a["voice"] == "es" and a["cost"]["cost_points"] == pytest.approx(12.5)
    assert st2.data["audio_solo"][0]["seed"] == 50
    lines = runs_to_csv(st2.data["runs"], st2.data["audio_solo"]).strip().split("\r\n")
    assert len(lines) == 4 and all(len(x.split(";")) == 10 for x in lines[1:3])
    assert lines[1].split(";")[1] == "Radar Sector Sim (Ladder)"
    f = lines[2].split(";")
    assert f[1] == "Spoken task: digit sums (with radar)" and f[3:6] == ["15", "3", "2"] and f[6] == "1.90" and f[7] == "75.0"
    assert "+12.5 pts" in lines[2] and f[-1] == "No"
    g = lines[3].split(";")
    assert g[1] == "Spoken task: digit sums (solo)" and g[7] == "87.5" and g[-1] == "No"   # goal at L5 is 90 %
    assert "Radar Sector Sim" not in lines[2] and "Radar Sector Sim" not in lines[3]       # never mixed with the sim module


def test_solo_after_the_run_updates_that_runs_cost(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    r = RunResult(6, 99, "Adaptive", correct=1, wrong=0, blank=0, real_seconds=10.0)
    r.audio = {"variant": "code", "level": 6, "n": 6, "correct": 3, "wrong": 1, "blank": 2, "accuracy": 50.0, "rt_s": 1.5, "target": "KILO 4 7 1"}
    rec = st.add_run(r)
    assert "cost" not in rec["audio"]
    st.add_audio_solo({"variant": "code", "level": 6, "n": 7, "correct": 7, "wrong": 0, "blank": 0, "accuracy": 100.0, "rt_s": 0.6}, seed=99)
    assert StatsStore(st.path).data["runs"][0]["audio"]["cost"]["cost_points"] == pytest.approx(50.0)


def test_settings_persist(tmp_path):
    st = StatsStore(str(tmp_path / "s.json"))
    st.settings()["audio"] = "off"
    st.settings()["voice"] = "en"
    st.save()
    assert StatsStore(st.path).settings() == {"audio": "off", "voice": "en"}


# ---- clips and generator ------------------------------------------------------------------------------------
def test_voice_clips_exist_small_and_spoken():
    from atcsim.ui import sound
    man = sound.manifest()
    total = 0
    for lang in ("es", "en"):
        assert sound.clips_complete(lang)
        assert man["languages"][lang]["fallback"] is False and man["languages"][lang]["engine"] == "SAPI"
        d = sound.durations(lang)
        assert all(0.15 < v < 0.8 for v in d.values())
        for tok in list(DIGITS) + list(LETTERS):
            pth = sound.clip_path(lang, tok)
            total += os.path.getsize(pth)
            with wave.open(pth, "rb") as w:
                assert (w.getnchannels(), w.getsampwidth(), w.getframerate()) == (1, 2, 16000)
    assert total < 1_500_000


def test_tone_fallback_encodes_digits():
    import make_voice
    lens = [len(make_voice.tone_token(str(d))) for d in range(1, 10)]
    assert lens == sorted(lens) and len(set(lens)) == 9          # more pips for bigger digits
    assert all(len(make_voice.tone_token(l)) > 0 for l in LETTERS)


def test_summarize_empty():
    s = summarize([], "sum", 3)
    assert s["n"] == 0 and s["accuracy"] == 0.0 and s["rt_s"] is None


# ---- UI: on/off, keys, baseline -----------------------------------------------------------------------------
def _app(tmp_path):
    from play_ui import new_app
    app = new_app(str(tmp_path))
    app.frame(0.0, draw=False)          # drain the window events of the dummy driver (focus events would pause the run)
    return app


@pytest.mark.parametrize("setting,level,seed,expect", [
    ("auto", 4, 10, None), ("auto", 5, 10, "sum"), ("auto", 5, 11, "code"), ("off", 7, 10, None), ("sum", 1, 11, "sum"),
    ("code", 2, 10, "code")])
def test_runs_get_audio_by_setting(tmp_path, setting, level, seed, expect):
    app = _app(tmp_path)
    app.stats.settings()["audio"] = setting
    app.start_run("Ladder", level, seed)
    au = app.screen.s.world.audio
    assert (au.variant if au else None) == expect


def test_radar_only_baseline_never_has_audio(tmp_path):
    from atcsim.core.scoring import RADAR_ONLY
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    app.start_run(RADAR_ONLY, 5, 10)
    assert app.screen.s.world.audio is None


def test_menu_audio_row_cycles_setting_and_voice(tmp_path):
    import pygame
    from play_ui import key
    from atcsim.ui.screens import AUDIO_ROW
    app = _app(tmp_path)
    m = app.screen
    m.sel = AUDIO_ROW
    seen = []
    for _ in range(4):
        key(app, pygame.K_RETURN)
        seen.append(app.stats.settings()["audio"])
    assert seen == ["sum", "code", "off", "auto"]
    key(app, pygame.K_RIGHT)
    assert app.stats.settings()["voice"] == "en"
    key(app, pygame.K_LEFT)
    assert app.stats.settings()["voice"] == "es"
    app.stats.settings()["audio"] = "off"
    app.stats.save()
    assert StatsStore(app.stats.path).settings()["audio"] == "off"
    m.draw(app.surface)
    key(app, pygame.K_ESCAPE)
    assert m.sel == len(m.items()) - 1 and m.items()[-1][0] == "Quit"     # Esc still highlights Quit


def _advance_to_answer(app):
    s = app.screen.s
    au = s.world.audio
    for _ in range(5000):
        app.frame(0.05, draw=False)
        it = au.open_item
        if it is not None and au.t >= it.end + 0.2:
            return it
    raise AssertionError("no spoken item")


def test_keys_answer_the_spoken_task_without_stopping_traffic(tmp_path):
    import pygame
    from play_ui import key
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    app.start_run("Ladder", 3, 20)
    s = app.screen.s
    it = _advance_to_answer(app)
    t_before = s.world.t
    key(app, pygame.K_v, "v")
    for ch in str(it.truth):
        key(app, pygame.K_0 + int(ch), ch)
    s.draw(app.surface)                                         # the widget shows the typed digits
    key(app, pygame.K_RETURN)
    assert it.outcome == "correct" and s.typing is None and not s.paused
    app.frame(0.5, draw=False)
    assert s.world.t > t_before                                 # traffic kept moving
    assert any(f[0].startswith("OK") for f in s.feedback)
    # codes: M
    (tmp_path / "b").mkdir()
    app2 = _app(tmp_path / "b")
    app2.stats.settings()["audio"] = "code"
    app2.start_run("Ladder", 5, 21)
    s2 = app2.screen.s
    for _ in range(40):
        it = _advance_to_answer(app2)
        key(app2, pygame.K_m, "m")
        if it.truth:
            break
    assert it.outcome == "correct"
    s2.draw(app2.surface)


def test_v_typing_does_not_touch_a_heading_proposal(tmp_path):
    import pygame
    from play_ui import key
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    app.start_run("Ladder", 3, 22)
    s = app.screen.s
    it = _advance_to_answer(app)
    cs = sorted(s.world.aircraft)[0]
    s.select(cs)
    key(app, pygame.K_RIGHT)
    assert s.proposal is not None
    key(app, pygame.K_v, "v")
    for ch in str(it.truth):
        key(app, pygame.K_0 + int(ch), ch)
    key(app, pygame.K_RETURN)
    assert it.outcome == "correct" and s.proposal is not None and s.world.selected == cs


def test_debrief_solo_baseline_saves_and_sets_the_cost(tmp_path):
    import pygame
    from play_ui import key, play, start_ladder
    from atcsim.ui.screens import AudioSoloScreen, DebriefScreen
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "sum"
    start_ladder(app, 2, 30)
    play(app, dict(seed=2, p_correct=0.9, p_skip=0.05), dt=0.2, draw_every=50)
    d = app.screen
    assert isinstance(d, DebriefScreen) and d.r.audio and d.r.audio["n"] > 0
    rec = app.stats.data["runs"][-1]
    assert rec["audio"]["variant"] == "sum" and "cost" not in rec["audio"]
    assert any(t.startswith("A: audio solo") for t, *_ in d.build(1200))
    key(app, pygame.K_a, "a")
    scr = app.screen
    assert isinstance(scr, AudioSoloScreen)
    while isinstance(app.screen, AudioSoloScreen):
        app.frame(0.1, draw=False)
        au = scr.au
        it = au.open_item
        if it is not None and au.t >= it.end + 0.3:
            key(app, pygame.K_v, "v")
            for ch in str(it.truth):
                key(app, pygame.K_0 + int(ch), ch)
            key(app, pygame.K_RETURN)
            scr.draw(app.surface)
    assert app.screen is d
    solo = app.stats.data["audio_solo"][-1]
    assert solo["n"] == 8 and solo["accuracy"] == 100.0 and solo["seed"] == 30
    cost = app.stats.data["runs"][-1]["audio"]["cost"]
    assert cost["cost_points"] == pytest.approx(100.0 - rec["audio"]["accuracy"])
    assert any(t.startswith("Coste doble tarea") for t, *_ in d.build(1200))
    for k in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
        key(app, k)
        d.draw(app.surface)
    p = app.export_csv()
    text = open(p, "rb").read().decode("utf-8-sig")
    os.remove(p)
    assert "Spoken task: digit sums (with radar)" in text and "Spoken task: digit sums (solo)" in text


def test_solo_baseline_esc_saves_nothing(tmp_path):
    import pygame
    from play_ui import key, play, start_ladder
    from atcsim.ui.screens import AudioSoloScreen, DebriefScreen
    app = _app(tmp_path)
    app.stats.settings()["audio"] = "code"
    start_ladder(app, 1, 31)
    play(app, dict(seed=3), dt=0.25, draw_every=80)
    d = app.screen
    key(app, pygame.K_a, "a")
    assert isinstance(app.screen, AudioSoloScreen)
    for _ in range(30):
        app.frame(0.1)
    key(app, pygame.K_ESCAPE)
    assert app.screen is d and app.stats.data["audio_solo"] == []
