@echo off
rem ATC Radar Sector Simulator - one-click launcher for Windows.
rem Creates a private virtual environment (in %LOCALAPPDATA%\atcsim-venv, outside this folder) on first run, installs pygame-ce, then starts the game.
rem Set SIM_NO_RUN=1 to only prepare the environment (used for testing this script).
setlocal
cd /d "%~dp0"
set "VENV=%LOCALAPPDATA%\atcsim-venv"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo Python 3.10 or newer was not found. Install it from https://www.python.org/downloads/ and tick "Add Python to PATH".
  pause
  exit /b 1
)

if not exist "%VENV%\Scripts\python.exe" (
  echo Creating virtual environment in %VENV% ...
  %PY% -m venv "%VENV%"
  if errorlevel 1 goto :fail
)

rem install only when pygame is missing (fast start-up on later runs)
"%VENV%\Scripts\python.exe" -c "import pygame" >nul 2>nul
if errorlevel 1 (
  echo Installing pygame-ce ...
  "%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt
  if errorlevel 1 goto :fail
)

if defined SIM_NO_RUN (
  echo Environment ready.
  exit /b 0
)
"%VENV%\Scripts\python.exe" main.py
if errorlevel 1 goto :fail
exit /b 0

:fail
echo.
echo Something went wrong (see the messages above). If pip could not download pygame-ce, check your internet connection.
pause
exit /b 1
