ATC Sim - radar sector simulator (source)

Python 3.10 or newer is required.

Windows        run.bat
macOS, Linux   sh run.sh

Manual:  python -m venv .venv  ->  .venv/bin/pip install -r requirements.txt  ->  .venv/bin/python main.py
Tests:   pip install pytest  ->  python -m pytest tests -q

Results are stored per user (Windows: %LOCALAPPDATA%\ATC-Sim, macOS: ~/Library/Application Support/ATC-Sim,
Linux: ~/.local/share/ATC-Sim).
