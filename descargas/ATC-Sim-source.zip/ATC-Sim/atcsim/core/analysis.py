"""Debrief analysis: what would have resolved a conflict, and a plain-English verdict for every loss."""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from .aircraft import Aircraft
from .predict import build_trajectory, predict_pair
from .world import LossEpisode, World


def _fmt_t(t: float) -> str:
    t = max(0.0, t)
    return f"{int(t // 60)}:{int(t % 60):02d}"


def smallest_resolving_turn(a: Aircraft, b: Aircraft, wind_from: float, wind_speed: float,
                            max_turn: int = 90, step: int = 5) -> Optional[Tuple[str, str, int]]:
    """Smallest single heading change (either aircraft, left or right, 5 degree steps) after which the pair is no
    longer predicted to lose separation, ignoring all other traffic. Returns (callsign, 'L'|'R', degrees)."""
    tb0 = build_trajectory(b, wind_from, wind_speed)
    ta0 = build_trajectory(a, wind_from, wind_speed)
    for mag in range(step, max_turn + 1, step):
        for who, other_traj in ((a, tb0), (b, ta0)):
            base = who.tgt_hdg if (who.tgt_hdg is not None and not who.nav) else who.hdg
            for side, sign in (("R", 1), ("L", -1)):
                c = who.copy()
                c.set_heading(base + sign * mag, side)
                tr = build_trajectory(c, wind_from, wind_speed)
                if predict_pair(tr, other_traj, who.callsign, "x") is None:
                    return (who.callsign, side, mag)
    return None


def loss_report(world: World, ep: LossEpisode) -> Dict[str, Any]:
    """Structured explanation of one loss of separation for the debrief screen."""
    rec = world.records.get(ep.pair)
    lines: List[str] = []
    verdict = ""
    lead = rec["first_lead"] if rec else None
    seen_t = rec["first_t"] if rec else None
    lines.append(f"{ep.a} and {ep.b} came within {ep.min_h:.1f} NM laterally and {ep.min_v:.0f} ft vertically "
                 f"at {_fmt_t(ep.t_min)} (minima: 5 NM and 1000 ft).")
    early = None
    late = None
    if rec is None or rec["first_t"] is None:
        lines.append("The conflict was never predicted before it happened (the situation changed too late, "
                     "for example by an instruction or a misheard read-back).")
        verdict = "not seen"
    else:
        warn = ep.start_t - seen_t
        lines.append(f"It was first predictable at {_fmt_t(seen_t)}, {warn:.0f} simulated seconds before the loss began.")
        cmds = [c for c in rec["commands"] if c[0] <= ep.start_t]
        if not cmds:
            verdict = "no action"
            lines.append("Neither aircraft received any instruction before the loss.")
        else:
            verdict = "acted, not enough"
            for (t, cid, cs, text, hc) in cmds:
                lines.append(f"  {_fmt_t(t)}  {cs}: {text}   ({ep.start_t - t:.0f} s before the loss)")
        wf, ws = world.wind_from, world.wind_speed
        if rec["states"] is not None:
            a0, b0, _ = rec["states"]
            early = smallest_resolving_turn(a0, b0, wf, ws)
        if rec.get("action_states") is not None:
            a1, b1, _ = rec["action_states"]
            late = smallest_resolving_turn(a1, b1, wf, ws)
        if early is not None:
            lines.append(f"At the first alert a single {early[2]} degree turn ({'right' if early[1]=='R' else 'left'}) "
                         f"of {early[0]} would have been enough.")
        else:
            lines.append("No single turn up to 90 degrees resolved it at the first alert; a level change or speed "
                         "change was needed.")
        first_cmd = cmds[0] if cmds else None
        if first_cmd is not None:
            a_states = rec.get("action_states")
            if late is not None and early is not None and late[2] > early[2]:
                lines.append(f"When you first acted the smallest single turn that still worked had grown from {early[2]} to "
                             f"{late[2]} degrees: acting early and little is cheaper.")
            elif late is None and a_states is not None:
                lines.append("When you first acted, no single turn up to 90 degrees was enough any more.")
            elif late is not None:
                lines.append(f"Your first instruction came in time (a {late[2]} degree turn would still have worked), "
                             "so the loss came from what happened afterwards: later instructions or a misheard read-back.")
        if rec.get("caused_by"):
            lines.append(f"This conflict appeared within 15 s of an instruction to {rec['caused_by']}: "
                         f"check the trial-plan preview before sending a heading.")
    unfixed = [c for c in world.clearances if c.uncorrected and c.callsign in ep.pair]
    for c in unfixed:
        lines.append(f"{c.callsign} misheard the {c.wrong_field} in the read-back and you did not catch it "
                     f"(cleared: {c.text}; heard: {c.heard}).")
        verdict = "readback"
    return {"pair": ep.pair, "start_t": ep.start_t, "min_h": ep.min_h, "min_v": ep.min_v, "t_min": ep.t_min,
            "lines": lines, "verdict": verdict, "early": early, "late": late, "lead": lead}


def task_report_lines(world: World) -> List[Tuple[str, str, str]]:
    """(outcome, title, detail) for every task that was not answered correctly."""
    out: List[Tuple[str, str, str]] = []
    for t in world.tasks.log:
        if t.outcome not in ("wrong", "blank"):
            continue
        right = t.options[t.correct] if (t.correct is not None and t.options) else "n/a"
        if t.outcome == "blank":
            detail = "no answer in time" if not t.note else t.note
            if t.options:
                detail += f" (the answer was: {right})"
        else:
            given = t.options[t.answer] if t.answer is not None else "?"
            detail = f"you answered: {given}; correct: {right}"
        out.append((t.outcome, f"{_fmt_t(t.sim_time)}  {t.kind}: {t.prompt[:90]}", detail))
    return out
