"""Trajectory projection and conflict prediction.

A trajectory is sampled on a regular grid (t = 0, dt, 2 dt, ...). Aircraft that fly steady and straight are
projected analytically; aircraft that are turning, accelerating or about to reach a waypoint are projected by
stepping a copy of the aircraft with the same integrator the simulation uses. Between samples the motion is
treated as linear, so for straight flights the result is exact (tested against brute force).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .aircraft import Aircraft
from .geometry import angle_diff, dist, interval_abs_below, interval_inside_circle, vec_from_hdg, wind_vector

SEP_H = 5.0
SEP_V = 1000.0
HORIZON = 300.0
GRID = 10.0


@dataclass(slots=True)
class Traj:
    dt: float
    xs: List[float]
    ys: List[float]
    zs: List[float]
    xmin: float = 0.0
    xmax: float = 0.0
    ymin: float = 0.0
    ymax: float = 0.0
    zmin: float = 0.0
    zmax: float = 0.0

    def finish(self) -> "Traj":
        self.xmin, self.xmax = min(self.xs), max(self.xs)
        self.ymin, self.ymax = min(self.ys), max(self.ys)
        self.zmin, self.zmax = min(self.zs), max(self.zs)
        return self


@dataclass(slots=True)
class Conflict:
    a: str
    b: str
    t_start: float   # seconds from now when both minima are first violated
    t_end: float
    t_cpa: float     # time of minimum horizontal distance inside the episode
    min_h: float     # NM
    min_v: float     # ft, vertical separation at t_cpa

    @property
    def pair(self) -> Tuple[str, str]:
        return (self.a, self.b) if self.a < self.b else (self.b, self.a)


def _is_steady(ac: Aircraft, wind_from: float, wind_speed: float, horizon: float) -> bool:
    if ac.tas != ac.tgt_tas:
        return False
    want = ac.desired_heading(wind_from, wind_speed)
    if abs(angle_diff(want, ac.hdg)) > 1e-6 or ac.turn_dir is not None:
        return False
    wp = ac.next_wp
    if wp is not None:
        gs = ac.ground_speed(wind_vector(wind_from, wind_speed))
        if dist((ac.x, ac.y), (wp[1], wp[2])) < gs * horizon / 3600.0 + 3.0:
            return False
    return True


def build_trajectory(ac: Aircraft, wind_from: float = 0.0, wind_speed: float = 0.0,
                     horizon: float = HORIZON, dt: float = GRID) -> Traj:
    n = int(round(horizon / dt))
    xs = [ac.x]
    ys = [ac.y]
    zs = [ac.alt]
    if _is_steady(ac, wind_from, wind_speed, horizon):
        w = wind_vector(wind_from, wind_speed)
        vx, vy = vec_from_hdg(ac.hdg, ac.tas)
        vx += w[0]
        vy += w[1]
        vz = ac.vertical_rate()
        for k in range(1, n + 1):
            t = k * dt
            xs.append(ac.x + vx * t / 3600.0)
            ys.append(ac.y + vy * t / 3600.0)
            z = ac.alt + vz * t
            if vz > 0 and z > ac.tgt_alt:
                z = ac.tgt_alt
            elif vz < 0 and z < ac.tgt_alt:
                z = ac.tgt_alt
            zs.append(z)
    else:
        c = ac.copy()
        for _ in range(n):
            c.step(dt, wind_from, wind_speed)
            xs.append(c.x)
            ys.append(c.y)
            zs.append(c.alt)
    return Traj(dt, xs, ys, zs).finish()


def predict_pair(ta: Traj, tb: Traj, a: str = "A", b: str = "B",
                 sep_h: float = SEP_H, sep_v: float = SEP_V) -> Optional[Conflict]:
    """First predicted loss-of-separation episode of a pair, or None."""
    lim = sep_h + 0.0
    if (ta.xmin - tb.xmax > lim or tb.xmin - ta.xmax > lim or ta.ymin - tb.ymax > lim
            or tb.ymin - ta.ymax > lim or ta.zmin - tb.zmax >= sep_v or tb.zmin - ta.zmax >= sep_v):
        return None
    dt = ta.dt
    n = min(len(ta.xs), len(tb.xs)) - 1
    t_start = None
    t_end = 0.0
    best_h = 1e18
    best_t = 0.0
    best_v = 0.0
    for k in range(n):
        rx0 = tb.xs[k] - ta.xs[k]
        ry0 = tb.ys[k] - ta.ys[k]
        rx1 = tb.xs[k + 1] - ta.xs[k + 1]
        ry1 = tb.ys[k + 1] - ta.ys[k + 1]
        # quick reject: both ends far and the segment cannot dip inside (distance change per segment is bounded)
        d0 = math.hypot(rx0, ry0)
        d1 = math.hypot(rx1, ry1)
        seg_len = math.hypot(rx1 - rx0, ry1 - ry0)
        if t_start is None and min(d0, d1) > sep_h + seg_len:
            continue  # rigorous: every point of the segment is at least min(d0, d1) - seg_len away
        vx = (rx1 - rx0) / dt
        vy = (ry1 - ry0) / dt
        z0 = tb.zs[k] - ta.zs[k]
        z1 = tb.zs[k + 1] - ta.zs[k + 1]
        vz = (z1 - z0) / dt
        ih = interval_inside_circle(rx0, ry0, vx, vy, sep_h - 1e-6, 0.0, dt)   # -1e-6: a pass at exactly 5 NM is not a loss (float noise)
        if ih is None:
            if t_start is not None:
                break
            continue
        iv = interval_abs_below(z0, vz, sep_v, 0.0, dt)
        if iv is None:
            if t_start is not None:
                break
            continue
        lo = max(ih[0], iv[0])
        hi = min(ih[1], iv[1])
        if lo >= hi:
            if t_start is not None:
                break
            continue
        if t_start is None:
            t_start = k * dt + lo
        t_end = k * dt + hi
        # minimum horizontal distance within [lo, hi]
        vv = vx * vx + vy * vy
        if vv < 1e-12:
            tm = lo
        else:
            tm = min(max(-(rx0 * vx + ry0 * vy) / vv, lo), hi)
        h = math.hypot(rx0 + vx * tm, ry0 + vy * tm)
        if h < best_h:
            best_h = h
            best_t = k * dt + tm
            best_v = abs(z0 + vz * tm)
    if t_start is None:
        return None
    return Conflict(a, b, t_start, t_end, best_t, best_h, best_v)


def predict_all(trajs: Dict[str, Traj], sep_h: float = SEP_H, sep_v: float = SEP_V) -> List[Conflict]:
    names = sorted(trajs)
    out: List[Conflict] = []
    for i in range(len(names)):
        ta = trajs[names[i]]
        for j in range(i + 1, len(names)):
            c = predict_pair(ta, trajs[names[j]], names[i], names[j], sep_h, sep_v)
            if c is not None:
                out.append(c)
    out.sort(key=lambda c: c.t_start)
    return out


def zone_incursion(traj: Traj, cx: float, cy: float, radius: float) -> Optional[Tuple[float, float]]:
    """(t_enter, t_leave) of the first predicted penetration of a circular zone, or None.

    If the aircraft is still inside at the end of the horizon, t_leave is the horizon."""
    dt = traj.dt
    t_in: Optional[float] = None
    t_out = 0.0
    for k in range(len(traj.xs) - 1):
        rx0 = traj.xs[k] - cx
        ry0 = traj.ys[k] - cy
        vx = (traj.xs[k + 1] - traj.xs[k]) / dt
        vy = (traj.ys[k + 1] - traj.ys[k]) / dt
        iv = interval_inside_circle(rx0, ry0, vx, vy, radius, 0.0, dt)
        if iv is None:
            if t_in is not None:
                break
            continue
        if t_in is None:
            t_in = k * dt + iv[0]
        t_out = k * dt + iv[1]
    return None if t_in is None else (t_in, t_out)
