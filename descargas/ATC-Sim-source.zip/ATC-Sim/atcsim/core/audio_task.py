"""Spoken secondary task (pure, seeded, no pygame): short spoken items arrive while the player controls traffic.

Two variants, one per run:
  sum   digits are spoken one after another; type their sum (V, digits, Enter) before the window closes.
  code  a target code (ICAO letter + digits) is given at the start; codes are spoken now and then; press M only when
        the spoken code is the target. Items = targets (hit = correct, miss = blank) + false alarms (wrong);
        a correctly ignored non-target is not an item, so doing nothing scores 0, not 60 %.
Time runs in REAL seconds and only while the run is not paused (the world ticks this engine).
The engine only schedules "cues" (clip names with a time); the UI plays them. Same seed = same items.
"""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .scenario import make_rng

VARIANTS = ("sum", "code")
SETTINGS = ("auto", "sum", "code", "off")      # menu cycle; "auto" = on from DEFAULT_ON_FROM, variant alternates by seed
VOICES = ("es", "en")
DEFAULT_ON_FROM = 5                            # the audit places dual-task work at level 5 (dual cost target <= 5 pts at L5)
DIGITS = tuple(str(i) for i in range(10))
LETTERS = ("alfa", "bravo", "delta", "eco", "kilo", "lima", "oscar", "sierra", "tango", "victor")
TONE = "tone"
NICE = {"sum": "Suma oída", "code": "Código oído"}
SOLO = "Audio-only"
DEFAULT_DUR = {**{d: 0.42 for d in DIGITS}, **{l: 0.55 for l in LETTERS}, TONE: 0.2}


@dataclass(frozen=True)
class AudioSpec:
    level: int
    sum_len: Tuple[int, int]     # digits per sum item (min, max)
    code_len: int                # tokens per code: one letter + (code_len - 1) digits
    gap_s: float                 # mean real seconds between the close of one item and the start of the next
    token_gap_s: float           # silence between spoken tokens (speech rate)
    window_s: float              # seconds to answer after the last token
    match_share: float           # share of code items that are the target
    show_target: bool            # the target code stays on screen (low levels); else only for the first seconds


AUDIO_LEVELS: List[AudioSpec] = [
    AudioSpec(1, (3, 3), 3, 22.0, 0.45, 8.0, 0.40, True),
    AudioSpec(2, (3, 3), 3, 20.0, 0.42, 8.0, 0.40, True),
    AudioSpec(3, (3, 4), 3, 18.0, 0.38, 7.0, 0.40, True),
    AudioSpec(4, (4, 4), 3, 16.0, 0.35, 7.0, 0.40, True),
    AudioSpec(5, (4, 5), 3, 14.0, 0.30, 6.0, 0.35, False),
    AudioSpec(6, (5, 5), 4, 12.0, 0.27, 6.0, 0.35, False),
    AudioSpec(7, (5, 6), 4, 10.0, 0.24, 5.0, 0.35, False),
    AudioSpec(8, (6, 6), 4, 9.0, 0.21, 5.0, 0.30, False),
    AudioSpec(9, (6, 7), 4, 8.0, 0.18, 4.5, 0.30, False),
    AudioSpec(10, (7, 7), 4, 7.0, 0.15, 4.0, 0.30, False),
]
TARGET_SHOW_S = 10.0             # the target stays visible this long at levels without show_target


def audio_spec(level: int) -> AudioSpec:
    return AUDIO_LEVELS[max(1, min(10, int(level))) - 1]


def resolve_variant(setting: str, level: int, seed: int) -> Optional[str]:
    """Variant for a run from the menu setting: off -> None; sum / code -> that one at any level;
    auto -> None below DEFAULT_ON_FROM, else sums on even seeds and codes on odd seeds."""
    if setting in VARIANTS:
        return setting
    if setting == "auto" and int(level) >= DEFAULT_ON_FROM:
        return VARIANTS[int(seed) % 2]
    return None


def code_text(tokens: List[str]) -> str:
    return " ".join(t.upper() for t in tokens)


@dataclass
class AudioItem:
    id: int
    kind: str
    tokens: List[str]
    onsets: List[float]          # engine time of each token
    end: float                   # engine time the last token has been spoken
    deadline: float
    truth: Any                   # sum: int; code: bool (is the target)
    answer: Any = None
    outcome: Optional[str] = None    # correct | wrong | blank | info (ignored non-target)
    response_s: Optional[float] = None
    closed_at: Optional[float] = None

    @property
    def start(self) -> float:
        return self.onsets[0]


class AudioTask:
    def __init__(self, variant: str, level: int, seed: int, durations: Optional[Dict[str, float]] = None,
                 max_items: Optional[int] = None, gap_scale: float = 1.0, start_s: float = 8.0):
        if variant not in VARIANTS:
            raise ValueError(f"unknown variant {variant!r}")
        self.variant = variant
        self.level = max(1, min(10, int(level)))
        self.seed = int(seed)
        self.spec = audio_spec(self.level)
        self.rng = make_rng(seed, "audio-" + variant)
        self.dur = dict(DEFAULT_DUR)
        if durations:
            self.dur.update({k: float(v) for k, v in durations.items() if v and float(v) > 0})
        self.max_items = max_items
        self.gap_scale = gap_scale
        self.t = 0.0
        self.items: List[AudioItem] = []         # every item created, in order
        self.log: List[AudioItem] = []           # closed items, in order
        self.current: Optional[AudioItem] = None
        self.cues: List[Tuple[float, str]] = []  # (time, clip) not yet played
        self.finished = False
        self._next_id = 1
        self.target: List[str] = []
        self.next_start = start_s
        if variant == "code":
            self.target = self._random_code()
            at = 1.0
            self._cue(at - 0.35, TONE)
            ons = self._schedule(self.target, at)
            self.target_end = ons[-1] + self.dur.get(self.target[-1], 0.5)
            self.next_start = max(start_s, self.target_end + 4.0)
        else:
            self.target_end = 0.0

    # ---- helpers ---------------------------------------------------------------------------
    def _cue(self, at: float, clip: str) -> None:
        self.cues.append((at, clip))

    def _schedule(self, tokens: List[str], at: float) -> List[float]:
        ons = []
        t = at
        for tok in tokens:
            ons.append(t)
            self._cue(t, tok)
            t += self.dur.get(tok, 0.5) + self.spec.token_gap_s
        return ons

    def _random_code(self) -> List[str]:
        return [self.rng.choice(LETTERS)] + [self.rng.choice(DIGITS) for _ in range(self.spec.code_len - 1)]

    def _distractor(self) -> List[str]:
        """A non-target code. From level 5 it differs from the target in exactly one token (or two swapped digits),
        so the whole code must be heard; below that it is random."""
        tgt = self.target
        for _ in range(50):
            if self.level >= 5:
                c = list(tgt)
                r = self.rng.random()
                if r < 0.2 and len(c) >= 3 and c[1] != c[2]:
                    c[1], c[2] = c[2], c[1]
                else:
                    i = self.rng.randrange(len(c))
                    pool = LETTERS if i == 0 else DIGITS
                    c[i] = self.rng.choice([p for p in pool if p != tgt[i]])
            else:
                c = self._random_code()
            if c != tgt:
                return c
        return [LETTERS[(LETTERS.index(tgt[0]) + 1) % len(LETTERS)]] + tgt[1:]

    @property
    def show_target(self) -> bool:
        return self.variant == "code" and (self.spec.show_target or self.t < self.target_end + TARGET_SHOW_S)

    @property
    def speaking(self) -> bool:
        c = self.current
        return c is not None and c.start - 0.4 <= self.t < c.end

    @property
    def open_item(self) -> Optional[AudioItem]:
        """The item that a key press answers now (from its first token to its deadline)."""
        c = self.current
        return c if (c is not None and self.t >= c.start - 0.4) else None

    @property
    def done(self) -> bool:
        return self.max_items is not None and len(self.items) >= self.max_items and self.current is None

    # ---- time ------------------------------------------------------------------------------
    def _make_item(self) -> AudioItem:
        sp = self.spec
        at = self.t + 0.4
        if self.variant == "sum":
            n = self.rng.randint(sp.sum_len[0], sp.sum_len[1])
            toks = [self.rng.choice(DIGITS[1:]) for _ in range(n)]
            truth: Any = sum(int(x) for x in toks)
            self._cue(at - 0.35, TONE)
        else:
            is_t = self.rng.random() < sp.match_share
            toks = list(self.target) if is_t else self._distractor()
            truth = is_t
        ons = self._schedule(toks, at)
        end = ons[-1] + self.dur.get(toks[-1], 0.5)
        it = AudioItem(self._next_id, self.variant, toks, ons, end, end + sp.window_s, truth)
        self._next_id += 1
        self.items.append(it)
        return it

    def tick(self, dt: float) -> None:
        if self.finished:
            return
        self.t += dt
        c = self.current
        if c is not None and self.t >= c.deadline:
            self._close(c, None)
        if self.current is None and self.t >= self.next_start and not (
                self.max_items is not None and len(self.items) >= self.max_items):
            self.current = self._make_item()

    def pop_cues(self) -> List[str]:
        """Clips due now, in order (the UI plays them)."""
        due = [c for c in self.cues if c[0] <= self.t]
        if due:
            self.cues = [c for c in self.cues if c[0] > self.t]
        return [clip for _, clip in sorted(due, key=lambda x: x[0])]

    def _close(self, it: AudioItem, answer: Any) -> AudioItem:
        it.closed_at = self.t
        if answer is None:
            if it.kind == "code" and not it.truth:
                it.outcome = "info"                          # non-target correctly ignored: not an item
            else:
                it.outcome = "blank"
        else:
            it.answer = answer
            if it.kind == "sum":
                it.outcome = "correct" if int(answer) == it.truth else "wrong"
            else:
                it.outcome = "correct" if it.truth else "wrong"
            it.response_s = round(max(0.0, self.t - it.end), 3)
        self.cues = []                                       # future cues can only be the rest of this item: drop them
        self.log.append(it)
        self.current = None
        g = self.spec.gap_s * self.gap_scale * self.rng.uniform(0.7, 1.3)
        self.next_start = self.t + max(1.5, g)
        return it

    # ---- answers ---------------------------------------------------------------------------
    def answer_sum(self, value: int) -> Optional[AudioItem]:
        it = self.open_item
        if self.finished or it is None or it.kind != "sum":
            return None
        return self._close(it, int(value))

    def press_match(self) -> Optional[AudioItem]:
        it = self.open_item
        if self.finished or it is None or it.kind != "code":
            return None
        return self._close(it, True)

    def finish(self) -> None:
        """End of the run: an item already started is closed as if its window had run out; one not yet started is dropped."""
        if self.finished:
            return
        c = self.current
        if c is not None:
            if self.t >= c.start:
                self._close(c, None)
            else:
                self.items.remove(c)
                self.current = None
        self.cues = []
        self.finished = True

    # ---- results ---------------------------------------------------------------------------
    def summary(self) -> Dict[str, Any]:
        return summarize(self.log, self.variant, self.level, code_text(self.target) if self.target else "")


def summarize(log: List[AudioItem], variant: str, level: int, target: str = "") -> Dict[str, Any]:
    scored = [i for i in log if i.outcome in ("correct", "wrong", "blank")]
    c = sum(1 for i in scored if i.outcome == "correct")
    w = sum(1 for i in scored if i.outcome == "wrong")
    b = sum(1 for i in scored if i.outcome == "blank")
    n = c + w + b
    rts = [i.response_s for i in scored if i.outcome == "correct" and i.response_s is not None]
    out: Dict[str, Any] = {
        "variant": variant, "level": int(level), "n": n, "correct": c, "wrong": w, "blank": b,
        "accuracy": round(100.0 * c / n, 1) if n else 0.0,
        "rt_s": round(sum(rts) / len(rts), 2) if rts else None,
        "rt_median_s": round(statistics.median(rts), 2) if rts else None,
        "spoken": len(log),
    }
    if variant == "code":
        out["target"] = target
        out["ignored"] = sum(1 for i in log if i.outcome == "info")
    return out


def audio_cost(dual: Dict[str, Any], solo: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Dual-task cost of the spoken task: accuracy alone minus accuracy while controlling traffic (points), and the
    response-time increase (seconds). None when the records do not match (variant, level) or either is empty."""
    try:
        if dual.get("variant") != solo.get("variant") or int(dual.get("level", -1)) != int(solo.get("level", -2)):
            return None
        if not dual.get("n") or not solo.get("n"):
            return None
        pts = float(solo["accuracy"]) - float(dual["accuracy"])
        rt = None
        if dual.get("rt_s") is not None and solo.get("rt_s") is not None:
            rt = round(float(dual["rt_s"]) - float(solo["rt_s"]), 2)
    except (TypeError, ValueError, KeyError):
        return None
    return {"solo_accuracy": float(solo["accuracy"]), "solo_rt_s": solo.get("rt_s"), "cost_points": round(pts, 1),
            "cost_rt_s": rt, "solo_ts": solo.get("ts")}


def latest_solo(solos: List[Dict[str, Any]], variant: str, level: int) -> Optional[Dict[str, Any]]:
    for s in reversed(solos or []):
        if s.get("variant") == variant and s.get("level") == level and s.get("n"):
            return s
    return None
