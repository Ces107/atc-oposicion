"""The simulation world: aircraft, wind, clearances with pilot delay, separation monitoring, conflict
prediction bookkeeping, handoffs, secondary tasks and a recorder for replay. No pygame here."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .aircraft import Aircraft
from .geometry import angle_diff, bearing, dist, norm360, wind_vector
from .perf import TYPES
from .predict import (Conflict, HORIZON, SEP_H, SEP_V, Traj, build_trajectory, predict_all, predict_pair,
                      zone_incursion)
from .scenario import AircraftSpec, Scenario, level_spec, make_rng
from .sector import Sector, default_sector
from .tasks import Task, TaskEngine

TICK = 1.0                  # simulated seconds per physics tick
PREDICT_EVERY = 5           # ticks between conflict predictions
SNAP_EVERY = 2              # ticks between recorded snapshots
EXIT_LEVEL_TOL = 200.0      # ft
EXIT_GATE_TOL = 5.0         # NM
TRANSFER_RANGE = 20.0       # NM from the exit fix
MAX_EXTRA_S = 1800.0        # simulated seconds allowed after the last spawn


@dataclass
class Clearance:
    id: int
    callsign: str
    text: str
    hdg: Optional[float] = None
    alt: Optional[float] = None
    spd: Optional[float] = None
    turn_dir: Optional[str] = None
    dct: Optional[str] = None
    resume: bool = False
    issued_t: float = 0.0
    delay_left: float = 0.0
    applied: bool = False
    applied_t: Optional[float] = None
    wrong_field: Optional[str] = None      # 'hdg' or 'alt' when the pilot misheard it
    heard: Optional[str] = None
    uncorrected: bool = False
    hdg_change: Optional[float] = None     # degrees, signed, relative to the previous target
    needed: bool = True


@dataclass
class LossEpisode:
    a: str
    b: str
    start_t: float
    end_t: Optional[float] = None
    min_h: float = 99.0
    min_v: float = 99999.0
    t_min: float = 0.0
    ticks: int = 0

    @property
    def pair(self) -> Tuple[str, str]:
        return (self.a, self.b) if self.a < self.b else (self.b, self.a)


class World:
    def __init__(self, scenario: Scenario, sector: Optional[Sector] = None, tasks: bool = True,
                 pilot_delay: Optional[float] = None, record: bool = True):
        self.scenario = scenario
        self.sector = sector or default_sector()
        self.spec = level_spec(scenario.level)
        self.t = 0.0                    # simulated seconds
        self.real_t = 0.0
        self.scale = scenario.scale
        self.wind_from = scenario.wind_from
        self.wind_speed = scenario.wind_speed
        self.wind_vec = wind_vector(self.wind_from, self.wind_speed)
        self.aircraft: Dict[str, Aircraft] = {}
        self.pending_spawns = sorted(scenario.specs, key=lambda s: s.spawn_time)
        self.spawned = 0
        self.exited = 0
        self._acc = 0.0
        self._tick_n = 0
        self.clearances: List[Clearance] = []
        self.pending: List[Clearance] = []
        self._cl_id = 1
        self.events: List[Tuple[float, str, Dict[str, Any]]] = []
        self.losses: List[LossEpisode] = []
        self.active_loss: Dict[Tuple[str, str], LossEpisode] = {}
        self.zone_episodes: List[Dict[str, Any]] = []
        self._zone_active_ep: Dict[str, Dict[str, Any]] = {}
        self.records: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self.handoffs: List[Dict[str, Any]] = []
        self.task_stats: Dict[str, Dict[str, int]] = {}
        self.predicted: List[Conflict] = []
        self.trajs: Dict[str, Traj] = {}
        self.zone_alerts: Dict[str, Tuple[float, float]] = {}
        self.snapshots: List[Tuple[float, List[tuple]]] = []
        self.record = record
        self.predict_enabled = True
        self.force_readback = False
        self.tutorial_mode = False
        self.selected: Optional[str] = None
        self.actions: List[Tuple[float, str, str]] = []   # (sim t, kind, callsign) UI-level actions, for the tutorial
        self.pauses = 0
        self.finished = False
        self.last_cmd_t: Dict[str, float] = {}
        self.pilot_delay = self.spec.pilot_delay_s if pilot_delay is None else pilot_delay
        self.rng_delay = make_rng(scenario.seed, "delay")
        self.rng_rb = make_rng(scenario.seed, "readback")
        self.tasks = TaskEngine(self, make_rng(scenario.seed, "tasks"), self.spec)
        self.tasks.enabled = tasks
        self.readbacks = tasks
        self.messages: List[Tuple[float, str, str]] = []  # (sim t, level, text)
        self.log_event("start", level=scenario.level, seed=scenario.seed)
        while self.pending_spawns and self.pending_spawns[0].spawn_time <= 0.0:
            self._spawn(self.pending_spawns.pop(0))
        self._refresh_prediction()

    # ---- logging ------------------------------------------------------------------------
    def log_event(self, etype: str, **kw) -> None:
        self.events.append((self.t, etype, kw))

    def message(self, text: str, level: str = "info") -> None:
        self.messages.append((self.t, level, text))
        if len(self.messages) > 200:
            del self.messages[:100]

    # ---- zone ---------------------------------------------------------------------------
    @property
    def zone_active(self) -> bool:
        s = self.scenario
        return (s.zone_from is not None and self.spec.zone and self.t >= s.zone_from
                and (s.zone_until is None or self.t < s.zone_until))

    # ---- spawning -----------------------------------------------------------------------
    def _spawn(self, s: AircraftSpec) -> None:
        sec = self.sector
        route = sec.route_points(s.route)
        x, y, idx = route[0][1], route[0][2], 1
        left = s.advance_nm
        while left > 0 and idx < len(route):
            seg = dist((x, y), (route[idx][1], route[idx][2]))
            if left < seg:
                f = left / seg
                x, y = x + (route[idx][1] - x) * f, y + (route[idx][2] - y) * f
                left = 0
            else:
                x, y = route[idx][1], route[idx][2]
                left -= seg
                idx += 1
        idx = min(idx, len(route) - 1) if idx >= len(route) else idx
        ac = Aircraft(callsign=s.callsign, type_code=s.type_code, x=x, y=y, alt=s.entry_alt,
                      hdg=0.0, tas=s.tas, tgt_alt=s.entry_alt, tgt_tas=s.tas, route=route, route_idx=idx,
                      nav=True, exit_fix=s.route[-1], exit_alt=s.exit_alt, entry_alt=s.entry_alt,
                      spawn_time=self.t, freq_now=sec.own_freq, freq_next=sec.freq_by_gate.get(s.route[-1], "121.500"))
        ac.hdg = ac.desired_heading(self.wind_from, self.wind_speed)
        self.aircraft[s.callsign] = ac
        self.spawned += 1
        self.log_event("spawn", callsign=s.callsign, gate=s.route[0], exit=s.route[-1], entry_alt=s.entry_alt,
                       exit_alt=s.exit_alt)

    # ---- commands -----------------------------------------------------------------------
    def issue(self, callsign: str, hdg: Optional[float] = None, alt: Optional[float] = None,
              spd: Optional[float] = None, turn_dir: Optional[str] = None, dct: Optional[str] = None,
              resume: bool = False) -> Tuple[bool, str, Optional[Clearance]]:
        ac = self.aircraft.get(callsign)
        if ac is None:
            return False, f"{callsign} is not in the sector", None
        parts: List[str] = []
        if hdg is not None:
            hdg = float(norm360(round(hdg)))
            shown = int(round(hdg)) or 360
            side = {"L": "left ", "R": "right "}.get(turn_dir or "", "")
            parts.append(f"turn {side}heading {shown:03d}" if turn_dir else f"heading {shown:03d}")
        if alt is not None:
            alt = float(int(round(alt / 100.0)) * 100)
            if alt < 3000 or alt > ac.ac_type.ceiling:
                return False, f"{callsign}: unable, level outside {ac.ac_type.code} limits", None
            verb = "climb" if alt > ac.tgt_alt else ("descend" if alt < ac.tgt_alt else "maintain")
            parts.append(f"{verb} FL{int(alt/100):03d}")
        if spd is not None:
            t = ac.ac_type
            if spd < t.v_min or spd > t.v_max:
                return False, f"{callsign}: unable, speed outside {int(t.v_min)}-{int(t.v_max)} kt", None
            spd = float(int(round(spd)))
            parts.append(f"speed {int(spd)} kt")
        if dct is not None:
            names = [w[0] for w in ac.route]
            if dct not in names:
                return False, f"{callsign}: {dct} is not on its route", None
            if names.index(dct) < ac.route_idx:
                return False, f"{callsign}: {dct} is already behind it", None
            parts.append(f"direct {dct}")
        if resume:
            parts.append("resume own navigation")
        if not parts:
            return False, "nothing to send", None
        delay = self.pilot_delay * self.rng_delay.uniform(0.7, 1.3) if self.pilot_delay > 0 else 0.0
        cl = Clearance(self._cl_id, callsign, ", ".join(parts), hdg, alt, spd, turn_dir, dct, resume,
                       issued_t=self.t, delay_left=delay)
        self._cl_id += 1
        # "needed" heuristic for the workload metric
        involved = any(callsign in c.pair for c in self.predicted) or callsign in self.zone_alerts
        exit_change = alt is not None and abs(alt - ac.exit_alt) < abs(ac.tgt_alt - ac.exit_alt) + 1
        cl.needed = bool(involved or resume or dct or exit_change)
        if hdg is not None:
            cur = ac.tgt_hdg if ac.tgt_hdg is not None and not ac.nav else ac.hdg
            cl.hdg_change = angle_diff(hdg, cur)
        self.clearances.append(cl)
        self.pending.append(cl)
        self.log_event("command", id=cl.id, callsign=callsign, text=cl.text, needed=cl.needed)
        self.message(f"{callsign} <- {cl.text}", "cmd")
        if delay <= 0:
            self._apply(cl)
        return True, cl.text, cl

    def _apply(self, cl: Clearance) -> None:
        if cl in self.pending:
            self.pending.remove(cl)
        ac = self.aircraft.get(cl.callsign)
        if ac is None or cl.applied:
            return
        # snapshot the pair states before the first action for the "act early and little" analysis
        for pair, rec in self.records.items():
            if cl.callsign in pair and rec.get("action_states") is None:
                a = self.aircraft.get(pair[0])
                b = self.aircraft.get(pair[1])
                if a is not None and b is not None:
                    rec["action_states"] = (a.copy(), b.copy(), self.t)
                    rec["action_lead"] = rec["last_t_start"]
        cl.applied = True
        cl.applied_t = self.t
        self.last_cmd_t[cl.callsign] = self.t
        hdg, alt = cl.hdg, cl.alt
        make_rb = False
        if self.force_readback and (cl.hdg is not None or cl.alt is not None):
            make_rb = True
            self.force_readback = False
        elif self.readbacks and "readback" in self.spec.kinds and (cl.hdg is not None or cl.alt is not None):
            make_rb = self.rng_rb.random() < 0.55
        wrong = make_rb and not self.tutorial_mode and self.rng_rb.random() < self.spec.readback_error_rate
        heard_parts: List[str] = []
        if hdg is not None:
            h_heard = hdg
            if wrong and (cl.alt is None or self.rng_rb.random() < 0.5):
                h_heard = norm360(hdg + self.rng_rb.choice([-30, -20, -10, 10, 20, 30]))
                cl.wrong_field = "hdg"
            heard_parts.append(f"heading {(int(round(h_heard)) or 360):03d}")
            hdg = h_heard
            ac.set_heading(hdg, self._effective_turn(ac, hdg, cl.turn_dir))
        if alt is not None:
            a_heard = alt
            if wrong and cl.wrong_field is None:
                options = [alt + d for d in (-2000, -1000, 1000, 2000) if 3000 <= alt + d <= ac.ac_type.ceiling]
                if options:
                    a_heard = self.rng_rb.choice(options)
                    cl.wrong_field = "alt"
            heard_parts.append(f"FL{int(a_heard/100):03d}")
            alt = a_heard
            ac.set_altitude(alt)
        if cl.spd is not None:
            ac.set_speed(cl.spd)
        if cl.dct is not None:
            ac.direct_to(cl.dct)
        if cl.resume:
            ac.resume_nav(self.wind_vec)
        if wrong and cl.wrong_field is None:
            wrong = False
        if make_rb:
            cl.heard = ", ".join(heard_parts)
            self.tasks.create_readback(cl, cl.heard, wrong)
        for pair, rec in self.records.items():
            if cl.callsign in pair:
                rec["commands"].append((self.t, cl.id, cl.callsign, cl.text, cl.hdg_change))
        self.log_event("applied", id=cl.id, callsign=cl.callsign, wrong=cl.wrong_field)
        self._refresh_prediction()

    @staticmethod
    def _effective_turn(ac: Aircraft, hdg: float, turn: Optional[str]) -> Optional[str]:
        """A forced turn direction is dropped when the aircraft has meanwhile turned past the target by up to 30 degrees
        (the pilot would otherwise fly a near-complete circle because of the 2-3 s delay)."""
        if turn is None:
            return None
        d = angle_diff(hdg, ac.hdg)
        if (turn == "R" and -30.0 <= d < 0.0) or (turn == "L" and 0.0 < d <= 30.0):
            return None
        return turn

    def request_transfer(self, callsign: str) -> Tuple[bool, str, Optional[Task]]:
        ac = self.aircraft.get(callsign)
        if ac is None:
            return False, "no such aircraft", None
        if ac.transferred or ac.flags.get("tfr_done"):
            return False, f"{callsign} already transferred", None
        fx = self.sector.fixes[ac.exit_fix]
        if dist((ac.x, ac.y), fx) > TRANSFER_RANGE:
            return False, f"{callsign}: not within {int(TRANSFER_RANGE)} NM of {ac.exit_fix} yet", None
        t = self.tasks.create_transfer(callsign)
        if t is None:
            return False, "transfer already in progress", None
        return True, "select frequency", t

    # ---- task results -------------------------------------------------------------------
    def on_task_finished(self, t: Task) -> None:
        st = self.task_stats.setdefault(t.kind, {"correct": 0, "wrong": 0, "blank": 0})
        if t.outcome in st:
            st[t.outcome] += 1
        ac = self.aircraft.get(t.aircraft) if t.aircraft else None
        if t.kind == "readback":
            cl = next((c for c in self.clearances if c.id == t.data.get("clearance")), None)
            if cl is not None and t.data.get("wrong"):
                if t.outcome == "correct" and ac is not None:      # player flagged the error
                    # never undo a NEWER instruction: only re-fly a field that no later applied clearance has set
                    later = [c for c in self.clearances if c.callsign == cl.callsign and c.id > cl.id and c.applied]
                    if cl.hdg is not None and not any(c.hdg is not None or c.resume or c.dct for c in later):
                        ac.set_heading(cl.hdg, self._effective_turn(ac, cl.hdg, cl.turn_dir))
                    if cl.alt is not None and not any(c.alt is not None for c in later):
                        ac.set_altitude(cl.alt)
                    self.log_event("readback_fixed", callsign=cl.callsign)
                    self._refresh_prediction()
                else:
                    cl.uncorrected = True
                    self.log_event("readback_missed", callsign=cl.callsign, field=cl.wrong_field)
        elif t.kind == "transfer" and ac is not None:
            ac.flags["tfr_done"] = True
            if t.outcome == "correct":
                ac.transferred = True
                ac.freq_now = ac.freq_next
                self.message(f"{ac.callsign} contact {ac.freq_next}", "info")
        elif t.kind == "levelreq" and ac is not None and t.outcome != "blank":
            if t.answer == 0:
                self.issue(ac.callsign, alt=t.data["alt"])

    # ---- prediction ---------------------------------------------------------------------
    def _refresh_prediction(self) -> None:
        if not self.predict_enabled:
            return
        self.trajs = {cs: build_trajectory(a, self.wind_from, self.wind_speed) for cs, a in self.aircraft.items()}
        self.predicted = predict_all(self.trajs)
        self.zone_alerts = {}
        if self.spec.zone and self.scenario.zone_from is not None:
            z = self.sector.zones[0]
            for cs, tr in self.trajs.items():
                inc = zone_incursion(tr, z.x, z.y, z.radius)
                if inc is not None:
                    # only warn if the zone is (or will be) active at that time
                    if self.scenario.zone_from is not None and (self.t + inc[1] >= self.scenario.zone_from) and (
                            self.scenario.zone_until is None or self.t + inc[0] < self.scenario.zone_until):
                        self.zone_alerts[cs] = inc
        for c in self.predicted:
            rec = self.records.get(c.pair)
            if rec is None:
                rec = {"pair": c.pair, "first_t": self.t, "first_lead": c.t_start, "first_min_h": c.min_h,
                       "states": (self.aircraft[c.a].copy(), self.aircraft[c.b].copy(), self.t),
                       "commands": [], "action_states": None, "action_lead": None, "lost": False,
                       "last_t": self.t, "last_t_start": c.t_start, "caused_by": None, "resolved_t": None}
                for cs in c.pair:
                    lc = self.last_cmd_t.get(cs)
                    if lc is not None and self.t - lc <= 15.0:
                        rec["caused_by"] = cs
                self.records[c.pair] = rec
                self.log_event("conflict_predicted", pair=c.pair, lead=c.t_start, min_h=c.min_h)
            rec["last_t"] = self.t
            rec["last_t_start"] = c.t_start

    def what_if(self, callsign: str, hdg: Optional[float] = None, alt: Optional[float] = None,
                spd: Optional[float] = None, turn_dir: Optional[str] = None) -> Tuple[List[Conflict], Optional[Tuple[float, float]]]:
        """Conflicts (and zone incursion) that would be predicted if this instruction were applied now."""
        ac = self.aircraft.get(callsign)
        if ac is None:
            return [], None
        c = ac.copy()
        if hdg is not None:
            c.set_heading(hdg, turn_dir)
        if alt is not None:
            c.set_altitude(alt)
        if spd is not None:
            c.set_speed(spd)
        tr = build_trajectory(c, self.wind_from, self.wind_speed)
        out: List[Conflict] = []
        for cs, other in self.trajs.items():
            if cs == callsign:
                continue
            cf = predict_pair(tr, other, callsign, cs)
            if cf is not None:
                out.append(cf)
        out.sort(key=lambda x: x.t_start)
        zone = None
        if self.spec.zone and self.scenario.zone_from is not None and self.sector.zones:
            z = self.sector.zones[0]
            zone = zone_incursion(tr, z.x, z.y, z.radius)
        return out, zone

    def level_change_is_safe(self, callsign: str, new_alt: float) -> bool:
        if not self.trajs:
            self._refresh_prediction()
        conf, _ = self.what_if(callsign, alt=new_alt)
        return not conf

    # ---- main loop ----------------------------------------------------------------------
    def advance(self, real_dt: float) -> None:
        """Advance by `real_dt` REAL seconds (the simulation clock runs `scale` times faster)."""
        if self.finished:
            return
        self.real_t += real_dt
        # pilot delay runs in real seconds
        for cl in list(self.pending):
            cl.delay_left -= real_dt
            if cl.delay_left <= 0:
                self._apply(cl)
        self._acc += real_dt * self.scale
        n = 0
        while self._acc >= TICK and n < 200:
            self._acc -= TICK
            self._tick()
            n += 1
        self.tasks.tick(real_dt)
        if self._is_over():
            self.finish()

    def _is_over(self) -> bool:
        if self.pending_spawns:
            return False
        if not self.aircraft:
            return True
        return self.t > self.scenario.spawn_end + MAX_EXTRA_S

    def _tick(self) -> None:
        self.t += TICK
        self._tick_n += 1
        while self.pending_spawns and self.pending_spawns[0].spawn_time <= self.t:
            self._spawn(self.pending_spawns.pop(0))
            if self._tick_n % PREDICT_EVERY != 0:
                self._refresh_prediction()
        for ac in list(self.aircraft.values()):
            ac.step(TICK, self.wind_from, self.wind_speed)
        for cs, ac in list(self.aircraft.items()):
            if self.t - ac.spawn_time >= 10.0 and not self.sector.contains((ac.x, ac.y)):
                self._exit(ac)
        self._check_separation()
        self._check_zone()
        if self._tick_n % PREDICT_EVERY == 0:
            self._refresh_prediction()
            self._close_records()
        if self.record and self._tick_n % SNAP_EVERY == 0:
            self.snapshots.append((self.t, [(a.callsign, round(a.x, 3), round(a.y, 3), round(a.alt), round(a.hdg, 1),
                                             round(a.tas)) for a in self.aircraft.values()]))

    def _close_records(self) -> None:
        cur = {c.pair for c in self.predicted}
        for pair, rec in self.records.items():
            if pair not in cur and rec["resolved_t"] is None and not rec["lost"]:
                rec["resolved_t"] = self.t

    def _check_separation(self) -> None:
        acs = sorted(self.aircraft.values(), key=lambda a: (a.x, a.callsign))     # sweep along x: far pairs are never looked at
        now: Dict[Tuple[str, str], Tuple[float, float]] = {}
        n_ac = len(acs)
        for i in range(n_ac):
            a = acs[i]
            for j in range(i + 1, n_ac):
                b = acs[j]
                dx = a.x - b.x
                if dx <= -SEP_H:
                    break
                dy = a.y - b.y
                if dy >= SEP_H or dy <= -SEP_H:
                    continue
                h = math.hypot(dx, dy)
                if h >= SEP_H:
                    continue
                v = abs(a.alt - b.alt)
                if v >= SEP_V:
                    continue
                pair = (a.callsign, b.callsign) if a.callsign < b.callsign else (b.callsign, a.callsign)
                now[pair] = (h, v)
        for pair, (h, v) in now.items():
            ep = self.active_loss.get(pair)
            if ep is None:
                ep = LossEpisode(pair[0], pair[1], self.t)
                self.active_loss[pair] = ep
                self.losses.append(ep)
                rec = self.records.get(pair)
                if rec is None:
                    rec = {"pair": pair, "first_t": None, "first_lead": None, "first_min_h": None, "states": None,
                           "commands": [], "action_states": None, "action_lead": None, "lost": True,
                           "last_t": self.t, "last_t_start": 0.0, "caused_by": None, "resolved_t": None}
                    self.records[pair] = rec
                rec["lost"] = True
                self.log_event("los_start", pair=pair, h=h, v=v)
                self.message(f"LOSS OF SEPARATION {pair[0]} / {pair[1]}", "alarm")
            ep.ticks += 1
            if h < ep.min_h or (h == ep.min_h and v < ep.min_v):
                ep.min_h, ep.min_v, ep.t_min = h, v, self.t
        for pair in list(self.active_loss):
            if pair not in now:
                ep = self.active_loss.pop(pair)
                ep.end_t = self.t
                self.log_event("los_end", pair=pair, min_h=ep.min_h)

    def _check_zone(self) -> None:
        if not self.zone_active or not self.sector.zones:
            for cs, ep in list(self._zone_active_ep.items()):
                ep["end_t"] = self.t
                del self._zone_active_ep[cs]
            return
        z = self.sector.zones[0]
        for cs, ac in self.aircraft.items():
            inside = math.hypot(ac.x - z.x, ac.y - z.y) < z.radius
            ep = self._zone_active_ep.get(cs)
            if inside and ep is None:
                ep = {"callsign": cs, "start_t": self.t, "end_t": None, "zone": z.name}
                self._zone_active_ep[cs] = ep
                self.zone_episodes.append(ep)
                self.log_event("zone_in", callsign=cs, zone=z.name)
                self.message(f"OUT OF BOUNDS: {cs} entered {z.name}", "alarm")
            elif not inside and ep is not None:
                ep["end_t"] = self.t
                del self._zone_active_ep[cs]

    def _exit(self, ac: Aircraft, forced: bool = False) -> None:
        cs = ac.callsign
        fx = self.sector.fixes.get(ac.exit_fix, (ac.x, ac.y))
        gd = dist((ac.x, ac.y), fx)
        alt_err = ac.alt - ac.exit_alt
        gate_ok = gd <= EXIT_GATE_TOL
        level_ok = abs(alt_err) <= EXIT_LEVEL_TOL
        # an open transfer prompt for this aircraft expires; a missing transfer is a blank item
        for t in list(self.tasks.tasks):
            if t.aircraft == cs and t.kind == "transfer":
                self.tasks._expire(t)
        if not ac.transferred and not ac.flags.get("tfr_done"):
            blank = Task(-1, "transfer", f"{cs} left the sector without a transfer of communication", [], None,
                         0, 0, self.real_t, cs, {}, state="expired", outcome="blank", closed_at=self.real_t,
                         sim_time=self.t, note="left without transfer")
            self.tasks.log.append(blank)
            self.on_task_finished(blank)
        h = {"callsign": cs, "t": self.t, "gate": ac.exit_fix, "gate_dist": gd, "gate_ok": gate_ok,
             "alt": ac.alt, "exit_alt": ac.exit_alt, "alt_err": alt_err, "level_ok": level_ok,
             "transferred": ac.transferred, "outcome": "correct" if (gate_ok and level_ok) else "wrong",
             "transit_s": self.t - ac.spawn_time, "forced": forced}
        if forced:            # still inside the sector when the run ended: the handoff never happened
            h["outcome"] = "blank"
            h["gate_ok"] = h["level_ok"] = False
        self.handoffs.append(h)
        self.log_event("handoff", **h)
        self.exited += 1
        del self.aircraft[cs]
        if self.selected == cs:
            self.selected = None
        for pair in list(self.active_loss):
            if cs in pair:
                ep = self.active_loss.pop(pair)
                ep.end_t = self.t
        zep = self._zone_active_ep.pop(cs, None)
        if zep:
            zep["end_t"] = self.t
        self.trajs.pop(cs, None)
        self.predicted = [c for c in self.predicted if cs not in c.pair]
        self.zone_alerts.pop(cs, None)

    def finish(self) -> None:
        if self.finished:
            return
        self.finished = True
        for ac in list(self.aircraft.values()):
            self._exit(ac, forced=True)
        self.tasks.finish_all()
        for pair, ep in list(self.active_loss.items()):
            ep.end_t = self.t
        self.log_event("end", t=self.t)

    def advance_sim(self, sim_seconds: float) -> None:
        """Convenience for tests and bots: advance by simulated seconds (real time = sim / scale)."""
        self.advance(sim_seconds / self.scale)

    # ---- queries ------------------------------------------------------------------------
    def select(self, callsign: Optional[str]) -> None:
        self.selected = callsign if callsign in self.aircraft else None
        if self.selected:
            self.actions.append((self.t, "select", self.selected))

    def note_action(self, kind: str, callsign: str = "") -> None:
        self.actions.append((self.t, kind, callsign))

    def replay_clip(self, t0: float, t1: float) -> List[Tuple[float, List[tuple]]]:
        return [s for s in self.snapshots if t0 <= s[0] <= t1]

    def open_conflict_pairs(self) -> List[Conflict]:
        return list(self.predicted)
