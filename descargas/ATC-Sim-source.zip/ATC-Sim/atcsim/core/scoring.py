"""Scoring: turns the world's event records into the project's Correct / Wrong / Blank item counts, a 0-100
score with an itemised breakdown, per-component accuracy (worst component highlighted) and the adaptive rule."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from .scenario import level_spec
from .tasks import NICE
from .world import World

LOSS_BASE = 10.0
LOSS_DEPTH = 12.0
ZONE_PENALTY = 6.0
HANDOFF_PENALTY = 3.0
TASK_WRONG = 1.5
TASK_BLANK = 2.0
UNNEEDED = 0.5
UNNEEDED_CAP = 8.0


@dataclass
class RunResult:
    level: int
    seed: int
    mode: str
    correct: int = 0
    wrong: int = 0
    blank: int = 0
    real_seconds: float = 0.0
    sim_seconds: float = 0.0
    losses: int = 0
    zone_incursions: int = 0
    score: float = 100.0
    breakdown: List[Tuple[str, float]] = field(default_factory=list)
    components: Dict[str, Dict[str, int]] = field(default_factory=dict)
    thirds: List[Optional[float]] = field(default_factory=list)
    thirds_data: Optional[List[Dict[str, float]]] = None   # schema-thirds shape {n,c,b,s} x3, or None if < 9 items
    unneeded: int = 0
    commands: int = 0
    pauses: int = 0
    goal_text: str = ""
    met: bool = False
    assisted: bool = False
    aircraft: int = 0

    @property
    def items(self) -> int:
        return self.correct + self.wrong + self.blank

    @property
    def accuracy(self) -> float:
        return 100.0 * self.correct / self.items if self.items else 0.0

    @property
    def seconds_per_item(self) -> float:
        return self.real_seconds / self.items if self.items else 0.0

    def component_accuracy(self, name: str) -> Optional[float]:
        c = self.components.get(name)
        if not c:
            return None
        n = c["correct"] + c["wrong"] + c["blank"]
        return 100.0 * c["correct"] / n if n else None

    def worst_component(self) -> Optional[Tuple[str, float]]:
        best: Optional[Tuple[str, float]] = None
        for k in self.components:
            a = self.component_accuracy(k)
            if a is not None and (best is None or a < best[1]):
                best = (k, a)
        return best


def _bump(comp: Dict[str, Dict[str, int]], name: str, outcome: str) -> None:
    c = comp.setdefault(name, {"correct": 0, "wrong": 0, "blank": 0})
    c[outcome] += 1


def thirds_schema(timed: List[Tuple[float, str]], end: float, real_seconds: float) -> Optional[List[Dict[str, float]]]:
    """Endurance data in the shared schema (coord/SCHEMA-thirds.md): time thirds of the run, group = min(2, floor(t*3/end)).
    The sim has no per-item seconds, so s = real seconds of the run / 3 for each third. None when fewer than 9 items."""
    if len(timed) < 9:
        return None
    out = [{"n": 0, "c": 0, "b": 0, "s": round(real_seconds / 3.0, 1)} for _ in range(3)]
    for tt, o in timed:
        g = max(0, min(2, int(tt * 3.0 / end)))
        out[g]["n"] += 1
        if o == "correct":
            out[g]["c"] += 1
        elif o == "blank":
            out[g]["b"] += 1
    return out


def compute_result(world: World, mode: str = "Ladder") -> RunResult:
    spec = level_spec(world.scenario.level)
    r = RunResult(world.scenario.level, world.scenario.seed, mode)
    r.real_seconds = world.real_t
    r.sim_seconds = world.t
    r.aircraft = world.spawned
    r.pauses = world.pauses
    comp: Dict[str, Dict[str, int]] = {}
    timed: List[Tuple[float, str]] = []   # (sim time, outcome)
    score = 100.0
    breakdown: List[Tuple[str, float]] = []

    # separation: one item per pair that was ever predicted to conflict or actually lost separation
    for rec in world.records.values():
        if rec["first_t"] is None and not rec["lost"]:
            continue
        out = "wrong" if rec["lost"] else "correct"
        _bump(comp, "Separation", out)
        t = rec["first_t"] if rec["first_t"] is not None else world.t
        timed.append((t, out))
    r.losses = len(world.losses)
    for ep in world.losses:
        pen = LOSS_BASE + LOSS_DEPTH * (1.0 - min(ep.min_h, 5.0) / 5.0)
        score -= pen
        breakdown.append((f"Loss of separation {ep.a}/{ep.b} (min {ep.min_h:.1f} NM)", -pen))

    # restricted zone
    r.zone_incursions = len(world.zone_episodes)
    for ep in world.zone_episodes:
        _bump(comp, "Restricted area", "wrong")
        timed.append((ep["start_t"], "wrong"))
        score -= ZONE_PENALTY
        breakdown.append((f"Entered restricted area {ep['zone']}: {ep['callsign']}", -ZONE_PENALTY))

    # handoffs
    for h in world.handoffs:
        _bump(comp, "Handoff", h["outcome"])
        timed.append((h["t"], h["outcome"]))
        if h["outcome"] == "blank":
            score -= HANDOFF_PENALTY
            breakdown.append((f"{h['callsign']} never left the sector before the run ended", -HANDOFF_PENALTY))
        elif h["outcome"] == "wrong":
            score -= HANDOFF_PENALTY
            why = []
            if not h["gate_ok"]:
                why.append(f"{h['gate_dist']:.0f} NM from gate {h['gate']}")
            if not h["level_ok"]:
                why.append(f"{h['alt_err']:+.0f} ft from exit level")
            breakdown.append((f"Bad handoff {h['callsign']}: " + ", ".join(why), -HANDOFF_PENALTY))

    # tasks
    nt_wrong = nt_blank = 0
    for t in world.tasks.log:
        if t.outcome not in ("correct", "wrong", "blank"):
            continue
        name = NICE.get(t.kind, t.kind)
        _bump(comp, name, t.outcome)
        timed.append((t.sim_time, t.outcome))
        if t.outcome == "wrong":
            nt_wrong += 1
        elif t.outcome == "blank":
            nt_blank += 1
    if nt_wrong:
        score -= TASK_WRONG * nt_wrong
        breakdown.append((f"{nt_wrong} wrong task answer(s)", -TASK_WRONG * nt_wrong))
    if nt_blank:
        score -= TASK_BLANK * nt_blank
        breakdown.append((f"{nt_blank} unanswered task(s) / missed transfer(s)", -TASK_BLANK * nt_blank))

    # workload discipline
    r.commands = len(world.clearances)
    r.unneeded = sum(1 for c in world.clearances if not c.needed)
    if r.unneeded:
        pen = min(UNNEEDED_CAP, UNNEEDED * r.unneeded)
        score -= pen
        breakdown.append((f"{r.unneeded} instruction(s) with no predicted need", -pen))

    r.components = comp
    r.correct = sum(c["correct"] for c in comp.values())
    r.wrong = sum(c["wrong"] for c in comp.values())
    r.blank = sum(c["blank"] for c in comp.values())
    r.score = max(0.0, score)
    r.breakdown = breakdown

    # accuracy by thirds of the run (fatigue / drift)
    end = max(world.t, 1.0)
    thirds: List[Optional[float]] = []
    for i in range(3):
        lo, hi = end * i / 3.0, end * (i + 1) / 3.0 + (1e-9 if i == 2 else 0)
        items = [o for (tt, o) in timed if lo <= tt < hi or (i == 2 and tt >= lo)]
        thirds.append(100.0 * sum(1 for o in items if o == "correct") / len(items) if items else None)
    r.thirds = thirds
    r.thirds_data = thirds_schema(timed, end, r.real_seconds)

    r.goal_text = f"accuracy >= {int(spec.goal_accuracy * 100)}% and 0 losses"
    r.met = bool(r.items and r.accuracy >= spec.goal_accuracy * 100.0 and r.losses == 0)
    r.assisted = bool(world.pauses > 0 and world.scenario.level >= 5)
    return r


RADAR_ONLY = "Radar-only"      # paired-seed baseline mode: same seed and traffic, no interrupting tasks
DUAL_COMPONENTS = ("Separation", "Handoff", "Restricted area")


def endurance_text(thirds: Optional[List[Dict[str, float]]]) -> str:
    """Endurance line for the debrief: fade = accuracy(third 3) - accuracy(third 1); only when both thirds have n >= 8."""
    if not thirds or len(thirds) != 3:
        return "Endurance: not enough items (needs 9 or more) to compare the thirds."
    a1, a3 = thirds[0], thirds[2]
    if a1["n"] < 8 or a3["n"] < 8:
        return "Endurance: too few items in the first or last third (needs 8 or more in each) to report a fade."
    fade = 100.0 * a3["c"] / a3["n"] - 100.0 * a1["c"] / a1["n"]
    verdict = "steady" if fade > -3 else ("small drop" if fade > -5 else "fading: shorten sessions or rest before the run")
    return f"Endurance: last third {fade:+.0f} points versus first third ({verdict}; n={a1['n']}/{a3['n']})."


def _radar_accuracy(components: Dict[str, Dict[str, int]]) -> Optional[Tuple[float, int]]:
    c = sum(v.get("correct", 0) for k, v in components.items() if k in DUAL_COMPONENTS)
    n = sum(v.get("correct", 0) + v.get("wrong", 0) + v.get("blank", 0) for k, v in components.items() if k in DUAL_COMPONENTS)
    return (100.0 * c / n, n) if n else None


def dual_task_cost(radar_only: Dict[str, Any], full: Dict[str, Any]) -> Optional[Dict[str, float]]:
    """Dual-task cost of two saved run records with the same seed and level: accuracy on the radar items (separation, handoff,
    restricted area) without interrupting tasks minus the same with them. cost_points is in percentage points (the spec's
    threshold is <= 5 at level 5); cost_rel = points / radar-only accuracy. None when the records are not a valid pair."""
    try:
        if radar_only.get("mode") != RADAR_ONLY or full.get("mode") == RADAR_ONLY:
            return None
        if radar_only["seed"] != full["seed"] or radar_only["level"] != full["level"]:
            return None
        a = _radar_accuracy(radar_only.get("components", {}))
        b = _radar_accuracy(full.get("components", {}))
    except (KeyError, TypeError, AttributeError):
        return None
    if a is None or b is None:
        return None
    return {"radar_only": a[0], "full": b[0], "cost_points": a[0] - b[0], "cost_rel": (a[0] - b[0]) / a[0] if a[0] else 0.0,
            "n_radar_only": a[1], "n_full": b[1]}


def latest_pair_cost(runs: List[Dict[str, Any]], rec: Dict[str, Any]) -> Optional[Dict[str, float]]:
    """Cost for `rec` (radar-only or full) with the most recent counterpart run of the same seed and level in `runs`."""
    for x in reversed(runs):
        if x is rec:
            continue
        pair = (rec, x) if rec.get("mode") == RADAR_ONLY else (x, rec)
        c = dual_task_cost(*pair)
        if c is not None:
            return c
    return None


# ---- adaptive mode ---------------------------------------------------------------------
def default_adaptive() -> Dict[str, int]:
    return {"level": 1, "ok": 0, "bad": 0}


def adaptive_update(state: Dict[str, int], met: bool, assisted: bool = False) -> Dict[str, int]:
    """+1 level after 2 clean successes (levels 1-4) or 3 (levels 5+); -1 after 2 failures in a row."""
    s = dict(state)
    if assisted:
        return s
    if met:
        s["ok"] += 1
        s["bad"] = 0
        need = 2 if s["level"] < 5 else 3
        if s["ok"] >= need and s["level"] < 10:
            s["level"] += 1
            s["ok"] = 0
    else:
        s["bad"] += 1
        s["ok"] = 0
        if s["bad"] >= 2 and s["level"] > 1:
            s["level"] -= 1
            s["bad"] = 0
    return s
