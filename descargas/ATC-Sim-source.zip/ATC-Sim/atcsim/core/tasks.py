"""Interrupting secondary tasks (readback check, frequency transfer, alert acknowledge, level request,
priority-callsign recall, estimate time to conflict, ETA estimate).

Timers here run in REAL seconds (human time), not simulated seconds.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .geometry import dist

# keys the UI uses for each task kind (index in the list = option index)
KEYS: Dict[str, List[str]] = {
    "readback": ["y", "n"],
    "transfer": ["1", "2", "3"],
    "alert": ["space"],
    "levelreq": ["a", "d"],
    "memory": ["1", "2", "3", "4"],
    "ttc": ["1", "2", "3", "4", "5", "6"],
    "eta": ["1", "2", "3", "4", "5"],
}
LABELS = {
    "readback": "READ-BACK CHECK", "transfer": "TRANSFER OF COMMUNICATION", "alert": "ALERT",
    "levelreq": "LEVEL REQUEST", "memory": "PRIORITY RECALL", "ttc": "TIME TO CONFLICT",
    "eta": "ETA ESTIMATE", "memshow": "MEMORISE",
}
NICE = {"readback": "Read-back check", "transfer": "Transfer of communication", "alert": "Alert (vigilance)",
        "levelreq": "Level request", "memory": "Priority recall", "ttc": "Time to conflict", "eta": "ETA estimate"}
TTC_BUCKETS = ["< 1 min", "1-2 min", "2-3 min", "3-4 min", "> 4 min", "No conflict"]


@dataclass
class Task:
    id: int
    kind: str
    prompt: str
    options: List[str]
    correct: Optional[int]
    time_left: float
    time_total: float
    created: float                      # real time
    aircraft: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    state: str = "open"                 # open | done | expired
    answer: Optional[int] = None
    outcome: Optional[str] = None       # correct | wrong | blank | info
    response_s: Optional[float] = None
    closed_at: Optional[float] = None
    sim_time: float = 0.0               # simulated time of creation (for the debrief)
    note: str = ""

    @property
    def is_open(self) -> bool:
        return self.state == "open"


def ttc_bucket(seconds: float) -> int:
    m = seconds / 60.0
    if m < 1:
        return 0
    if m < 2:
        return 1
    if m < 3:
        return 2
    if m < 4:
        return 3
    return 4


class TaskEngine:
    def __init__(self, world, rng, spec):
        self.world = world
        self.rng = rng
        self.spec = spec
        self.tasks: List[Task] = []      # open tasks
        self.log: List[Task] = []        # every finished task, in order
        self._next_id = 1
        self.real_t = 0.0
        self._next_random = self._gap(first=True)
        self._pending_memory: List[Dict[str, Any]] = []
        self.enabled = True

    # ---- helpers -----------------------------------------------------------------------
    def _gap(self, first: bool = False) -> float:
        g = self.spec.task_gap_s * self.rng.uniform(0.6, 1.4)
        return self.real_t + (g * 0.7 if first else g)

    def _new(self, kind, prompt, options, correct, total, aircraft="", data=None) -> Task:
        if getattr(self.world, "tutorial_mode", False) and kind != "memshow":
            total = max(total, 45.0)
        t = Task(self._next_id, kind, prompt, options, correct, total, total, self.real_t, aircraft,
                 data or {}, sim_time=self.world.t)
        self._next_id += 1
        self.tasks.append(t)
        self.world.log_event("task_open", id=t.id, kind=kind, prompt=prompt, aircraft=aircraft)
        return t

    def open_of_kind(self, kind: str) -> List[Task]:
        return [t for t in self.tasks if t.kind == kind and t.is_open]

    # ---- creation -----------------------------------------------------------------------
    def create_readback(self, clearance, heard_text: str, is_wrong: bool) -> Task:
        prompt = f"{clearance.callsign} reads back: {heard_text}   (cleared: {clearance.text})"
        t = self._new("readback", prompt, ["Correct", "Incorrect"], 1 if is_wrong else 0,
                      self.spec.task_deadline_s, clearance.callsign,
                      {"clearance": clearance.id, "wrong": is_wrong})
        return t

    def create_transfer(self, callsign: str) -> Optional[Task]:
        ac = self.world.aircraft.get(callsign)
        if ac is None or ac.transferred or self.has_open(callsign, "transfer"):
            return None
        right = ac.freq_next
        pool = [f for f in self.world.sector.freq_by_gate.values() if f != right]
        self.rng.shuffle(pool)
        opts = pool[:2] + [right]
        self.rng.shuffle(opts)
        return self._new("transfer", f"{callsign}: contact next sector",
                         opts, opts.index(right), max(self.spec.task_deadline_s, 8.0), callsign)

    def has_open(self, callsign: str, kind: str) -> bool:
        return any(t.aircraft == callsign and t.kind == kind and t.is_open for t in self.tasks)

    def _create_alert(self) -> Optional[Task]:
        acs = list(self.world.aircraft)
        if not acs:
            return None
        cs = self.rng.choice(sorted(acs))
        return self._new("alert", f"RADIO FAILURE  {cs}  7600",
                         ["Acknowledge"], 0, min(6.0, self.spec.task_deadline_s), cs)

    def _create_levelreq(self) -> Optional[Task]:
        w = self.world
        cands = [a for a in w.aircraft.values() if a.tgt_alt == a.alt and a.spawn_time + 20 < w.t
                 and not self.has_open(a.callsign, "levelreq")]
        if not cands:
            return None
        ac = self.rng.choice(sorted(cands, key=lambda a: a.callsign))
        delta = self.rng.choice([-4000, -2000, 2000, 4000])
        new = ac.alt + delta
        new = int(round(new / 100.0) * 100)
        if new < 10000 or new > ac.ac_type.ceiling:
            new = ac.alt - delta
        if new < 10000 or new > ac.ac_type.ceiling:
            return None
        safe = w.level_change_is_safe(ac.callsign, new)
        verb = "climb" if new > ac.alt else "descend"
        t = self._new("levelreq", f"{ac.callsign} requests {verb} FL{int(new/100)}",
                      ["Approve", "Deny"], 0 if safe else 1, self.spec.task_deadline_s + 2, ac.callsign,
                      {"alt": new, "safe": safe})
        return t

    def _create_memory_show(self) -> Optional[Task]:
        cands = sorted(self.world.aircraft)
        if len(cands) < 4 or self._pending_memory:
            return None
        picks = self.rng.sample(cands, 3)
        t = self._new("memshow", "Memorise: " + "  ".join(picks), [], None, 6.0)
        t.data["callsigns"] = picks
        t.outcome = "info"
        delay = self.rng.uniform(30.0, 60.0)
        self._pending_memory.append({"at": self.real_t + delay, "picks": picks})
        return t

    def _create_memory_ask(self, picks: List[str]) -> Optional[Task]:
        right = self.rng.choice(picks)
        others = [c for c in sorted(self.world.aircraft) if c not in picks]
        pool = others + [s.callsign for s in self.world.scenario.specs
                         if s.callsign not in picks and s.callsign not in others]
        pool = sorted(set(pool))
        if len(pool) < 3:
            return None
        opts = self.rng.sample(pool, 3) + [right]
        self.rng.shuffle(opts)
        return self._new("memory", "Which one was on the priority list?",
                         opts, opts.index(right), self.spec.task_deadline_s + 4, "", {"picks": picks})

    def _create_ttc(self) -> Optional[Task]:
        """Ask for the time to loss of separation. About a quarter of the time the pair is a NEAR MISS that stays outside
        5 NM (between 5 and 9 NM at closest approach): the right answer is then 'No conflict'."""
        from .predict import predict_all
        w = self.world
        cands = [c for c in w.predicted if 30.0 <= c.t_start <= 270.0]
        if self.rng.random() < 0.25 and w.trajs:
            real = {c.pair for c in w.predicted}
            near = [c for c in predict_all(w.trajs, sep_h=9.0) if c.pair not in real and 30.0 <= c.t_start <= 270.0
                    and c.min_h >= 6.0]          # clearly outside 5 NM: 'No conflict' must be unambiguous
            if near:
                c = self.rng.choice(near)
                return self._new("ttc", f"{c.a} / {c.b}: time to loss of separation, sim clock, from now?",
                                 list(TTC_BUCKETS), len(TTC_BUCKETS) - 1, self.spec.task_deadline_s + 3, c.a,
                                 {"pair": (c.a, c.b), "near_miss": True, "min_h": c.min_h})
        if not cands:
            return None
        c = self.rng.choice(cands)
        b = ttc_bucket(c.t_start)
        return self._new("ttc", f"{c.a} / {c.b}: time to loss of separation, sim clock, from now?",
                         list(TTC_BUCKETS), b, self.spec.task_deadline_s + 3, c.a,
                         {"pair": (c.a, c.b), "t_start": c.t_start})

    def _create_eta(self) -> Optional[Task]:
        w = self.world
        cands = []
        for a in w.aircraft.values():
            wp = a.next_wp
            if wp is None or a.spawn_time + 15 > w.t:
                continue
            gs = a.ground_speed(w.wind_vec)
            d = dist((a.x, a.y), (wp[1], wp[2]))
            minutes = d / gs * 60.0
            if 2.0 <= minutes <= 9.0:
                cands.append((a, wp, minutes))
        if not cands:
            return None
        a, wp, minutes = self.rng.choice(sorted(cands, key=lambda c: c[0].callsign))
        right = int(round(minutes))
        opts_vals = sorted({max(1, right + d) for d in (-2, -1, 0, 1, 2)})
        while len(opts_vals) < 5:
            opts_vals.append(opts_vals[-1] + 1)
        opts_vals = opts_vals[:5]
        if right not in opts_vals:
            opts_vals[2] = right
            opts_vals = sorted(set(opts_vals))
        return self._new("eta", f"{a.callsign}: ETA {wp[0]}, GS {int(round(a.ground_speed(w.wind_vec)))} kt?",
                         [f"{v} min" for v in opts_vals], opts_vals.index(right),
                         self.spec.task_deadline_s + 3, a.callsign, {"minutes": minutes, "fix": wp[0]})

    def _random_task(self) -> None:
        kinds = [k for k in self.spec.kinds if k in ("alert", "levelreq", "memory", "ttc", "eta")]
        if not kinds:
            return
        weights = {"alert": 1.0, "levelreq": 1.5, "memory": 1.0, "ttc": 1.6, "eta": 1.4}
        for _ in range(4):
            k = self.rng.choices(kinds, [weights[x] for x in kinds])[0]
            made = None
            if k == "alert":
                made = self._create_alert()
            elif k == "levelreq":
                made = self._create_levelreq()
            elif k == "memory":
                made = self._create_memory_show()
            elif k == "ttc":
                made = self._create_ttc()
            elif k == "eta":
                made = self._create_eta()
            if made is not None:
                return

    # ---- time ---------------------------------------------------------------------------
    def tick(self, real_dt: float) -> None:
        self.real_t += real_dt
        for t in list(self.tasks):
            t.time_left -= real_dt
            if t.time_left <= 0:
                self._expire(t)
        for m in list(self._pending_memory):
            if self.real_t >= m["at"]:
                self._pending_memory.remove(m)
                self._create_memory_ask(m["picks"])
        if self.enabled and self.real_t >= self._next_random and self.world.t > 20:
            if len([t for t in self.tasks if t.kind != "memshow"]) < 3:
                self._random_task()
            self._next_random = self._gap()

    def _expire(self, t: Task) -> None:
        t.state = "expired"
        t.closed_at = self.real_t
        if t.kind == "memshow":
            t.outcome = "info"
        else:
            t.outcome = "blank"
            self.world.on_task_finished(t)
        self.tasks.remove(t)
        self.log.append(t)
        self.world.log_event("task_expired", id=t.id, kind=t.kind)

    def answer(self, task_id: int, choice: int) -> Optional[Task]:
        for t in self.tasks:
            if t.id == task_id and t.is_open and t.kind != "memshow":
                if choice < 0 or choice >= len(t.options):
                    return None
                t.answer = choice
                t.state = "done"
                t.closed_at = self.real_t
                t.response_s = t.time_total - t.time_left
                t.outcome = "correct" if choice == t.correct else "wrong"
                self.tasks.remove(t)
                self.log.append(t)
                self.world.on_task_finished(t)
                self.world.log_event("task_answer", id=t.id, kind=t.kind, choice=choice, outcome=t.outcome)
                return t
        return None

    def finish_all(self) -> None:
        """Called at the end of a run: open tasks that never got an answer count as blank."""
        for t in list(self.tasks):
            if t.kind == "memshow":
                self.tasks.remove(t)
                continue
            self._expire(t)
