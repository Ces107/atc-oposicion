"""Aircraft performance models (fictional but plausible numbers) and the turn-rate law."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict

G = 9.80665
KT_TO_MS = 0.514444
BANK_DEG = 25.0
MAX_TURN_RATE = 3.0  # deg/s ("rate one")


@dataclass(frozen=True)
class AircraftType:
    code: str
    wake: str            # L / M / H
    v_min: float         # kt (true airspeed model used by the game)
    v_max: float
    v_cruise: float
    climb_fpm: float
    descent_fpm: float
    accel: float         # kt per second
    ceiling: int         # ft


TYPES: Dict[str, AircraftType] = {t.code: t for t in [
    AircraftType("A320", "M", 220, 470, 400, 2200, 2400, 1.0, 39000),
    AircraftType("B738", "M", 220, 470, 410, 2300, 2400, 1.0, 39000),
    AircraftType("E190", "M", 210, 450, 380, 2400, 2400, 1.0, 41000),
    AircraftType("A333", "H", 240, 490, 440, 1800, 2200, 0.8, 41000),
    AircraftType("AT72", "M", 170, 290, 250, 1500, 1800, 0.6, 25000),
]}


def turn_rate(tas: float) -> float:
    """Turn rate in deg/s for a 25 degree bank at true airspeed `tas` (kt), capped at rate one (3 deg/s).

    omega = g * tan(bank) / v  (v in m/s).  At 250 kt this is 2.037 deg/s.
    """
    v = max(tas, 1.0) * KT_TO_MS
    w = math.degrees(G * math.tan(math.radians(BANK_DEG)) / v)
    return min(MAX_TURN_RATE, w)
