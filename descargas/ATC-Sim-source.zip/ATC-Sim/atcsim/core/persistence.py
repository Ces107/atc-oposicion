"""JSON statistics file next to the game + CSV export with the project's fixed columns."""
from __future__ import annotations

import csv
import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from .audio_task import SETTINGS as AUDIO_SETTINGS, VARIANTS as AUDIO_VARIANTS, VOICES, audio_cost, latest_solo
from .scenario import level_spec
from .scoring import RunResult, default_adaptive

CSV_COLUMNS = ["Date", "Module", "Level", "Correct", "Wrong", "Blank", "Seconds per item", "Accuracy %", "Goal", "Met"]
VERSION = 2
AUDIO_MODULE = {"sum": "Spoken task: digit sums", "code": "Spoken task: code match"}
DEFAULT_SETTINGS = {"audio": "auto", "voice": "es"}


def default_path() -> str:
    from .paths import user_data_dir
    return os.path.join(user_data_dir(), "sim_stats.json")


def result_to_record(r: RunResult, ts: Optional[float] = None) -> Dict[str, Any]:
    return {
        "ts": time.time() if ts is None else ts, "mode": r.mode, "level": r.level, "seed": r.seed,
        "correct": r.correct, "wrong": r.wrong, "blank": r.blank,
        "spi": round(r.seconds_per_item, 2), "accuracy": round(r.accuracy, 1),
        "score": round(r.score, 1), "losses": r.losses, "zone": r.zone_incursions,
        "goal": r.goal_text, "met": bool(r.met), "assisted": bool(r.assisted),
        "real_s": round(r.real_seconds, 1), "aircraft": r.aircraft,
        "components": {k: dict(v) for k, v in r.components.items()},
        "thirds": [dict(t) for t in r.thirds_data] if r.thirds_data else None,
        "unneeded": r.unneeded, "commands": r.commands,
        "audio": dict(r.audio) if r.audio else None,
    }


def _csv_field(v: Any) -> str:
    s = str(v)
    if any(ch in s for ch in ';"\r\n'):
        s = '"' + s.replace('"', '""') + '"'
    return s


def module_name(rec: Dict[str, Any]) -> str:
    return f"Radar Sector Sim ({rec.get('mode', 'Ladder')})"


def audio_row(ts: float, level: int, a: Dict[str, Any], solo: bool) -> List[Any]:
    """One CSV row for the spoken task (separate module so it never mixes with the radar items).
    Seconds per item = mean response time of the correct answers; Goal carries the dual-task cost when known."""
    goal_acc = int(level_spec(level).goal_accuracy * 100)
    goal = f"accuracy >= {goal_acc}%"
    cost = a.get("cost")
    if not solo:
        if cost:
            rt = f", {cost['cost_rt_s']:+.2f} s" if cost.get("cost_rt_s") is not None else ""
            goal += f" / dual-task cost {cost['cost_points']:+.1f} pts{rt} vs solo"
        else:
            goal += " / no solo baseline"
    date = time.strftime("%d/%m/%Y %H:%M", time.localtime(ts))
    mod = AUDIO_MODULE.get(a.get("variant"), "Spoken task") + (" (solo)" if solo else " (with radar)")
    return [date, mod, level, a["correct"], a["wrong"], a["blank"], f"{(a.get('rt_s') or 0.0):.2f}",
            f"{a['accuracy']:.1f}", goal, "Yes" if a["n"] and a["accuracy"] >= goal_acc else "No"]


def runs_to_csv(runs: List[Dict[str, Any]], solos: Optional[List[Dict[str, Any]]] = None) -> str:
    """One row per radar run (unchanged), followed by one extra row when that run had the spoken task; then one row
    per solo baseline block of the spoken task. Same 10 columns as always."""
    rows: List[List[Any]] = []
    for x in runs:
        date = time.strftime("%d/%m/%Y %H:%M", time.localtime(x["ts"]))
        rows.append([date, module_name(x), x["level"], x["correct"], x["wrong"], x["blank"],
                     f"{x['spi']:.2f}", f"{x['accuracy']:.1f}", x.get("goal", ""), "Yes" if x.get("met") else "No"])
        a = x.get("audio")
        if a and a.get("n"):
            rows.append(audio_row(x["ts"], x["level"], a, solo=False))
    for s in solos or []:
        if s.get("n"):
            rows.append(audio_row(s["ts"], s["level"], s, solo=True))
    lines = [";".join(CSV_COLUMNS)] + [";".join(_csv_field(v) for v in r) for r in rows]
    return "\r\n".join(lines) + "\r\n"


class StatsStore:
    def __init__(self, path: Optional[str] = None):
        self.path = path or default_path()
        self.data: Dict[str, Any] = self._empty()
        self.warning: str = ""
        self.load()

    @staticmethod
    def _empty() -> Dict[str, Any]:
        return {"version": VERSION, "runs": [], "adaptive": default_adaptive(), "best": {}, "tutorial_done": False,
                "next_seed": 1000, "audio_solo": [], "settings": dict(DEFAULT_SETTINGS)}

    def load(self) -> None:
        self.data = self._empty()
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, dict):
                raise ValueError("not an object")
            self.data = self._migrate(raw)
        except (OSError, ValueError) as e:
            bad = self.path + f".corrupt-{int(time.time())}"
            try:
                os.replace(self.path, bad)
                self.warning = f"Stats file was unreadable ({e}); it was kept as {os.path.basename(bad)} and a new one started."
            except OSError:
                self.warning = f"Stats file unreadable ({e}) and could not be moved."
            self.data = self._empty()

    @staticmethod
    def _finite(v: Any) -> float:
        f = float(v)
        if f != f or f in (float("inf"), float("-inf")):
            raise ValueError("not finite")
        return f

    @staticmethod
    def _clean_components(c: Any) -> Dict[str, Dict[str, int]]:
        out: Dict[str, Dict[str, int]] = {}
        if not isinstance(c, dict):
            return out
        for k, v in c.items():
            if isinstance(v, dict):
                try:
                    out[str(k)] = {o: int(v.get(o, 0)) for o in ("correct", "wrong", "blank")}
                except (TypeError, ValueError):
                    continue
        return out

    @staticmethod
    def _clean_thirds(t: Any) -> Optional[List[Dict[str, float]]]:
        """Valid schema-thirds (3 dicts n,c,b,s) or None; old files without the field load as None."""
        if not isinstance(t, list) or len(t) != 3:
            return None
        out = []
        try:
            for g in t:
                n, c, b = int(g["n"]), int(g["c"]), int(g["b"])
                s = StatsStore._finite(g["s"])
                if n < 0 or c < 0 or b < 0 or c + b > n:
                    return None
                out.append({"n": n, "c": c, "b": b, "s": s})
        except (KeyError, TypeError, ValueError):
            return None
        return out

    @staticmethod
    def _clean_audio(a: Any) -> Optional[Dict[str, Any]]:
        """Spoken-task summary of a run or a solo block, or None (old files have no such field)."""
        if not isinstance(a, dict) or a.get("variant") not in AUDIO_VARIANTS:
            return None
        try:
            c, w, b = (max(0, int(a.get(k, 0))) for k in ("correct", "wrong", "blank"))
            out: Dict[str, Any] = {"variant": a["variant"], "level": max(1, min(10, int(a.get("level", 1)))),
                                   "n": c + w + b, "correct": c, "wrong": w, "blank": b,
                                   "accuracy": round(100.0 * c / (c + w + b), 1) if c + w + b else 0.0}
            for k in ("rt_s", "rt_median_s"):
                v = a.get(k)
                out[k] = None if v is None else round(StatsStore._finite(v), 2)
            for k in ("spoken", "ignored"):
                if k in a:
                    out[k] = max(0, int(a[k]))
            for k in ("target", "voice"):
                if k in a:
                    out[k] = str(a[k])[:40]
            cost = a.get("cost")
            if isinstance(cost, dict) and "cost_points" in cost:
                out["cost"] = {"solo_accuracy": StatsStore._finite(cost.get("solo_accuracy", 0.0)),
                               "solo_rt_s": None if cost.get("solo_rt_s") is None else StatsStore._finite(cost["solo_rt_s"]),
                               "cost_points": StatsStore._finite(cost["cost_points"]),
                               "cost_rt_s": None if cost.get("cost_rt_s") is None else StatsStore._finite(cost["cost_rt_s"]),
                               "solo_ts": None if cost.get("solo_ts") is None else StatsStore._finite(cost["solo_ts"])}
            if "ts" in a:
                ts = StatsStore._finite(a["ts"])
                if not (0.0 < ts < 4.0e9):
                    return None
                out["ts"] = ts
                out["seed"] = int(a.get("seed", 0))
            return out
        except (KeyError, TypeError, ValueError):
            return None

    @staticmethod
    def _migrate(raw: Dict[str, Any]) -> Dict[str, Any]:
        d = StatsStore._empty()
        v = raw.get("version", 1)
        runs = raw.get("runs", [])
        good = []
        for x in runs if isinstance(runs, list) else []:
            if not isinstance(x, dict):
                continue
            try:
                ts = float(x["ts"])
                if not (0.0 < ts < 4.0e9):          # NaN, inf, absurd values would crash the CSV export's date formatting
                    continue
                good.append({
                    "ts": ts, "mode": str(x.get("mode", "Ladder")), "level": int(x["level"]),
                    "seed": int(x.get("seed", 0)), "correct": int(x["correct"]), "wrong": int(x["wrong"]),
                    "blank": int(x["blank"]), "spi": StatsStore._finite(x.get("spi", 0.0)), "accuracy": StatsStore._finite(x.get("accuracy", 0.0)),
                    "score": float(x.get("score", 0.0)), "losses": int(x.get("losses", 0)), "zone": int(x.get("zone", 0)),
                    "goal": str(x.get("goal", "")), "met": bool(x.get("met", False)),
                    "assisted": bool(x.get("assisted", False)), "real_s": float(x.get("real_s", 0.0)),
                    "aircraft": int(x.get("aircraft", 0)), "components": StatsStore._clean_components(x.get("components", {})),
                    "thirds": StatsStore._clean_thirds(x.get("thirds")),
                    "unneeded": max(0, int(x.get("unneeded", 0))), "commands": max(0, int(x.get("commands", 0))),
                    "audio": StatsStore._clean_audio(x.get("audio")),
                })
            except (KeyError, TypeError, ValueError):
                continue
        d["runs"] = good
        solos = raw.get("audio_solo")
        if isinstance(solos, list):
            d["audio_solo"] = [s for s in (StatsStore._clean_audio(x) for x in solos) if s is not None and "ts" in s]
        st = raw.get("settings")
        if isinstance(st, dict):
            if st.get("audio") in AUDIO_SETTINGS:
                d["settings"]["audio"] = st["audio"]
            if st.get("voice") in VOICES:
                d["settings"]["voice"] = st["voice"]
        ad = raw.get("adaptive")
        if isinstance(ad, dict) and all(k in ad for k in ("level", "ok", "bad")):
            try:
                d["adaptive"] = {"level": max(1, min(10, int(ad["level"]))), "ok": int(ad["ok"]), "bad": int(ad["bad"])}
            except (TypeError, ValueError):
                pass
        best = raw.get("best")
        if isinstance(best, dict):
            d["best"] = {str(k): v for k, v in best.items() if isinstance(v, dict)}
        d["tutorial_done"] = bool(raw.get("tutorial_done", False))
        try:
            d["next_seed"] = int(raw.get("next_seed", 1000))
        except (TypeError, ValueError):
            pass
        d["version"] = VERSION
        return d

    def save(self) -> bool:
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=1)
            os.replace(tmp, self.path)
            return True
        except OSError as e:
            self.warning = f"Could not save statistics: {e}"
            return False

    def add_run(self, r: RunResult, ts: Optional[float] = None, voice: Optional[str] = None) -> Dict[str, Any]:
        rec = result_to_record(r, ts)
        a = rec.get("audio")
        if a:
            if voice:
                a["voice"] = voice
            solo = latest_solo(self.data["audio_solo"], a["variant"], a["level"])
            cost = audio_cost(a, solo) if solo else None
            if cost:
                a["cost"] = cost
        self.data["runs"].append(rec)
        key = str(r.level)
        b = self.data["best"].get(key)
        if r.mode == "Radar-only":
            pass                                     # baseline runs (no tasks) never count as personal bests
        elif b is None or rec["score"] > b.get("score", -1):
            self.data["best"][key] = {"score": rec["score"], "accuracy": rec["accuracy"], "seed": rec["seed"],
                                      "ts": rec["ts"]}
        self.save()
        return rec

    def add_audio_solo(self, summary: Dict[str, Any], seed: int, voice: str = "", ts: Optional[float] = None) -> Dict[str, Any]:
        """Save a solo (no traffic) block of the spoken task: the single-task baseline. The latest run with the same
        seed, level and variant gets its dual-task cost updated, so a baseline taken right after a run counts for it."""
        rec = dict(summary)
        rec["ts"] = time.time() if ts is None else ts
        rec["seed"] = int(seed)
        if voice:
            rec["voice"] = voice
        self.data["audio_solo"].append(rec)
        for x in reversed(self.data["runs"]):
            a = x.get("audio")
            if a and x.get("seed") == rec["seed"] and a.get("variant") == rec.get("variant") and a.get("level") == rec.get("level"):
                cost = audio_cost(a, rec)
                if cost:
                    a["cost"] = cost
                break
        self.save()
        return rec

    def settings(self) -> Dict[str, str]:
        st = self.data.setdefault("settings", dict(DEFAULT_SETTINGS))
        for k, v in DEFAULT_SETTINGS.items():
            st.setdefault(k, v)
        return st

    def next_seed(self) -> int:
        s = int(self.data.get("next_seed", 1000))
        self.data["next_seed"] = s + 1
        return s

    def export_csv(self, path: str) -> bool:
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                f.write(runs_to_csv(self.data["runs"], self.data.get("audio_solo", [])))
            return True
        except OSError as e:
            self.warning = f"Could not write CSV: {e}"
            return False

    def clean_streak(self) -> int:
        n = 0
        for x in reversed(self.data["runs"]):
            if x.get("mode") == "Radar-only":
                continue
            if x["met"] and not x.get("assisted"):
                n += 1
            else:
                break
        return n
