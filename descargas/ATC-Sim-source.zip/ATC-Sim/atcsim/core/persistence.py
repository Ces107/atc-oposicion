"""JSON statistics file next to the game + CSV export with the project's fixed columns."""
from __future__ import annotations

import csv
import io
import json
import os
import time
from typing import Any, Dict, List, Optional

from .scoring import RunResult, default_adaptive

CSV_COLUMNS = ["Date", "Module", "Level", "Correct", "Wrong", "Blank", "Seconds per item", "Accuracy %", "Goal", "Met"]
VERSION = 2


def default_path() -> str:
    from .paths import user_data_dir
    return os.path.join(user_data_dir(), "sim_stats.json")


def result_to_record(r: RunResult, ts: Optional[float] = None) -> Dict[str, Any]:
    return {
        "ts": time.time() if ts is None else ts, "mode": r.mode, "level": r.level, "seed": r.seed,
        "correct": r.correct, "wrong": r.wrong, "blank": r.blank,
        "spi": round(r.seconds_per_item, 2), "accuracy": round(r.accuracy, 1),
        "score": round(r.score, 1), "losses": r.losses, "zone": r.zone_incursions,
        "goal": r.goal_text, "met": bool(r.met), "assisted": bool(r.assisted),
        "real_s": round(r.real_seconds, 1), "aircraft": r.aircraft,
        "components": {k: dict(v) for k, v in r.components.items()},
        "thirds": [dict(t) for t in r.thirds_data] if r.thirds_data else None,
        "unneeded": r.unneeded, "commands": r.commands,
    }


def _csv_field(v: Any) -> str:
    s = str(v)
    if any(ch in s for ch in ';"\r\n'):
        s = '"' + s.replace('"', '""') + '"'
    return s


def module_name(rec: Dict[str, Any]) -> str:
    return f"Radar Sector Sim ({rec.get('mode', 'Ladder')})"


def runs_to_csv(runs: List[Dict[str, Any]]) -> str:
    lines = [";".join(CSV_COLUMNS)]
    for x in runs:
        date = time.strftime("%d/%m/%Y %H:%M", time.localtime(x["ts"]))
        row = [date, module_name(x), x["level"], x["correct"], x["wrong"], x["blank"],
               f"{x['spi']:.2f}", f"{x['accuracy']:.1f}", x.get("goal", ""), "Yes" if x.get("met") else "No"]
        lines.append(";".join(_csv_field(v) for v in row))
    return "\r\n".join(lines) + "\r\n"


class StatsStore:
    def __init__(self, path: Optional[str] = None):
        self.path = path or default_path()
        self.data: Dict[str, Any] = self._empty()
        self.warning: str = ""
        self.load()

    @staticmethod
    def _empty() -> Dict[str, Any]:
        return {"version": VERSION, "runs": [], "adaptive": default_adaptive(), "best": {}, "tutorial_done": False,
                "next_seed": 1000}

    def load(self) -> None:
        self.data = self._empty()
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, dict):
                raise ValueError("not an object")
            self.data = self._migrate(raw)
        except (OSError, ValueError) as e:
            bad = self.path + f".corrupt-{int(time.time())}"
            try:
                os.replace(self.path, bad)
                self.warning = f"Stats file was unreadable ({e}); it was kept as {os.path.basename(bad)} and a new one started."
            except OSError:
                self.warning = f"Stats file unreadable ({e}) and could not be moved."
            self.data = self._empty()

    @staticmethod
    def _finite(v: Any) -> float:
        f = float(v)
        if f != f or f in (float("inf"), float("-inf")):
            raise ValueError("not finite")
        return f

    @staticmethod
    def _clean_components(c: Any) -> Dict[str, Dict[str, int]]:
        out: Dict[str, Dict[str, int]] = {}
        if not isinstance(c, dict):
            return out
        for k, v in c.items():
            if isinstance(v, dict):
                try:
                    out[str(k)] = {o: int(v.get(o, 0)) for o in ("correct", "wrong", "blank")}
                except (TypeError, ValueError):
                    continue
        return out

    @staticmethod
    def _clean_thirds(t: Any) -> Optional[List[Dict[str, float]]]:
        """Valid schema-thirds (3 dicts n,c,b,s) or None; old files without the field load as None."""
        if not isinstance(t, list) or len(t) != 3:
            return None
        out = []
        try:
            for g in t:
                n, c, b = int(g["n"]), int(g["c"]), int(g["b"])
                s = StatsStore._finite(g["s"])
                if n < 0 or c < 0 or b < 0 or c + b > n:
                    return None
                out.append({"n": n, "c": c, "b": b, "s": s})
        except (KeyError, TypeError, ValueError):
            return None
        return out

    @staticmethod
    def _migrate(raw: Dict[str, Any]) -> Dict[str, Any]:
        d = StatsStore._empty()
        v = raw.get("version", 1)
        runs = raw.get("runs", [])
        good = []
        for x in runs if isinstance(runs, list) else []:
            if not isinstance(x, dict):
                continue
            try:
                ts = float(x["ts"])
                if not (0.0 < ts < 4.0e9):          # NaN, inf, absurd values would crash the CSV export's date formatting
                    continue
                good.append({
                    "ts": ts, "mode": str(x.get("mode", "Ladder")), "level": int(x["level"]),
                    "seed": int(x.get("seed", 0)), "correct": int(x["correct"]), "wrong": int(x["wrong"]),
                    "blank": int(x["blank"]), "spi": StatsStore._finite(x.get("spi", 0.0)), "accuracy": StatsStore._finite(x.get("accuracy", 0.0)),
                    "score": float(x.get("score", 0.0)), "losses": int(x.get("losses", 0)), "zone": int(x.get("zone", 0)),
                    "goal": str(x.get("goal", "")), "met": bool(x.get("met", False)),
                    "assisted": bool(x.get("assisted", False)), "real_s": float(x.get("real_s", 0.0)),
                    "aircraft": int(x.get("aircraft", 0)), "components": StatsStore._clean_components(x.get("components", {})),
                    "thirds": StatsStore._clean_thirds(x.get("thirds")),
                    "unneeded": max(0, int(x.get("unneeded", 0))), "commands": max(0, int(x.get("commands", 0))),
                })
            except (KeyError, TypeError, ValueError):
                continue
        d["runs"] = good
        ad = raw.get("adaptive")
        if isinstance(ad, dict) and all(k in ad for k in ("level", "ok", "bad")):
            try:
                d["adaptive"] = {"level": max(1, min(10, int(ad["level"]))), "ok": int(ad["ok"]), "bad": int(ad["bad"])}
            except (TypeError, ValueError):
                pass
        best = raw.get("best")
        if isinstance(best, dict):
            d["best"] = {str(k): v for k, v in best.items() if isinstance(v, dict)}
        d["tutorial_done"] = bool(raw.get("tutorial_done", False))
        try:
            d["next_seed"] = int(raw.get("next_seed", 1000))
        except (TypeError, ValueError):
            pass
        d["version"] = VERSION
        return d

    def save(self) -> bool:
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=1)
            os.replace(tmp, self.path)
            return True
        except OSError as e:
            self.warning = f"Could not save statistics: {e}"
            return False

    def add_run(self, r: RunResult, ts: Optional[float] = None) -> Dict[str, Any]:
        rec = result_to_record(r, ts)
        self.data["runs"].append(rec)
        key = str(r.level)
        b = self.data["best"].get(key)
        if r.mode == "Radar-only":
            pass                                     # baseline runs (no tasks) never count as personal bests
        elif b is None or rec["score"] > b.get("score", -1):
            self.data["best"][key] = {"score": rec["score"], "accuracy": rec["accuracy"], "seed": rec["seed"],
                                      "ts": rec["ts"]}
        self.save()
        return rec

    def next_seed(self) -> int:
        s = int(self.data.get("next_seed", 1000))
        self.data["next_seed"] = s + 1
        return s

    def export_csv(self, path: str) -> bool:
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                f.write(runs_to_csv(self.data["runs"]))
            return True
        except OSError as e:
            self.warning = f"Could not write CSV: {e}"
            return False

    def clean_streak(self) -> int:
        n = 0
        for x in reversed(self.data["runs"]):
            if x.get("mode") == "Radar-only":
                continue
            if x["met"] and not x.get("assisted"):
                n += 1
            else:
                break
        return n
