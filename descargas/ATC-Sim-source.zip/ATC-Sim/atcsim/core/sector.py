"""The fictional sector: boundary, fixes, airways (routes) and a restricted area. Not a real ACC sector."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .geometry import Point, dist, point_in_polygon


@dataclass(frozen=True)
class Zone:
    name: str
    x: float
    y: float
    radius: float


@dataclass
class Sector:
    name: str
    polygon: List[Point]
    fixes: Dict[str, Point]          # every named point
    boundary_fixes: List[str]        # entry / exit gates
    routes: Dict[str, List[str]]     # airway name -> ordered fix names
    zones: List[Zone] = field(default_factory=list)
    freq_by_gate: Dict[str, str] = field(default_factory=dict)
    own_freq: str = "125.350"

    def contains(self, p: Point) -> bool:
        return point_in_polygon(p, self.polygon)

    def route_points(self, names: List[str]) -> Tuple[Tuple[str, float, float], ...]:
        return tuple((n, self.fixes[n][0], self.fixes[n][1]) for n in names)

    def route_length(self, names: List[str]) -> float:
        return sum(dist(self.fixes[a], self.fixes[b]) for a, b in zip(names, names[1:]))

    def all_routes(self) -> List[Tuple[str, List[str]]]:
        """Every route in both directions. Direction reversed routes are named with a trailing '~'."""
        out: List[Tuple[str, List[str]]] = []
        for n, r in self.routes.items():
            out.append((n, list(r)))
            out.append((n + "~", list(reversed(r))))
        return out

    @property
    def bounds(self) -> Tuple[float, float, float, float]:
        xs = [p[0] for p in self.polygon]
        ys = [p[1] for p in self.polygon]
        return min(xs), min(ys), max(xs), max(ys)


def default_sector() -> Sector:
    fixes: Dict[str, Point] = {
        # boundary gates
        "ALBAR": (-25.0, 40.0), "NERVA": (15.0, 40.0),
        "TEJAR": (50.0, 15.0), "ORISA": (50.0, -22.0),
        "SULMA": (20.0, -40.0), "PIRAL": (-20.0, -40.0),
        "LUNDA": (-50.0, -15.0), "MOREA": (-50.0, 22.0),
        # interior waypoints
        "MIDAS": (0.0, 0.0), "CANTO": (-22.0, 10.0), "REGAL": (24.0, 8.0),
        "VELAR": (-10.0, -18.0), "DORNA": (12.0, -16.0), "FARO": (-8.0, 22.0),
    }
    gates = ["ALBAR", "NERVA", "TEJAR", "ORISA", "SULMA", "PIRAL", "LUNDA", "MOREA"]
    routes = {
        "R1": ["MOREA", "CANTO", "MIDAS", "ORISA"],
        "R2": ["LUNDA", "VELAR", "MIDAS", "REGAL", "NERVA"],
        "R3": ["ALBAR", "FARO", "MIDAS", "DORNA", "SULMA"],
        "R4": ["NERVA", "REGAL", "TEJAR"],
        "R5": ["ORISA", "DORNA", "VELAR", "LUNDA"],
        "R6": ["PIRAL", "VELAR", "CANTO", "MOREA"],
        "R7": ["SULMA", "DORNA", "REGAL", "TEJAR"],
    }
    freqs = {"ALBAR": "127.850", "NERVA": "132.700", "TEJAR": "124.100", "ORISA": "129.450",
             "SULMA": "135.225", "PIRAL": "121.375", "LUNDA": "133.900", "MOREA": "126.600"}
    poly = [(-50.0, -40.0), (50.0, -40.0), (50.0, 40.0), (-50.0, 40.0)]
    return Sector("SIERRA CENTRAL", poly, fixes, gates, routes,
                  zones=[Zone("R-31", -26.0, -12.0, 6.5)], freq_by_gate=freqs)
