"""Strip planner mode (pure, seeded, no pygame): plan traffic from flight progress strips, with no radar picture.

The player sees one strip per aircraft that will cross the sector (callsign, type, speed, entry point and time, the
route, exit point and time, requested and exit level) and a schematic of the route structure. Every time falls on
a whole or half minute. Task: find, before they happen, the pairs that will lose separation and resolve each one
with the allowed actions, so that every aircraft still leaves over its exit point at its exit level; and catch the
strips whose coordination is wrong (exit time inconsistent with entry time + route time, or an exit level the exit
point does not accept).

Rules (also on the help overlay):
  * Separation is in TIME: two aircraft at the same level must pass a common point at least SEP_MIN minutes apart,
    must not overtake each other on a common segment and must not meet head-on on a common segment.
  * A level change is made over a point: over that point the aircraft counts at both levels.
  * Actions: level of a segment (never the last one: the aircraft leaves at its XFL), delay at the entry point
    (hold, whole minutes), the alternative route over another point. Each only before the aircraft reaches it.
Time unit: minutes of the exercise clock (sim minutes); the clock runs at `rs_per_min` real seconds per minute.
"""
from __future__ import annotations

import copy
import itertools
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .scenario import level_spec, make_rng

SEP_MIN = 3.0                    # minutes between two aircraft at the same level over a common point
THINK_MIN = 3.0                  # a designed conflict happens at least this long after both strips are on the board
MAX_REF_COST = 4.0               # a designed conflict has a single resolution costing at most this (fair item)
EPS = 1e-6
SPEED_NM_MIN = {240: 4.0, 360: 6.0, 480: 8.0}      # with segment lengths 24/36/48 NM every time is a half minute
SPEED_WEIGHTS = ((240, 0.25), (360, 0.35), (480, 0.40))
TYPES = {240: ("AT76", "DH8D"), 360: ("E190", "CRJ9"), 480: ("A320", "B738", "A321")}
AIRLINES = ("IBE", "VLG", "AEA", "RYR", "EZY", "AFR", "DLH", "BAW", "KLM", "TAP", "SWR", "ANE")
FL_MIN, FL_MAX = 240, 400
PLANNER = "Strip Planner"        # CSV module prefix

# ---- the fictional route structure (not a real sector) -------------------------------------------------------
POINTS: Dict[str, Tuple[float, float]] = {
    "NORIX": (-18.0, 42.0), "NEMBA": (18.0, 54.0), "ESTAN": (42.0, 18.0), "ELBIS": (54.0, -18.0),
    "SOLBE": (18.0, -66.0), "SAMAR": (-18.0, -54.0), "ORBEN": (-66.0, -18.0), "OLMAR": (-54.0, 18.0),
    "ARVEN": (-18.0, 18.0), "BOLMA": (18.0, 18.0), "CUREL": (18.0, -18.0), "DASTO": (-18.0, -18.0),
}
GATES = ("NORIX", "NEMBA", "ESTAN", "ELBIS", "SOLBE", "SAMAR", "ORBEN", "OLMAR")
INNER = ("ARVEN", "BOLMA", "CUREL", "DASTO")
GATE_INNER = {"NORIX": "ARVEN", "OLMAR": "ARVEN", "NEMBA": "BOLMA", "ESTAN": "BOLMA",
              "ELBIS": "CUREL", "SOLBE": "CUREL", "SAMAR": "DASTO", "ORBEN": "DASTO"}
PARITY = {"NORIX": "par", "NEMBA": "impar", "ESTAN": "impar", "ELBIS": "par",
          "SOLBE": "impar", "SAMAR": "par", "ORBEN": "impar", "OLMAR": "par"}
LEVELS_BY_PARITY = {"par": (280, 300, 320, 340, 360), "impar": (290, 310, 330, 350)}
_SEG = {("NORIX", "ARVEN"): 24, ("NEMBA", "BOLMA"): 36, ("ESTAN", "BOLMA"): 24, ("ELBIS", "CUREL"): 36,
        ("SOLBE", "CUREL"): 48, ("SAMAR", "DASTO"): 36, ("ORBEN", "DASTO"): 48, ("OLMAR", "ARVEN"): 36,
        ("ARVEN", "BOLMA"): 36, ("BOLMA", "CUREL"): 36, ("CUREL", "DASTO"): 36, ("DASTO", "ARVEN"): 36,
        ("ARVEN", "CUREL"): 48}
SEGMENTS: Dict[frozenset, int] = {frozenset(k): v for k, v in _SEG.items()}
ALT_EXTRA_MAX = 48               # an alternative route is offered when it is at most this many NM longer


def seg_len(a: str, b: str) -> int:
    return SEGMENTS[frozenset((a, b))]


def parity_of(fl: int) -> str:
    return "par" if (int(fl) // 10) % 2 == 0 else "impar"


def level_ok_at(gate: str, fl: int) -> bool:
    return parity_of(fl) == PARITY[gate]


def _inner_adj() -> Dict[str, List[str]]:
    adj: Dict[str, List[str]] = {p: [] for p in INNER}
    for k in SEGMENTS:
        a, b = tuple(k)
        if a in INNER and b in INNER:
            adj[a].append(b)
            adj[b].append(a)
    return {k: sorted(v) for k, v in adj.items()}


def route_length(route: Sequence[str]) -> int:
    return sum(seg_len(a, b) for a, b in zip(route, route[1:]))


def route_options(entry: str, exit_: str) -> List[List[str]]:
    """[primary] or [primary, alternative]. Primary = shortest; alternative = next shortest over other points,
    at most ALT_EXTRA_MAX NM longer. Ties are broken by the point names (deterministic)."""
    a, b = GATE_INNER[entry], GATE_INNER[exit_]
    adj = _inner_adj()
    paths: List[List[str]] = []

    def walk(p: List[str]) -> None:
        if p[-1] == b:
            paths.append(list(p))
            return
        for n in adj[p[-1]]:
            if n not in p:
                walk(p + [n])
    walk([a])
    full = sorted(([entry] + p + [exit_] for p in paths), key=lambda r: (route_length(r), r))
    out = [full[0]]
    for r in full[1:]:
        if r[1:-1] != full[0][1:-1] and route_length(r) <= route_length(full[0]) + ALT_EXTRA_MAX:
            out.append(r)
            break
    return out


# ---- level ladder ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class PlannerSpec:
    level: int
    n_flights: int
    window_min: float        # entries spread over this many exercise minutes
    rs_per_min: float        # real seconds per exercise minute
    conflicts: int           # designed conflicting pairs (if nobody acts)
    coord_errors: int        # strips with a coordination error
    lead_min: float          # a strip reaches the board this many minutes before its entry time
    show_etos: bool          # times over the inner points printed on the strip
    check_aid: bool          # after each change: says whether it solved something or created a conflict

    @property
    def name(self) -> str:
        return level_spec(self.level).name

    @property
    def goal_accuracy(self) -> float:
        return level_spec(self.level).goal_accuracy


PLANNER_LEVELS: List[PlannerSpec] = [
    PlannerSpec(1, 6, 24, 7.0, 2, 0, 12, True, True),
    PlannerSpec(2, 8, 28, 6.5, 3, 1, 12, True, True),
    PlannerSpec(3, 10, 32, 6.0, 4, 1, 11, True, True),
    PlannerSpec(4, 12, 38, 5.5, 5, 2, 10, False, False),
    PlannerSpec(5, 15, 44, 5.0, 6, 2, 10, False, False),
    PlannerSpec(6, 18, 50, 4.5, 7, 3, 9, False, False),
    PlannerSpec(7, 21, 56, 4.0, 8, 3, 8, False, False),
    PlannerSpec(8, 25, 62, 3.6, 10, 4, 8, False, False),
    PlannerSpec(9, 29, 70, 3.2, 12, 5, 7, False, False),
    PlannerSpec(10, 34, 80, 2.8, 14, 6, 6, False, False),
]


def planner_spec(level: int) -> PlannerSpec:
    return PLANNER_LEVELS[max(1, min(10, int(level))) - 1]


# ---- flights --------------------------------------------------------------------------------------------------
@dataclass
class Flight:
    cs: str
    type_code: str
    speed: int                   # kt (ground speed, constant)
    entry_t: float               # planned time over the entry point (minutes, half-minute grid)
    routes: List[List[str]]      # [primary] or [primary, alternative]
    rfl: int                     # level written on the strip (requested / cruise), FL
    xfl: int                     # exit level the next sector accepts (truth), FL
    shown_xfl: int               # exit level written on the strip (differs from xfl on an "L" error until flagged)
    err: Optional[str] = None    # None | "T" (exit time inconsistent) | "L" (XFL not accepted at the exit point)
    time_err: float = 0.0        # minutes added to the printed exit time ("T" error, until flagged)
    delay: float = 0.0           # hold at entry (plan)
    route_i: int = 0             # 0 primary, 1 alternative (plan)
    levels: List[int] = field(default_factory=list)   # level of each segment of the current route (plan)
    flagged: bool = False
    fixed_last: bool = False     # the system set the last segment to xfl after a correct "L" flag

    def __post_init__(self) -> None:
        if not self.levels:
            self.levels = [self.rfl] * (len(self.route) - 1)

    @property
    def route(self) -> List[str]:
        return self.routes[self.route_i]

    @property
    def entry(self) -> str:
        return self.routes[0][0]

    @property
    def exit(self) -> str:
        return self.routes[0][-1]

    @property
    def nm_min(self) -> float:
        return SPEED_NM_MIN[self.speed]

    def times(self) -> List[float]:
        t = self.entry_t + self.delay
        out = [t]
        for a, b in zip(self.route, self.route[1:]):
            t += seg_len(a, b) / self.nm_min
            out.append(t)
        return out

    @property
    def t_entry(self) -> float:
        return self.entry_t + self.delay

    @property
    def t_exit(self) -> float:
        return self.times()[-1]

    def shown_exit(self) -> float:
        return self.t_exit + (0.0 if self.flagged else self.time_err)

    def point_levels(self, i: int) -> Tuple[int, ...]:
        """Levels the aircraft occupies over route point i (a change over a point counts at both levels)."""
        out = []
        if i > 0:
            out.append(self.levels[i - 1])
        if i < len(self.levels):
            out.append(self.levels[i])
        return tuple(sorted(set(out)))

    def exit_ok(self) -> bool:
        return self.levels[-1] == self.xfl

    def plan_key(self) -> tuple:
        return (self.delay, self.route_i, tuple(self.levels))


# ---- conflicts (analytic) -------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Conflict:
    a: str
    b: str
    kind: str                    # "punto" (common point) | "alcance" (overtaking) | "frente" (head-on)
    where: str                   # point name or "P-Q"
    t: float                     # minutes: when it happens (the earlier time over the point / the overtaking or meeting)
    level: int

    @property
    def pair(self) -> Tuple[str, str]:
        return (self.a, self.b)


def pair_key(a: str, b: str) -> Tuple[str, str]:
    return (a, b) if a < b else (b, a)


def pair_conflicts(fa: Flight, fb: Flight) -> List[Conflict]:
    """Every conflict of a pair with their current plans, earliest first."""
    a, b = (fa, fb) if fa.cs < fb.cs else (fb, fa)
    ra, rb = a.route, b.route
    ta, tb = a.times(), b.times()
    out: List[Conflict] = []
    pos_b = {p: i for i, p in enumerate(rb)}
    for i, p in enumerate(ra):
        j = pos_b.get(p)
        if j is None:
            continue
        common = set(a.point_levels(i)) & set(b.point_levels(j))
        if common and abs(ta[i] - tb[j]) < SEP_MIN - EPS:
            out.append(Conflict(a.cs, b.cs, "punto", p, min(ta[i], tb[j]), min(common)))
    segs_b = {(rb[j], rb[j + 1]): j for j in range(len(rb) - 1)}
    for i in range(len(ra) - 1):
        p, q = ra[i], ra[i + 1]
        la = a.levels[i]
        a1, a2 = ta[i], ta[i + 1]
        j = segs_b.get((p, q))
        if j is not None and b.levels[j] == la:
            b1, b2 = tb[j], tb[j + 1]
            if (a1 - b1) * (a2 - b2) < -EPS:          # the order changes along the segment: one overtakes the other
                da, db = a2 - a1, b2 - b1
                t = (a1 * db - b1 * da) / (db - da)
                out.append(Conflict(a.cs, b.cs, "alcance", f"{p}-{q}", t, la))
        j = segs_b.get((q, p))
        if j is not None and b.levels[j] == la:
            b1, b2 = tb[j], tb[j + 1]                  # b flies q -> p
            if a1 < b2 - EPS and b1 < a2 - EPS:        # both on the segment at the same time, opposite ways: they meet
                da, db = a2 - a1, b2 - b1
                t = (1.0 + a1 / da + b1 / db) / (1.0 / da + 1.0 / db)
                out.append(Conflict(a.cs, b.cs, "frente", f"{p}-{q}", t, la))
    out.sort(key=lambda c: (c.t, c.kind, c.where))
    return out


def first_conflict(fa: Flight, fb: Flight) -> Optional[Conflict]:
    cs = pair_conflicts(fa, fb)
    return cs[0] if cs else None


def find_conflicts(flights: Sequence[Flight]) -> Dict[Tuple[str, str], Conflict]:
    """Earliest conflict of every conflicting pair (pairs as sorted callsign tuples)."""
    out: Dict[Tuple[str, str], Conflict] = {}
    fl = list(flights)
    for i in range(len(fl)):
        for j in range(i + 1, len(fl)):
            c = first_conflict(fl[i], fl[j])
            if c is not None:
                out[c.pair] = c
    return out


def conflicts_of(f: Flight, flights: Sequence[Flight]) -> Dict[Tuple[str, str], Conflict]:
    out: Dict[Tuple[str, str], Conflict] = {}
    for g in flights:
        if g.cs != f.cs:
            c = first_conflict(f, g)
            if c is not None:
                out[c.pair] = c
    return out


# ---- resolutions ----------------------------------------------------------------------------------------------
@dataclass
class Action:
    cs: str
    kind: str                    # "nivel" | "demora" | "ruta"
    delay: float
    route_i: int
    levels: Tuple[int, ...]
    cost: float                  # resolution cost units (minutes of delay or extra flight, segments changed)

    def text(self, f: Flight) -> str:
        if self.kind == "demora":
            return f"{self.cs} +{self.delay - f.delay:g}' en {f.entry}"
        if self.kind == "ruta":
            via = "-".join(f.routes[self.route_i][1:-1])
            return f"{self.cs} ruta por {via}"
        r = f.route
        ch = [f"{r[i]}-{r[i + 1]} {lv}" for i, lv in enumerate(self.levels) if lv != f.levels[i]]
        return f"{self.cs} " + ", ".join(ch)


def can_change_segment(f: Flight, i: int, now: float) -> bool:
    """Segment i may get a new level: not the last one (exit at XFL) and its first point not yet reached."""
    return i < len(f.levels) - 1 and f.times()[i] > now + EPS


def candidate_actions(f: Flight, now: float) -> List[Action]:
    out: List[Action] = []
    not_entered = f.t_entry > now + EPS
    if not_entered:
        for d in range(1, 9):
            out.append(Action(f.cs, "demora", f.delay + d, f.route_i, tuple(f.levels), float(d)))
        if len(f.routes) > 1:
            ri = 1 - f.route_i
            extra = (route_length(f.routes[ri]) - route_length(f.route)) / f.nm_min
            n = len(f.routes[ri]) - 1
            lv = tuple([f.rfl] * (n - 1) + [f.levels[-1]])
            out.append(Action(f.cs, "ruta", f.delay, ri, lv, max(0.0, extra) + 0.5))
    n = len(f.levels)
    for i in range(n - 1):
        for j in range(i, n - 1):
            if not can_change_segment(f, i, now):
                continue
            base = f.levels[i]
            if any(f.levels[k] != base for k in range(i, j + 1)):
                continue
            for dl in (10, -10, 20, -20):
                lv = base + dl
                if not FL_MIN <= lv <= FL_MAX:
                    continue
                new = list(f.levels)
                for k in range(i, j + 1):
                    new[k] = lv
                out.append(Action(f.cs, "nivel", f.delay, f.route_i, tuple(new), float(j - i + 1) + (0.1 if abs(dl) == 20 else 0.0)))
    return out


def _apply_plan(f: Flight, delay: float, route_i: int, levels: Sequence[int]) -> tuple:
    old = (f.delay, f.route_i, list(f.levels))
    f.delay, f.route_i, f.levels = delay, route_i, list(levels)
    return old


def best_resolution(flights: Dict[str, Flight], pair: Tuple[str, str], now: float) -> Optional[Action]:
    """Cheapest single action on either aircraft of `pair` that removes its conflict and creates no new conflicting
    pair (it may also remove others). None when no single action does it."""
    allf = list(flights.values())
    best: Optional[Action] = None
    for cs in pair:
        f = flights[cs]
        before = set(conflicts_of(f, allf))
        if pair not in before:
            continue
        for act in candidate_actions(f, now):
            if best is not None and act.cost >= best.cost:
                continue
            old = _apply_plan(f, act.delay, act.route_i, act.levels)
            after = set(conflicts_of(f, allf))
            _apply_plan(f, *old)
            if pair not in after and after <= before:
                best = act
    return best


def best_plan(flights: Dict[str, Flight], pair: Tuple[str, str], now: float) -> Optional[List[Action]]:
    """One action if one is enough, else the cheapest two (the first may not create anything either)."""
    one = best_resolution(flights, pair, now)
    if one is not None:
        return [one]
    allf = list(flights.values())
    best: Optional[List[Action]] = None
    cost = float("inf")
    for cs in pair:
        f = flights[cs]
        before = set(conflicts_of(f, allf))
        for a1 in sorted(candidate_actions(f, now), key=lambda a: a.cost):
            if a1.cost >= cost:
                break
            old = _apply_plan(f, a1.delay, a1.route_i, a1.levels)
            ok = set(conflicts_of(f, allf)) <= before
            a2 = best_resolution(flights, pair, now) if ok else None
            _apply_plan(f, *old)
            if a2 is not None and a1.cost + a2.cost < cost:
                best, cost = [a1, a2], a1.cost + a2.cost
    return best


# ---- scenario generation --------------------------------------------------------------------------------------
@dataclass
class PlannerScenario:
    seed: int
    level: int
    flights: List[Flight]
    designed: Dict[Tuple[str, str], Conflict]
    attempt: int = 0
    ref_cost: float = 0.0        # sum of the cheapest single resolution of every designed conflict

    @property
    def spec(self) -> PlannerSpec:
        return planner_spec(self.level)

    def appear(self, f: Flight) -> float:
        return f.entry_t - self.spec.lead_min


def _half(rng, lo: float, hi: float) -> float:
    return rng.randrange(int(round(2 * lo)), int(round(2 * hi)) + 1) / 2.0


def _speed(rng) -> int:
    r = rng.random()
    acc = 0.0
    for s, w in SPEED_WEIGHTS:
        acc += w
        if r < acc:
            return s
    return SPEED_WEIGHTS[-1][0]


def _callsigns(rng, n: int) -> List[str]:
    out: List[str] = []
    while len(out) < n:
        cs = rng.choice(AIRLINES) + str(rng.randint(10, 9899))
        if cs not in out:
            out.append(cs)
    return out


def _make_flight(rng, cs: str, entry_t: float, entry: str = "", exit_: str = "", speed: int = 0,
                 fl: int = 0) -> Flight:
    if not entry:
        entry = rng.choice(GATES)
    if not exit_:
        exit_ = rng.choice([g for g in GATES if g != entry])
    speed = speed or _speed(rng)
    fl = fl or rng.choice(LEVELS_BY_PARITY[PARITY[exit_]])
    return Flight(cs, rng.choice(TYPES[speed]), speed, entry_t, route_options(entry, exit_), fl, fl, fl)


def _shares(ra: List[str], rb: List[str], kind: str) -> bool:
    if kind == "punto":
        return bool(set(ra) & set(rb) & set(INNER))
    sa = {(ra[i], ra[i + 1]) for i in range(len(ra) - 1)}
    sb = {(rb[i], rb[i + 1]) for i in range(len(rb) - 1)}
    if kind == "alcance":
        return bool(sa & sb)
    return bool({(q, p) for (p, q) in sa} & sb)


def _design_pair(rng, sc_spec: PlannerSpec, A: Flight, B: Flight, kind: str, lo: float, hi: float,
                 placed: Sequence[Flight] = ()) -> bool:
    """Rebuild B so that it conflicts with A by `kind` (B's gates, speed, level and entry time) and with none of the
    aircraft of the pairs already designed."""
    par = parity_of(A.rfl)
    exits = [g for g in GATES if PARITY[g] == par]
    for _ in range(60):
        xg = rng.choice(exits)
        eg = rng.choice([g for g in GATES if g != xg])
        r = route_options(eg, xg)[0]
        if not _shares(A.route, r, kind):
            continue
        sp = _speed(rng)
        if kind == "alcance" and sp == A.speed:
            sp = rng.choice([s for s in SPEED_NM_MIN if s != A.speed])
        B.routes = route_options(eg, xg)
        B.route_i = 0
        B.speed, B.type_code = sp, rng.choice(TYPES[sp])
        B.rfl = B.xfl = B.shown_xfl = A.rfl
        B.levels = [A.rfl] * (len(r) - 1)
        cands = []
        t0 = A.entry_t - 24.0
        for k in range(97):
            e = t0 + 0.5 * k
            if not lo <= e <= hi:
                continue
            B.entry_t = e
            c = first_conflict(A, B)
            if c is None or c.kind != kind:
                continue
            if c.t < max(A.entry_t, e) - sc_spec.lead_min + THINK_MIN:
                continue
            if kind == "punto" and c.where not in INNER:
                continue
            if any(first_conflict(B, g) for g in placed):
                continue
            cands.append(e)
        rng.shuffle(cands)
        pool = {g.cs: g for g in placed}
        pool[A.cs], pool[B.cs] = A, B
        for e in cands[:8]:
            B.entry_t = e
            now = max(A.entry_t, e) - sc_spec.lead_min + 1.0
            act = best_resolution(pool, pair_key(A.cs, B.cs), now)
            if act is not None and act.cost <= MAX_REF_COST:
                return True
    return False


KINDS = ("punto", "frente", "alcance")


def _try_generate(seed: int, level: int, attempt: int) -> Optional[PlannerScenario]:
    spec = planner_spec(level)
    rng = make_rng(seed, f"planner-{attempt}")
    n = spec.n_flights
    lo, hi = spec.lead_min, spec.lead_min + spec.window_min
    names = _callsigns(rng, n)
    times = sorted(_half(rng, lo, hi) for _ in range(n))
    times[0] = lo                                     # the first strip is on the board when the clock starts
    flights = [_make_flight(rng, cs, t) for cs, t in zip(names, times)]
    idx = list(range(n))
    rng.shuffle(idx)
    designed_cs: List[Tuple[str, str]] = []
    kinds = [KINDS[i % 3] for i in range(spec.conflicts)]
    rng.shuffle(kinds)
    placed: List[Flight] = []
    for k in range(spec.conflicts):
        A, B = flights[idx[2 * k]], flights[idx[2 * k + 1]]
        for _ in range(40):                           # A must not meet the aircraft of the pairs already designed
            if not any(first_conflict(A, g) for g in placed):
                break
            A.entry_t = _half(rng, lo, hi)
        else:
            return None
        ok = _design_pair(rng, spec, A, B, kinds[k], lo, hi + 6, placed)
        if not ok:
            ok = any(_design_pair(rng, spec, A, B, kk, lo, hi + 6, placed) for kk in KINDS if kk != kinds[k])
        if not ok:
            return None
        placed += [A, B]
        designed_cs.append(pair_key(A.cs, B.cs))
    in_design = {cs for p in designed_cs for cs in p}
    # coordination errors on flights outside the designed pairs
    free = [f for f in flights if f.cs not in in_design]
    rng.shuffle(free)
    for f in free[:spec.coord_errors]:
        if rng.random() < 0.5:
            f.err = "T"
            f.time_err = rng.choice([-3.0, -2.0, -1.5, -1.0, 1.0, 1.5, 2.0, 3.0])
        else:
            f.err = "L"
            wrong = f.xfl + rng.choice([10, -10])     # one level off: the parity the exit point does not accept
            f.rfl = f.shown_xfl = wrong
            f.levels = [wrong] * (len(f.route) - 1)
    by = {f.cs: f for f in flights}

    def variants() -> List[List[Flight]]:
        """Plan as given, and plan with every "L" error corrected (the last segment at the true XFL)."""
        v2 = copy.deepcopy(flights)
        for f in v2:
            if f.err == "L":
                f.levels[-1] = f.xfl
        return [flights, v2]

    def extras() -> List[Tuple[str, str]]:
        bad: List[Tuple[str, str]] = []
        want = set(designed_cs)
        for fl in variants():
            got = find_conflicts(fl)
            bad += [p for p in got if p not in want]
            if not want <= set(got):
                return [("", "")]
        return bad

    for _ in range(120):
        bad = extras()
        if not bad:
            break
        if bad[0] == ("", ""):
            return None
        p = bad[0]
        movable = [cs for cs in p if cs not in in_design]
        if not movable:
            return None
        f = by[rng.choice(movable)]
        if f.err == "L" or rng.random() < 0.5:
            f.entry_t = _half(rng, lo, hi)
        else:
            f.rfl = f.xfl = f.shown_xfl = rng.choice(LEVELS_BY_PARITY[PARITY[f.exit]])
            f.levels = [f.rfl] * (len(f.route) - 1)
    else:
        return None
    if extras():
        return None
    designed = find_conflicts(flights)
    # every designed conflict must be solvable by one action once both strips are on the board; the cheapest
    # costs add up to the reference cost the player's resolutions are compared with
    ref = 0.0
    for p, c in designed.items():
        now = max(by[p[0]].entry_t, by[p[1]].entry_t) - spec.lead_min + 1.0
        act = best_resolution(by, p, now)
        if act is None or act.cost > MAX_REF_COST + 0.1:
            return None
        ref += act.cost
    flights.sort(key=lambda f: (f.entry_t, f.cs))
    return PlannerScenario(seed, level, flights, designed, attempt, round(ref, 1))


def generate_planner(seed: int, level: int) -> PlannerScenario:
    """Deterministic scenario for (seed, level). Designed conflicts are built pair by pair and every other pair is
    pushed apart, so the conflict set is known by construction (tests check it with an independent sweep)."""
    for attempt in range(200):
        sc = _try_generate(int(seed), max(1, min(10, int(level))), attempt)
        if sc is not None:
            return sc
    raise RuntimeError(f"no planner scenario for seed {seed} level {level}")


# ---- the running exercise -------------------------------------------------------------------------------------
class PlannerWorld:
    """Clock, strips on the board, the player's decisions and every outcome. Ticked in REAL seconds."""

    def __init__(self, scenario: PlannerScenario, audio=None):
        self.sc = scenario
        self.spec = scenario.spec
        self.level = scenario.level
        self.seed = scenario.seed
        self.flights: Dict[str, Flight] = {f.cs: copy.deepcopy(f) for f in scenario.flights}
        self.orig_levels: Dict[str, Dict[int, Tuple[int, ...]]] = {}
        self.order = [f.cs for f in scenario.flights]
        self.designed = dict(scenario.designed)
        self.t = 0.0
        self.real_t = 0.0
        self.finished = False
        self.pauses = 0
        self.audio = audio
        self.visible_real: Dict[str, float] = {}
        self.entered: Dict[str, float] = {}
        self.exited: Dict[str, float] = {}
        self.declared: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self.false_alarms: List[Dict[str, Any]] = []
        self.flags: Dict[str, Dict[str, Any]] = {}
        self.happened: Dict[Tuple[str, str], Dict[str, Any]] = {}
        self.coord_missed: List[str] = []
        self.exits: Dict[str, Dict[str, Any]] = {}
        self.edits: List[Dict[str, Any]] = []
        self.decisions: List[Dict[str, Any]] = []
        self.events: List[Dict[str, Any]] = []     # feedback stream for the UI: {"kind","outcome","text"}
        self.touched_levels: set = set()
        self._conf: Optional[Dict[Tuple[str, str], Conflict]] = None
        self._advance_visibility()

    # ---- queries --------------------------------------------------------------------------------------------
    def appear(self, cs: str) -> float:
        return self.flights[cs].entry_t - self.spec.lead_min

    def visible(self, cs: str) -> bool:
        return cs in self.visible_real

    def on_board(self) -> List[str]:
        """Strips on the board, by entry time: visible and not gone (they stay 1 minute after the exit)."""
        out = [cs for cs in self.order if cs in self.visible_real
               and not (cs in self.exited and self.t > self.exited[cs] + 1.0)]
        return sorted(out, key=lambda cs: (self.flights[cs].t_entry, cs))

    def conflicts(self) -> Dict[Tuple[str, str], Conflict]:
        if self._conf is None:
            self._conf = find_conflicts(list(self.flights.values()))
        return self._conf

    def future_conflicts(self) -> Dict[Tuple[str, str], Conflict]:
        return {p: c for p, c in self.conflicts().items() if c.t > self.t and p not in self.happened}

    def end_time(self) -> float:
        return max(f.t_exit for f in self.flights.values())

    # ---- time -----------------------------------------------------------------------------------------------
    def _advance_visibility(self) -> None:
        for cs in self.order:
            if cs not in self.visible_real and self.appear(cs) <= self.t + EPS:
                self.visible_real[cs] = self.real_t

    def _event(self, kind: str, outcome: str, text: str) -> None:
        self.events.append({"kind": kind, "outcome": outcome, "text": text, "t": self.t})

    def advance(self, real_dt: float) -> None:
        if self.finished or real_dt <= 0:
            return
        self.real_t += real_dt
        self.t += real_dt / self.spec.rs_per_min
        self._advance_visibility()
        for cs, f in self.flights.items():
            if cs not in self.entered and f.t_entry <= self.t + EPS:
                self.entered[cs] = f.t_entry
                if f.err and not f.flagged:
                    self.coord_missed.append(cs)
                    self._event("coord", "blank", f"{cs} {'hora' if f.err == 'T' else 'XFL'}")
        for p, c in sorted(self.conflicts().items(), key=lambda kv: kv[1].t):
            if p not in self.happened and c.t <= self.t + EPS:
                self.happened[p] = {"conflict": c, "created": p not in self.designed, "real": self.real_t}
                self._event("sep", "wrong", f"{p[0]}/{p[1]} {c.where}")
        for cs, f in self.flights.items():
            if cs not in self.exited and f.t_exit <= self.t + EPS:
                self.exited[cs] = f.t_exit
                self.exits[cs] = {"ok": f.exit_ok(), "level": f.levels[-1], "xfl": f.xfl, "t": f.t_exit}
                if cs in self.touched_levels and not f.exit_ok() and not (f.err == "L" and not f.flagged):
                    self._event("exit", "wrong", f"{cs} {f.exit} {f.levels[-1]}")
        if self.audio is not None:
            self.audio.tick(real_dt)
        if len(self.exited) == len(self.flights):
            self.finish()

    def finish(self) -> None:
        if self.finished:
            return
        self.finished = True
        if self.audio is not None:
            self.audio.finish()

    # ---- decisions ------------------------------------------------------------------------------------------
    def _latency(self, *css: str) -> float:
        return round(max(0.0, self.real_t - max(self.visible_real.get(c, self.real_t) for c in css)), 2)

    def declare(self, a: str, b: str) -> Tuple[Optional[str], str]:
        """Declare that a and b will conflict. Returns (outcome, message); outcome None = not counted."""
        if self.finished or a == b or a not in self.flights or b not in self.flights:
            return None, "-"
        if not (self.visible(a) and self.visible(b)):
            return None, "-"
        p = pair_key(a, b)
        if p in self.declared:
            return None, "ya"
        if p in self.happened:
            return None, "tarde"
        cur = self.conflicts().get(p)
        orig = self.designed.get(p)
        real = (cur is not None and cur.t > self.t) or (orig is not None and orig.t > self.t)
        outcome = "correct" if real else "wrong"
        rec = {"t": self.t, "real": self.real_t, "outcome": outcome, "latency": self._latency(a, b)}
        self.decisions.append({"kind": "conflicto", "latency": rec["latency"], "t": self.t, "outcome": outcome})
        if real:
            self.declared[p] = rec
        else:
            rec["pair"] = p
            self.false_alarms.append(rec)
        self._event("det", outcome, f"{p[0]}/{p[1]}")
        return outcome, ""

    def flag(self, cs: str) -> Tuple[Optional[str], str]:
        """Mark the strip as wrongly coordinated (exit time or XFL). Only before the aircraft enters."""
        f = self.flights.get(cs)
        if self.finished or f is None or not self.visible(cs):
            return None, "-"
        if cs in self.flags:
            return None, "ya"
        if f.t_entry <= self.t + EPS:
            return None, "tarde"
        outcome = "correct" if f.err else "wrong"
        self.flags[cs] = {"t": self.t, "outcome": outcome, "latency": self._latency(cs)}
        self.decisions.append({"kind": "ficha", "latency": self._latency(cs), "t": self.t, "outcome": outcome})
        if f.err:
            f.flagged = True
            if f.err == "L":
                f.shown_xfl = f.xfl
                f.levels[-1] = f.xfl
                f.fixed_last = True
                self._conf = None
        self._event("coord", outcome, f"{cs}")
        return outcome, ""

    def editable(self, cs: str) -> Dict[str, Any]:
        """What the player may still change on this strip now."""
        f = self.flights[cs]
        before_entry = f.t_entry > self.t + EPS and cs not in self.entered
        ts = f.times()
        return {"delay": before_entry, "route": before_entry and len(f.routes) > 1,
                "segments": [ts[i] > self.t + EPS for i in range(len(f.levels))]}

    def apply(self, cs: str, delay: Optional[float] = None, route_i: Optional[int] = None,
              levels: Optional[Sequence[int]] = None) -> Tuple[bool, str, Dict[str, Any]]:
        """Commit a change to one aircraft's plan. Returns (ok, message, effect) where effect lists the pairs whose
        conflict it removed and the pairs it created (the UI shows them only at levels with the check aid)."""
        f = self.flights.get(cs)
        if self.finished or f is None or not self.visible(cs) or cs in self.exited:
            return False, "-", {}
        ed = self.editable(cs)
        nd = f.delay if delay is None else float(delay)
        nr = f.route_i if route_i is None else int(route_i)
        if (nd != f.delay or nr != f.route_i) and not ed["delay"]:
            return False, "tarde", {}
        if nd < 0 or nd > 30 or nr not in range(len(f.routes)):
            return False, "-", {}
        if nr != f.route_i and levels is None:
            n = len(f.routes[nr]) - 1
            levels = [f.rfl] * (n - 1) + [f.levels[-1]]
        nl = list(f.levels if levels is None else levels)
        if len(nl) != len(f.routes[nr]) - 1 or any(not FL_MIN <= int(v) <= FL_MAX for v in nl):
            return False, "-", {}
        if nr == f.route_i:
            ts = f.times()
            for i, (o, v) in enumerate(zip(f.levels, nl)):
                if o != v and ts[i] <= self.t + EPS:     # the segment has started: too late (the last one may change:
                    return False, "tarde", {}            # then the exit is checked against the XFL)
        if (nd, nr, tuple(nl)) == f.plan_key():
            return False, "=", {}
        before = set(p for p in conflicts_of(f, list(self.flights.values())) if p not in self.happened)
        old = f.plan_key()
        f.delay, f.route_i, f.levels = nd, nr, [int(v) for v in nl]
        self._conf = None
        after = set(p for p in conflicts_of(f, list(self.flights.values())) if p not in self.happened)
        if tuple(f.levels) != old[2] or nr != old[1]:
            self.touched_levels.add(cs)
        lat = self._latency(cs)
        self.edits.append({"cs": cs, "t": self.t, "from": old, "to": f.plan_key(), "latency": lat})
        self.decisions.append({"kind": "cambio", "latency": lat, "t": self.t, "outcome": "info"})
        return True, "", {"removed": sorted(before - after), "created": sorted(after - before)}


# ---- scoring --------------------------------------------------------------------------------------------------
SEP_LOSS = 12.0
DET_BLANK = 3.0
FALSE_ALARM = 3.0
COORD_BLANK = 4.0
COORD_FALSE = 2.0
EXIT_BAD = 6.0
COST_SLACK = 1.0                 # free cost units per designed conflict above the cheapest resolutions
COST_ALLOWANCE = 3.0             # free cost units for a conflict the player created and then declared
COST_POINT = 1.0
COST_CAP = 15.0
COMPONENTS = ("Detección", "Separación", "Coordinación", "Salida")


@dataclass
class PlannerResult:
    level: int
    seed: int
    mode: str
    correct: int = 0
    wrong: int = 0
    blank: int = 0
    real_seconds: float = 0.0
    score: float = 100.0
    breakdown: List[Tuple[str, float]] = field(default_factory=list)
    components: Dict[str, Dict[str, int]] = field(default_factory=dict)
    thirds_data: Optional[List[Dict[str, float]]] = None
    goal_text: str = ""
    met: bool = False
    assisted: bool = False
    flights: int = 0
    conflicts: int = 0           # designed (present if nobody acts)
    found: int = 0               # designed conflicts declared in time
    missed: int = 0              # designed conflicts never declared
    false_alarms: int = 0
    lost: int = 0                # conflicts that happened (designed or created)
    created: int = 0             # conflicts created by the player's changes that happened
    coord_errors: int = 0
    coord_flagged: int = 0
    coord_false: int = 0
    exits_checked: int = 0       # aircraft whose levels the player changed
    exits_ok: int = 0
    delay_min: float = 0.0
    reroute_min: float = 0.0
    reroutes: int = 0
    level_changes: int = 0       # segments left at a level different from the strip
    cost_units: float = 0.0
    ref_cost: float = 0.0        # cheapest single resolutions of the designed conflicts, summed
    decisions: int = 0
    s_per_decision: Optional[float] = None
    audio: Optional[Dict[str, Any]] = None

    @property
    def items(self) -> int:
        return self.correct + self.wrong + self.blank

    @property
    def accuracy(self) -> float:
        return 100.0 * self.correct / self.items if self.items else 0.0

    @property
    def seconds_per_item(self) -> float:
        if self.s_per_decision is not None:
            return self.s_per_decision
        return self.real_seconds / self.items if self.items else 0.0

    def component_accuracy(self, name: str) -> Optional[float]:
        c = self.components.get(name)
        if not c:
            return None
        n = c["correct"] + c["wrong"] + c["blank"]
        return 100.0 * c["correct"] / n if n else None

    def worst_component(self) -> Optional[Tuple[str, float]]:
        best: Optional[Tuple[str, float]] = None
        for k in self.components:
            a = self.component_accuracy(k)
            if a is not None and (best is None or a < best[1]):
                best = (k, a)
        return best


def resolution_cost(world: PlannerWorld) -> Dict[str, float]:
    """Delay minutes, extra minutes of rerouting and segments at a level other than the strip's, at the end."""
    delay = rer = 0.0
    nre = lv = 0
    for cs, f in world.flights.items():
        orig = next(x for x in world.sc.flights if x.cs == cs)
        delay += f.delay
        if f.route_i != orig.route_i:
            nre += 1
            rer += max(0.0, (route_length(f.route) - route_length(orig.route)) / f.nm_min)
            lv += sum(1 for v in f.levels[:-1] if v != f.rfl)
        else:
            for i, v in enumerate(f.levels):
                o = orig.levels[i]
                if i == len(f.levels) - 1 and f.fixed_last:
                    o = f.xfl
                if v != o:
                    lv += 1
    return {"delay": delay, "reroute_min": rer, "reroutes": nre, "levels": lv, "units": delay + rer + lv}


def compute_planner_result(world: PlannerWorld, mode: str = "Ladder") -> PlannerResult:
    from .scoring import thirds_schema
    spec = world.spec
    r = PlannerResult(world.level, world.seed, mode)
    r.real_seconds = world.real_t
    r.flights = len(world.flights)
    comp: Dict[str, Dict[str, int]] = {k: {"correct": 0, "wrong": 0, "blank": 0} for k in COMPONENTS}
    timed: List[Tuple[float, str]] = []
    score = 100.0
    bd: List[Tuple[str, float]] = []

    def bump(name: str, outcome: str, t: float) -> None:
        comp[name][outcome] += 1
        timed.append((t, outcome))

    r.conflicts = len(world.designed)
    # detection
    for p, c in world.designed.items():
        d = world.declared.get(p)
        if d and d["outcome"] == "correct":
            r.found += 1
            bump("Detección", "correct", d["t"])
        else:
            r.missed += 1
            bump("Detección", "blank", c.t)
    for p, d in world.declared.items():
        if p not in world.designed:
            bump("Detección", "correct", d["t"])
    for fa in world.false_alarms:
        r.false_alarms += 1
        bump("Detección", "wrong", fa["t"])
    if r.missed:
        score -= DET_BLANK * r.missed
        bd.append((f"{r.missed} conflicto(s) sin detectar", -DET_BLANK * r.missed))
    if r.false_alarms:
        score -= FALSE_ALARM * r.false_alarms
        bd.append((f"{r.false_alarms} falsa(s) alarma(s)", -FALSE_ALARM * r.false_alarms))
    # separation
    for p, c in world.designed.items():
        h = world.happened.get(p)
        bump("Separación", "wrong" if h else "correct", (h["conflict"].t if h else c.t))
    for p, h in world.happened.items():
        r.lost += 1
        c = h["conflict"]
        if h["created"]:
            r.created += 1
            bump("Separación", "wrong", c.t)
        score -= SEP_LOSS
        bd.append((f"Pérdida {p[0]}/{p[1]} {c.where} {fmt_t(c.t)}" + (" (creada)" if h["created"] else ""), -SEP_LOSS))
    # coordination
    for cs, f in world.flights.items():
        if f.err:
            r.coord_errors += 1
            fl = world.flags.get(cs)
            if fl and fl["outcome"] == "correct":
                r.coord_flagged += 1
                bump("Coordinación", "correct", fl["t"])
            else:
                bump("Coordinación", "blank", f.t_entry)
                score -= COORD_BLANK
                bd.append((f"Ficha {cs} sin marcar ({'hora de salida' if f.err == 'T' else 'XFL'})", -COORD_BLANK))
    for cs, fl in world.flags.items():
        if fl["outcome"] == "wrong":
            r.coord_false += 1
            bump("Coordinación", "wrong", fl["t"])
            score -= COORD_FALSE
            bd.append((f"Ficha {cs} marcada sin error", -COORD_FALSE))
    # exits of the aircraft whose levels the player changed
    for cs in sorted(world.touched_levels):
        f = world.flights[cs]
        if f.err == "L" and not f.flagged:
            continue                                     # already counted as a coordination miss
        r.exits_checked += 1
        ok = f.exit_ok()
        if ok:
            r.exits_ok += 1
        bump("Salida", "correct" if ok else "wrong", f.t_exit)
        if not ok:
            score -= EXIT_BAD
            bd.append((f"{cs} sale de {f.exit} a {f.levels[-1]} (XFL {f.xfl})", -EXIT_BAD))
    # resolution cost
    rc = resolution_cost(world)
    r.delay_min, r.reroute_min, r.reroutes, r.level_changes = rc["delay"], rc["reroute_min"], int(rc["reroutes"]), int(rc["levels"])
    r.cost_units = round(rc["units"], 1)
    r.ref_cost = world.sc.ref_cost
    allowance = (world.sc.ref_cost + COST_SLACK * r.conflicts
                 + COST_ALLOWANCE * sum(1 for p in world.declared if p not in world.designed))
    excess = max(0.0, rc["units"] - allowance)
    if excess > 0:
        pen = min(COST_CAP, COST_POINT * excess)
        score -= pen
        bd.append((f"Coste de resolución {rc['units']:.1f} > {allowance:.0f} permitido", -pen))
    r.components = {k: v for k, v in comp.items() if v["correct"] + v["wrong"] + v["blank"]}
    r.correct = sum(v["correct"] for v in comp.values())
    r.wrong = sum(v["wrong"] for v in comp.values())
    r.blank = sum(v["blank"] for v in comp.values())
    r.score = max(0.0, round(score, 1))
    r.breakdown = bd
    r.decisions = len(world.decisions)
    lats = [d["latency"] for d in world.decisions if d.get("latency") is not None]
    r.s_per_decision = round(sum(lats) / len(lats), 2) if lats else None
    end = max(world.t, 1.0)
    r.thirds_data = thirds_schema(timed, end, r.real_seconds)
    r.goal_text = f"accuracy >= {int(spec.goal_accuracy * 100)}% and 0 losses"
    r.met = bool(r.items and r.accuracy >= spec.goal_accuracy * 100.0 and r.lost == 0)
    r.assisted = bool(world.pauses > 0 and world.level >= 5)
    if world.audio is not None:
        r.audio = world.audio.summary()
    return r


def fmt_t(t: float) -> str:
    """Exercise time as mm:ss (strip times are always :00 or :30)."""
    s = int(round(max(0.0, t) * 60))
    return f"{s // 60:02d}:{s % 60:02d}"
