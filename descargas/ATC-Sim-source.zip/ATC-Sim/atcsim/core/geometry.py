"""Pure 2-D geometry for the sector. Units: NM, degrees (true, 0 = north, clockwise), knots, seconds.

x points east, y points north.
"""
from __future__ import annotations

import math
from typing import Iterable, Optional, Sequence, Tuple

Point = Tuple[float, float]


def norm360(h: float) -> float:
    """Normalise a heading to [0, 360)."""
    h = math.fmod(h, 360.0)
    if h < 0:
        h += 360.0
    return h if h < 360.0 else 0.0


def angle_diff(target: float, current: float) -> float:
    """Signed shortest difference target - current in (-180, 180]. Positive = turn right."""
    d = math.fmod(target - current, 360.0)
    if d > 180.0:
        d -= 360.0
    elif d <= -180.0:
        d += 360.0
    return d


def vec_from_hdg(hdg: float, speed: float) -> Point:
    """Velocity (x east, y north) in the same unit as speed for a heading in degrees."""
    r = math.radians(hdg)
    return (speed * math.sin(r), speed * math.cos(r))


def hdg_from_vec(dx: float, dy: float) -> float:
    """Heading (0-360) of a vector pointing (dx east, dy north)."""
    if dx == 0.0 and dy == 0.0:
        return 0.0
    return norm360(math.degrees(math.atan2(dx, dy)))


def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def bearing(a: Point, b: Point) -> float:
    return hdg_from_vec(b[0] - a[0], b[1] - a[1])


def point_in_polygon(p: Point, poly: Sequence[Point]) -> bool:
    """Ray casting; points exactly on an edge count as inside for the top/left edges only (good enough)."""
    x, y = p
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if (yi > y) != (yj > y):
            xin = (xj - xi) * (y - yi) / (yj - yi) + xi
            if x < xin:
                inside = not inside
        j = i
    return inside


def segment_intersection(p1: Point, p2: Point, p3: Point, p4: Point) -> Optional[Tuple[float, float, Point]]:
    """Intersection of segments p1p2 and p3p4. Returns (u, v, point) with u along p1p2, v along p3p4 in [0,1]."""
    d1x, d1y = p2[0] - p1[0], p2[1] - p1[1]
    d2x, d2y = p4[0] - p3[0], p4[1] - p3[1]
    den = d1x * d2y - d1y * d2x
    if abs(den) < 1e-12:
        return None
    ex, ey = p3[0] - p1[0], p3[1] - p1[1]
    u = (ex * d2y - ey * d2x) / den
    v = (ex * d1y - ey * d1x) / den
    if 0.0 <= u <= 1.0 and 0.0 <= v <= 1.0:
        return u, v, (p1[0] + u * d1x, p1[1] + u * d1y)
    return None


def interval_inside_circle(rx: float, ry: float, vx: float, vy: float, radius: float,
                           t0: float, t1: float) -> Optional[Tuple[float, float]]:
    """Time interval within [t0, t1] where |r + v t| < radius (r, v are relative position/velocity at t = 0).

    Returns None if the relative distance never goes below `radius` in the window.
    """
    a = vx * vx + vy * vy
    b = 2.0 * (rx * vx + ry * vy)
    c = rx * rx + ry * ry - radius * radius
    if a < 1e-12:
        return (t0, t1) if c < 0 else None
    disc = b * b - 4.0 * a * c
    if disc <= 0.0:
        return None
    s = math.sqrt(disc)
    lo = (-b - s) / (2.0 * a)
    hi = (-b + s) / (2.0 * a)
    lo = max(lo, t0)
    hi = min(hi, t1)
    if lo >= hi:
        return None
    return (lo, hi)


def interval_abs_below(z0: float, dz: float, limit: float, t0: float, t1: float) -> Optional[Tuple[float, float]]:
    """Interval within [t0, t1] where |z0 + dz t| < limit (linear in t)."""
    if abs(dz) < 1e-12:
        return (t0, t1) if abs(z0) < limit else None
    ta = (-limit - z0) / dz
    tb = (limit - z0) / dz
    lo, hi = (ta, tb) if ta < tb else (tb, ta)
    lo = max(lo, t0)
    hi = min(hi, t1)
    if lo >= hi:
        return None
    return (lo, hi)


def closest_approach(rx: float, ry: float, vx: float, vy: float) -> Tuple[float, float]:
    """Time (>= 0) and distance of the closest point of approach for relative position r and velocity v.

    If v is (nearly) zero, or the aircraft are already diverging, t = 0 and the distance is |r|.
    """
    vv = vx * vx + vy * vy
    if vv < 1e-12:
        return 0.0, math.hypot(rx, ry)
    t = -(rx * vx + ry * vy) / vv
    if t < 0.0:
        t = 0.0
    return t, math.hypot(rx + vx * t, ry + vy * t)


def wind_vector(wind_from: float, wind_speed: float) -> Point:
    """Wind velocity vector (direction the air moves TOWARDS) for wind blowing FROM `wind_from`."""
    return vec_from_hdg(norm360(wind_from + 180.0), wind_speed)


def heading_for_track(track: float, tas: float, wind_from: float, wind_speed: float) -> Optional[Tuple[float, float]]:
    """Heading and ground speed needed to make good `track` with true airspeed `tas` in the wind.

    Returns None if the wind is too strong to hold the track (crosswind component >= tas).
    Uses the wind triangle: sin(WCA) = (ws / tas) * sin(wind_to_angle - track).
    """
    if tas <= 0:
        return None
    wd = norm360(wind_from + 180.0)  # direction the wind blows towards
    # crosswind component relative to the desired track (positive = pushes to the right of track)
    ang = math.radians(wd - track)
    cross = wind_speed * math.sin(ang)
    if abs(cross) >= tas:
        return None
    wca = math.asin(-cross / tas)  # crab into the wind
    hdg = norm360(track + math.degrees(wca))
    along = wind_speed * math.cos(ang)
    gs = tas * math.cos(wca) + along
    if gs <= 0:
        return None
    return hdg, gs
