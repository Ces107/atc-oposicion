"""Where the app keeps its own files: a writable per-user folder, never the install folder or the package."""
from __future__ import annotations

import os
import sys

APP_DIR = "ATC-Sim"


def user_data_dir(create: bool = True) -> str:
    """%LOCALAPPDATA%\\ATC-Sim on Windows, ~/Library/Application Support/ATC-Sim on macOS, $XDG_DATA_HOME/ATC-Sim elsewhere.
    SIM_DATA_DIR overrides it (tests, portable use)."""
    forced = os.environ.get("SIM_DATA_DIR")
    if forced:
        base = forced
    elif sys.platform == "win32":
        base = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Local"), APP_DIR)
    elif sys.platform == "darwin":
        base = os.path.join(os.path.expanduser("~"), "Library", "Application Support", APP_DIR)
    else:
        base = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share"), APP_DIR)
    if create:
        try:
            os.makedirs(base, exist_ok=True)
        except OSError:
            pass
    return base


def resource_dir() -> str:
    """Folder holding read-only bundled files (the icon): the PyInstaller bundle or the source tree."""
    return getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
