"""Difficulty ladder and scenario data structures (pure data, no simulation code)."""
from __future__ import annotations

import hashlib
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


def make_rng(seed: int, stream: str) -> random.Random:
    """Independent, reproducible random stream derived from the run seed and a stream name."""
    h = hashlib.sha256(f"{int(seed)}:{stream}".encode()).digest()
    return random.Random(int.from_bytes(h[:8], "big"))


@dataclass(frozen=True)
class LevelSpec:
    level: int
    name: str
    n_aircraft: int
    window_s: float          # REAL seconds over which traffic enters
    scale: float             # simulated seconds per real second
    wind_kt: float
    design_conflicts: int    # conflict pairs designed into the traffic (if nobody acts)
    task_gap_s: float        # mean REAL seconds between interrupting tasks
    task_deadline_s: float   # REAL seconds available to answer a task
    aids: int                # 0 none .. 3 full (see README)
    zone: bool               # restricted zone in use
    pilot_delay_s: float     # REAL seconds between instruction and execution
    level_change_share: float
    readback_error_rate: float
    goal_accuracy: float     # accuracy goal used for "Met"
    kinds: Tuple[str, ...]   # enabled task kinds


ALL_KINDS = ("readback", "transfer", "alert", "levelreq", "memory", "ttc", "eta")

LEVELS: List[LevelSpec] = [
    LevelSpec(1, "Warm-up",     4, 170, 2.0, 0, 1, 40, 14, 3, False, 1.5, 0.30, 0.25, 0.80, ("readback", "transfer")),
    LevelSpec(2, "Easy",        6, 210, 2.5, 0, 2, 32, 12, 3, False, 1.5, 0.35, 0.25, 0.85, ("readback", "transfer", "alert")),
    LevelSpec(3, "Steady",      9, 260, 3.0, 6, 2, 28, 11, 2, False, 2.0, 0.40, 0.25, 0.88, ("readback", "transfer", "alert", "levelreq")),
    LevelSpec(4, "Standard",   12, 300, 3.5, 10, 3, 24, 10, 2, True, 2.0, 0.40, 0.25, 0.90, ALL_KINDS[:6]),
    LevelSpec(5, "Competitive", 16, 340, 4.0, 14, 4, 20, 9, 1, True, 2.0, 0.45, 0.30, 0.90, ALL_KINDS),
    LevelSpec(6, "Hard",        22, 380, 4.5, 18, 6, 16, 8, 1, True, 2.5, 0.45, 0.30, 0.88, ALL_KINDS),
    LevelSpec(7, "Elite",       28, 400, 5.0, 24, 8, 13, 7, 0, True, 2.5, 0.50, 0.30, 0.85, ALL_KINDS),
    LevelSpec(8, "Extreme",     36, 410, 5.5, 28, 11, 11, 6.5, 0, True, 3.0, 0.50, 0.35, 0.80, ALL_KINDS),
    LevelSpec(9, "Superhuman",  46, 420, 6.0, 34, 15, 9, 6, 0, True, 3.0, 0.55, 0.35, 0.75, ALL_KINDS),
    LevelSpec(10, "Impossible", 60, 420, 6.5, 40, 20, 7, 5, 0, True, 3.5, 0.55, 0.40, 0.70, ALL_KINDS),
]


def level_spec(level: int) -> LevelSpec:
    return LEVELS[max(1, min(10, int(level))) - 1]


@dataclass
class AircraftSpec:
    callsign: str
    type_code: str
    route_name: str          # e.g. "R3" or "R3~" (reverse)
    route: List[str]         # fix names, first = entry gate, last = exit gate
    spawn_time: float        # simulated seconds
    entry_alt: float
    exit_alt: float
    tas: float
    advance_nm: float = 0.0  # start this far along the route instead of at the entry gate (tutorial)


@dataclass
class Scenario:
    seed: int
    level: int
    specs: List[AircraftSpec]
    wind_from: float
    wind_speed: float
    scale: float
    spawn_end: float                      # simulated seconds when the last aircraft has entered
    zone_from: Optional[float] = None     # simulated seconds; None = no zone
    zone_until: Optional[float] = None
    designed_pairs: List[Tuple[str, str]] = field(default_factory=list)
    null_losses: int = 0                  # loss-of-separation episodes if nobody acts (measured)
    title: str = ""
    scripted: bool = False
    meta: Dict[str, object] = field(default_factory=dict)
