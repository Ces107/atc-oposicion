"""The 3-minute practice scenario: a scripted sequence of steps that teaches the controls by doing them.

The tutorial only reads the world (selected aircraft, action log, clearances, task stats); the UI performs the
actions. `Tutorial.update()` advances the step when the current step's condition is met.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional

from .scenario import AircraftSpec, Scenario
from .world import World


@dataclass
class Step:
    title: str
    text: str
    cond: Callable[[World], bool]
    on_enter: Optional[Callable[[World], None]] = None
    highlight: str = ""       # callsign to mark on the scope
    freeze: bool = False      # the clock is stopped while the learner reads and does the first steps
    keys: str = ""            # key reminder shown under the text


def tutorial_scenario() -> Scenario:
    specs = [
        AircraftSpec("TUT1", "B738", "R1", ["MOREA", "CANTO", "MIDAS", "ORISA"], 0.0, 30000, 30000, 360, advance_nm=25.0),
        AircraftSpec("TUT2", "A320", "R2~", ["NERVA", "REGAL", "MIDAS", "VELAR", "LUNDA"], 0.0, 30000, 30000, 360,
                     advance_nm=28.8),
        AircraftSpec("TUT3", "E190", "R7", ["SULMA", "DORNA", "REGAL", "TEJAR"], 0.0, 26000, 28000, 340, advance_nm=20.0),
    ]
    sc = Scenario(0, 1, specs, 0.0, 0.0, 4.0, 0.0, title="Practice", scripted=True)
    return sc


def _did(w: World, kind: str, cs: str = "") -> int:
    return sum(1 for (_, k, c) in w.actions if k == kind and (not cs or c == cs))


def _fast(w: World) -> None:
    w.scale = 10.0          # the wait for TUT1 to pass MIDAS would take about a minute at x4: run faster meanwhile


def _normal(w: World) -> None:
    w.scale = 4.0


def _tut4(w: World) -> None:
    _normal(w)
    w.pending_spawns.append(AircraftSpec("TUT4", "A320", "R3", ["ALBAR", "FARO", "MIDAS", "DORNA", "SULMA"], w.t + 1,
                                         36000, 36000, 380, advance_nm=74.0))
    w.pending_spawns.sort(key=lambda s: s.spawn_time)


def _long_deadline(t) -> None:
    if t is not None:
        t.time_left = t.time_total = 45.0


def _force_rb(w: World) -> None:
    w.force_readback = True


def _alert(w: World) -> None:
    _long_deadline(w.tasks._create_alert())


def _levelreq(w: World) -> None:
    ac = w.aircraft.get("TUT1")
    if ac is None:
        return
    t = w.tasks._new("levelreq", "TUT1 requests descend FL290.",
                     ["Approve", "Deny"], 0, 45.0, "TUT1", {"alt": 29000, "safe": True})
    t.data["tutorial"] = True


def build_steps() -> List[Step]:
    return [
        Step("Select an aircraft",
             "Click TUT1.",
             lambda w: _did(w, "select", "TUT1") >= 1, highlight="TUT1", freeze=True, keys="Click  /  Tab"),
        Step("Read the label and the strip",
             "Label: callsign, level, speed, heading. Strip: XFL, exit gate, frequency. Select TUT2.",
             lambda w: _did(w, "select", "TUT2") >= 1, highlight="TUT2", freeze=True, keys="Click the aircraft or its strip  /  Tab"),
        Step("A conflict is coming",
             "TUT1 and TUT2 meet at MIDAS (amber line). Press RIGHT twice on TUT2 to try a heading.",
             lambda w: _did(w, "propose", "TUT2") >= 2, highlight="TUT2", freeze=True, keys="Left / Right = heading   Up / Down = level   + / - = speed"),
        Step("Send the instruction",
             "Turn until the trial line is green, then Enter. Small and early.",
             lambda w: any(c.callsign == "TUT2" and c.hdg is not None for c in w.clearances), highlight="TUT2",
             freeze=True, keys="Enter = send    Esc = cancel the trial", on_enter=_force_rb),
        Step("Check the read-back",
             "Compare read-back and clearance. Right: Y. Wrong: N.",
             lambda w: w.task_stats.get("readback", {}).get("correct", 0) + w.task_stats.get("readback", {}).get("wrong", 0) >= 1,
             keys="Y = correct   N = incorrect"),
        Step("Resume own navigation",
             "Wait until TUT1 has passed MIDAS, then select TUT2 and press R.",
             lambda w: any(c.callsign == "TUT2" and c.resume for c in w.clearances), highlight="TUT2", keys="R = resume own navigation",
             on_enter=_fast),
        Step("Send it to its exit level",
             "TUT3 must exit at FL280. Select it, Up twice, Enter.",
             lambda w: "TUT3" in w.aircraft and w.aircraft["TUT3"].tgt_alt >= 28000 or "TUT3" not in w.aircraft,
             highlight="TUT3", keys="Up / Down = level   Enter = send", on_enter=_normal),
        Step("Transfer of communication",
             "Select TUT4 (inside 20 NM of its gate). T, then its strip frequency key.",
             lambda w: w.aircraft.get("TUT4") is None and any(t.aircraft == "TUT4" and t.kind == "transfer" for t in w.tasks.log)
             or (w.aircraft.get("TUT4") is not None and w.aircraft["TUT4"].transferred),
             highlight="TUT4", on_enter=_tut4, keys="T = transfer, then 1 / 2 / 3"),
        Step("Interruptions",
             "Alert: press Space.",
             lambda w: w.task_stats.get("alert", {}).get("correct", 0) >= 1, on_enter=_alert, keys="Space = acknowledge"),
        Step("Level request",
             "Nobody is near TUT1. Approve: A.",
             lambda w: w.task_stats.get("levelreq", {}).get("correct", 0) + w.task_stats.get("levelreq", {}).get("wrong", 0) >= 1,
             on_enter=_levelreq, keys="A = approve   D = deny"),
        Step("You are ready",
             "P pause, F1 help. Enter to finish.",
             lambda w: _did(w, "finish") >= 1, keys="Enter = finish"),
    ]


class Tutorial:
    def __init__(self, world: World):
        self.world = world
        world.tutorial_mode = True
        self.steps = build_steps()
        self.index = 0
        self.done = False
        self.entered = -1
        self.update()

    @property
    def step(self) -> Optional[Step]:
        return None if self.done else self.steps[self.index]

    @property
    def freeze(self) -> bool:
        s = self.step
        return bool(s and s.freeze)

    def update(self) -> None:
        while not self.done:
            s = self.steps[self.index]
            if self.entered != self.index:
                self.entered = self.index
                if s.on_enter:
                    s.on_enter(self.world)
            if s.cond(self.world):
                self.index += 1
                if self.index >= len(self.steps):
                    self.done = True
            else:
                break
