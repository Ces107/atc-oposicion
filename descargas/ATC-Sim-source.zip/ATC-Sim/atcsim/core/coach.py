"""Optional closed loop with the progress dashboard: sim/atc_profile.json (written by the dashboard's "Export coach profile").
Expected shape: {"generated": str, "weakest": str, "suggestedSimLevel": 1-10, "abilities": {id: {"S": number, "confidence": str, "trend": str}}}.
Any missing, unreadable or malformed file is ignored: the sim never fails because of it."""
from __future__ import annotations

import json
import os
from typing import Any, Dict, Optional

PROFILE_NAME = "atc_profile.json"


def default_profile_path() -> str:
    from .paths import user_data_dir
    return os.path.join(user_data_dir(create=False), PROFILE_NAME)


def load_profile(path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Return {"message": str, "level": Optional[int]} or None. Never raises."""
    p = path or default_profile_path()
    try:
        if not os.path.isfile(p) or os.path.getsize(p) > 1_000_000:
            return None
        with open(p, "r", encoding="utf-8-sig") as f:
            raw = json.load(f)
        if not isinstance(raw, dict):
            return None
        level = raw.get("suggestedSimLevel")
        if isinstance(level, bool) or not isinstance(level, (int, float)) or level != level or not (1 <= level <= 10):
            level = None
        else:
            level = int(level)
        weakest = raw.get("weakest")
        weakest = " ".join(weakest.split())[:60] if isinstance(weakest, str) and weakest.strip() else None
        abil = raw.get("abilities")
        detail = ""
        if weakest and isinstance(abil, dict) and isinstance(abil.get(weakest), dict):
            s = abil[weakest].get("S")
            if isinstance(s, (int, float)) and not isinstance(s, bool) and s == s and abs(s) < 1e6:
                detail = f" (score {s:.0f})"
        parts = []
        if weakest:
            parts.append(f"weakest ability {weakest}{detail}")
        if level is not None:
            parts.append(f"suggested sim level {level}")
        if not parts:
            return None
        return {"message": "Coach: " + ", ".join(parts) + ".", "level": level}
    except (OSError, ValueError, TypeError, RecursionError, UnicodeError):
        return None
