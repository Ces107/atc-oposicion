"""Aircraft kinematics: heading, speed and altitude follow their targets with realistic rate limits.

Units: NM, degrees, knots (true airspeed; ground speed = TAS vector + wind vector), feet, seconds.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass, field
from typing import Optional, Tuple

from .geometry import (angle_diff, bearing, dist, heading_for_track, hdg_from_vec, norm360,
                       vec_from_hdg, wind_vector)
from .perf import AircraftType, TYPES, turn_rate

Waypoint = Tuple[str, float, float]  # name, x, y
CAPTURE_NM = 1.0


@dataclass(slots=True)
class Aircraft:
    callsign: str
    type_code: str
    x: float
    y: float
    alt: float
    hdg: float
    tas: float
    tgt_alt: float
    tgt_tas: float
    route: Tuple[Waypoint, ...] = ()
    route_idx: int = 0
    nav: bool = True                 # flying direct to route[route_idx]
    tgt_hdg: Optional[float] = None  # heading hold when nav is False
    turn_dir: Optional[str] = None   # 'L' or 'R': forced turn direction until the heading is reached
    exit_fix: str = ""
    exit_alt: float = 0.0
    entry_alt: float = 0.0
    spawn_time: float = 0.0
    freq_now: str = ""
    freq_next: str = ""
    transferred: bool = False
    flags: dict = field(default_factory=dict)

    # ---- derived values -------------------------------------------------------------------
    @property
    def ac_type(self) -> AircraftType:
        return TYPES[self.type_code]

    def velocity(self, wind: Tuple[float, float]) -> Tuple[float, float]:
        """Ground velocity in kt (x east, y north)."""
        vx, vy = vec_from_hdg(self.hdg, self.tas)
        return vx + wind[0], vy + wind[1]

    def ground_speed(self, wind: Tuple[float, float]) -> float:
        vx, vy = self.velocity(wind)
        return math.hypot(vx, vy)

    def track(self, wind: Tuple[float, float]) -> float:
        vx, vy = self.velocity(wind)
        return hdg_from_vec(vx, vy)

    def vertical_rate(self) -> float:
        """Current vertical rate in ft/s (positive = climbing)."""
        d = self.tgt_alt - self.alt
        if abs(d) < 1e-9:
            return 0.0
        t = self.ac_type
        return (t.climb_fpm if d > 0 else -t.descent_fpm) / 60.0

    @property
    def next_wp(self) -> Optional[Waypoint]:
        if self.nav and self.route_idx < len(self.route):
            return self.route[self.route_idx]
        return None

    def copy(self) -> "Aircraft":
        c = copy.copy(self)
        c.flags = dict(self.flags)
        return c

    # ---- commands (validated by World, applied here) -------------------------------------
    def set_heading(self, hdg: float, turn_dir: Optional[str] = None) -> None:
        self.nav = False
        self.tgt_hdg = norm360(hdg)
        self.turn_dir = turn_dir

    def set_altitude(self, alt: float) -> None:
        self.tgt_alt = float(alt)

    def set_speed(self, tas: float) -> None:
        t = self.ac_type
        self.tgt_tas = min(max(float(tas), t.v_min), t.v_max)

    def direct_to(self, wp_name: str) -> bool:
        for i, w in enumerate(self.route):
            if w[0] == wp_name and i >= 0:
                self.route_idx = i
                self.nav = True
                self.tgt_hdg = None
                self.turn_dir = None
                return True
        return False

    def resume_nav(self, wind: Tuple[float, float] = (0.0, 0.0)) -> None:
        """Resume own navigation: direct to the first route waypoint that is still ahead.

        A waypoint counts as passed when the aircraft lies beyond it along the following leg (positive dot product of
        the aircraft's offset from the waypoint with the leg direction), so an aircraft that was vectored past a
        waypoint is never sent back to it."""
        self.turn_dir = None
        idx = self.route_idx
        while idx + 1 < len(self.route):
            _, wx, wy = self.route[idx]
            _, nx, ny = self.route[idx + 1]
            if (self.x - wx) * (nx - wx) + (self.y - wy) * (ny - wy) > 0.0:
                idx += 1
            else:
                break
        self.route_idx = idx
        if idx >= len(self.route):
            self.nav = False
            self.tgt_hdg = self.hdg
            return
        self.nav = True
        self.tgt_hdg = None

    # ---- integration --------------------------------------------------------------------
    def desired_heading(self, wind_from: float, wind_speed: float) -> float:
        wp = self.next_wp
        if wp is not None:
            trk = bearing((self.x, self.y), (wp[1], wp[2]))
            r = heading_for_track(trk, self.tas, wind_from, wind_speed)
            return r[0] if r else trk
        return self.tgt_hdg if self.tgt_hdg is not None else self.hdg

    def step(self, dt: float, wind_from: float = 0.0, wind_speed: float = 0.0) -> None:
        t = self.ac_type
        # speed
        d = self.tgt_tas - self.tas
        m = t.accel * dt
        self.tas = self.tgt_tas if abs(d) <= m else self.tas + math.copysign(m, d)
        # altitude
        d = self.tgt_alt - self.alt
        rate = (t.climb_fpm if d > 0 else t.descent_fpm) / 60.0
        m = rate * dt
        self.alt = self.tgt_alt if abs(d) <= m else self.alt + math.copysign(m, d)
        # heading
        want = self.desired_heading(wind_from, wind_speed)
        diff = angle_diff(want, self.hdg)
        if self.turn_dir == "R" and diff < 0:
            diff += 360.0
        elif self.turn_dir == "L" and diff > 0:
            diff -= 360.0
        max_turn = turn_rate(self.tas) * dt
        if abs(diff) <= max_turn:
            step = diff
            self.turn_dir = None
        else:
            step = math.copysign(max_turn, diff)
        mid = self.hdg + step / 2.0
        self.hdg = norm360(self.hdg + step)
        # position, using the mid-step heading (exact chord direction for a constant-rate turn)
        vx, vy = vec_from_hdg(mid, self.tas)
        wx, wy = wind_vector(wind_from, wind_speed)
        self.x += (vx + wx) * dt / 3600.0
        self.y += (vy + wy) * dt / 3600.0
        # waypoint capture
        wp = self.next_wp
        if wp is not None:
            dd = dist((self.x, self.y), (wp[1], wp[2]))
            gs_step = math.hypot(vx + wx, vy + wy) * dt / 3600.0
            if dd < max(CAPTURE_NM, gs_step * 1.5):
                self.route_idx += 1
                if self.route_idx >= len(self.route):
                    self.nav = False
                    self.tgt_hdg = self.hdg
