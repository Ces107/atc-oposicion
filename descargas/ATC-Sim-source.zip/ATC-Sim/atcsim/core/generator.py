"""Deterministic scenario generator.

A scenario is built from designed conflict pairs (two routes that cross, meet head-on, or an overtake, timed so that
both aircraft reach the meeting point together) plus random filler traffic. Each candidate is then verified with a
"null run" (nobody gives any instruction) and accepted only if the number of loss-of-separation episodes is close to
the level's design target. The result is fully determined by (seed, level).
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .geometry import bearing, dist, heading_for_track, segment_intersection
from .perf import TYPES
from .scenario import AircraftSpec, LevelSpec, Scenario, level_spec, make_rng
from .sector import Sector, default_sector

PREFIX = ["BAW", "AFR", "IBE", "DLH", "RYR", "VLG", "EZY", "KLM", "TAP", "SAS", "AEE", "SWR", "THY", "UAE", "ITY"]
GATE_SPACING_S = 150.0   # minimum simulated seconds between two aircraft entering at the same gate


def time_along(sector: Sector, route: List[str], d: float, tas: float, wind_from: float, wind_speed: float) -> float:
    """Simulated seconds for an aircraft following `route` (fix names) to cover distance `d` NM from the start."""
    t = 0.0
    left = d
    for a, b in zip(route, route[1:]):
        pa, pb = sector.fixes[a], sector.fixes[b]
        L = dist(pa, pb)
        trk = bearing(pa, pb)
        r = heading_for_track(trk, tas, wind_from, wind_speed)
        gs = r[1] if r else tas
        seg = min(left, L)
        t += seg / gs * 3600.0
        left -= seg
        if left <= 1e-9:
            break
    return t


def _crossings(sector: Sector):
    """Every (routeA, dA, routeB, dB, kind): meeting points of two directional routes."""
    routes = sector.all_routes()
    out = []
    for i, (na, ra) in enumerate(routes):
        for j, (nb, rb) in enumerate(routes):
            if i >= j:
                continue
            base_a, base_b = na.rstrip("~"), nb.rstrip("~")
            if base_a == base_b:
                L = sector.route_length(ra)
                if na.endswith("~") != nb.endswith("~"):
                    for f in (0.35, 0.5, 0.65):
                        out.append((na, ra, f * L, nb, rb, (1 - f) * L, "head-on"))
                continue
            da = 0.0
            for a1, a2 in zip(ra, ra[1:]):
                pa1, pa2 = sector.fixes[a1], sector.fixes[a2]
                db = 0.0
                for b1, b2 in zip(rb, rb[1:]):
                    pb1, pb2 = sector.fixes[b1], sector.fixes[b2]
                    hit = segment_intersection(pa1, pa2, pb1, pb2)
                    if hit is not None:
                        u, v, _ = hit
                        out.append((na, ra, da + u * dist(pa1, pa2), nb, rb, db + v * dist(pb1, pb2), "crossing"))
                    db += dist(pb1, pb2)
                da += dist(pa1, pa2)
    # overtakes on the same directional route
    for n, r in routes:
        L = sector.route_length(r)
        for f in (0.4, 0.6):
            out.append((n, r, f * L, n, r, f * L, "overtake"))
    return out


def _pick_alt(rng, ceiling: int, lo: int = 24000, hi: int = 38000) -> int:
    hi = min(hi, ceiling - 1000)
    lo = min(lo, hi - 2000)
    return rng.randrange(lo // 1000, hi // 1000 + 1) * 1000


def _make_callsign(rng, used: set) -> str:
    for _ in range(100):
        cs = rng.choice(PREFIX) + str(rng.randrange(1, 9999))
        if rng.random() < 0.35:
            cs += rng.choice("ABCDEFGHKLMNPRSTVWXZ")
        if len(cs) <= 7 and cs not in used:
            used.add(cs)
            return cs
    raise RuntimeError("callsign generation failed")


def _tas_for(rng, code: str) -> float:
    t = TYPES[code]
    v = t.v_cruise + rng.randrange(-30, 25, 5)
    return float(min(max(v, t.v_min + 20), t.v_max - 20))


def _build_candidate(seed: int, sub: int, spec: LevelSpec, sector: Sector) -> Scenario:
    rng = make_rng(seed, f"scenario{sub}")
    routes = sector.all_routes()
    routes_by_name = {n: r for n, r in routes}
    crossings = _crossings(sector)
    wind_from = float(rng.randrange(0, 360, 10))
    wind_speed = float(spec.wind_kt)
    window = spec.window_s * spec.scale
    used: set = set()
    specs: List[AircraftSpec] = []
    gate_times: Dict[str, List[float]] = {}
    designed: List[Tuple[str, str]] = []

    def free_gate(gate: str, t: float) -> bool:
        return all(abs(t - x) >= GATE_SPACING_S for x in gate_times.get(gate, []))

    def add(route_name: str, t: float, alt: float, exit_alt: float, code: str, tas: float) -> AircraftSpec:
        r = routes_by_name[route_name]
        s = AircraftSpec(_make_callsign(rng, used), code, route_name, list(r), t, float(alt), float(exit_alt), tas)
        specs.append(s)
        gate_times.setdefault(r[0], []).append(t)
        return s

    def exit_alt_for(entry: int, code: str) -> int:
        if rng.random() < spec.level_change_share:
            d = rng.choice([-6000, -4000, -2000, 2000, 4000])
            e = entry + d
            ceil = TYPES[code].ceiling - 1000
            if e < 20000 or e > min(38000, ceil):
                e = entry - d
            if 20000 <= e <= min(38000, ceil):
                return e
        return entry

    n_pairs = min(spec.design_conflicts, spec.n_aircraft // 2)
    for _ in range(n_pairs):
        for attempt in range(25):
            na, ra, da, nb, rb, db, kind = rng.choice(crossings)
            if kind == "overtake":
                ca, cb = "AT72", rng.choice(["A320", "B738", "E190"])
            else:
                ca = rng.choice(list(TYPES))
                cb = rng.choice(list(TYPES))
            if rng.random() < 0.5:
                na, ra, da, nb, rb, db = nb, rb, db, na, ra, da
                ca, cb = cb, ca
            tas_a, tas_b = _tas_for(rng, ca), _tas_for(rng, cb)
            sa = rng.uniform(0.0, window * 0.75)
            ta = sa + time_along(sector, ra, da, tas_a, wind_from, wind_speed)
            off = rng.uniform(-22.0, 22.0)
            sb = ta + off - time_along(sector, rb, db, tas_b, wind_from, wind_speed)
            if sb < 0:
                sa -= sb
                sb = 0.0
            if not (free_gate(ra[0], sa) and free_gate(rb[0], sb)):
                continue
            if ra[0] == rb[0] and abs(sa - sb) < GATE_SPACING_S:
                continue
            ceil = min(TYPES[ca].ceiling, TYPES[cb].ceiling)
            alt_a = _pick_alt(rng, ceil)
            alt_b = alt_a + rng.choice([0, 0, 0, 500, -500])
            sp_a = add(na, sa, alt_a, exit_alt_for(alt_a, ca), ca, tas_a)
            sp_b = add(nb, sb, alt_b, exit_alt_for(alt_b, cb), cb, tas_b)
            designed.append((sp_a.callsign, sp_b.callsign))
            break

    while len(specs) < spec.n_aircraft:
        for attempt in range(40):
            name, r = rng.choice(routes)
            t = rng.uniform(0.0, window)
            if free_gate(r[0], t):
                code = rng.choice(list(TYPES))
                alt = _pick_alt(rng, TYPES[code].ceiling)
                add(name, t, alt, exit_alt_for(alt, code), code, _tas_for(rng, code))
                break
        else:
            break
    specs.sort(key=lambda s: s.spawn_time)
    if specs:
        shift = specs[0].spawn_time - 8.0    # the first aircraft is on the scope within a few seconds of the start
        if shift > 0:
            for s_ in specs:
                s_.spawn_time -= shift
    spawn_end = specs[-1].spawn_time if specs else 0.0
    sc = Scenario(seed, spec.level, specs, wind_from, wind_speed, spec.scale, spawn_end,
                  designed_pairs=designed, title=f"Level {spec.level} {spec.name}, seed {seed}")
    if spec.zone:
        sc.zone_from = 0.15 * window
        sc.zone_until = None
    return sc


def null_run_losses(scenario: Scenario, sector: Optional[Sector] = None) -> int:
    """Number of loss-of-separation episodes when nobody gives any instruction."""
    from .world import World
    w = World(scenario, sector, tasks=False, pilot_delay=0.0, record=False)
    w.predict_enabled = False
    step = 5.0
    while not w.finished:
        w.advance_sim(step)
    return len(w.losses)


def generate(seed: int, level: int, sector: Optional[Sector] = None, tries: int = 12) -> Scenario:
    sector = sector or default_sector()
    spec = level_spec(level)
    target = spec.design_conflicts
    lo = max(1, int(target * 0.7))
    hi = int(target * 1.6) + 1
    best: Optional[Scenario] = None
    best_gap = 10 ** 9
    for sub in range(tries):
        cand = _build_candidate(seed, sub, spec, sector)
        n = null_run_losses(cand, sector)
        cand.null_losses = n
        gap = 0 if lo <= n <= hi else min(abs(n - lo), abs(n - hi))
        if gap < best_gap:
            best, best_gap = cand, gap
        if gap == 0:
            break
    assert best is not None
    return best
