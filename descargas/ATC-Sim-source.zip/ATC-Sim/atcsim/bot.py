"""Scripted controller used for testing and calibration. It plays through the core API only.

It resolves predicted conflicts with the smallest heading change that leaves no new predicted conflict, sends
aircraft to their exit level when safe, resumes navigation afterwards, requests transfers in range and answers
tasks (using the ground truth of each task, with a configurable error/omission rate and reaction delay).
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

from .core.geometry import angle_diff, dist
from .core.tasks import KEYS
from .core.world import TRANSFER_RANGE, World


class Bot:
    def __init__(self, world: World, seed: int = 0, p_correct: float = 1.0, p_skip: float = 0.0,
                 reaction_s: float = 1.5, act_conflicts: bool = True, do_levels: bool = True,
                 do_transfer: bool = True, lead_s: float = 200.0, max_turn: int = 60):
        self.w = world
        self.rng = random.Random(seed)
        self.p_correct = p_correct
        self.p_skip = p_skip
        self.reaction = reaction_s
        self.act_conflicts = act_conflicts
        self.do_levels = do_levels
        self.do_transfer = do_transfer
        self.lead_s = lead_s
        self.max_turn = max_turn
        self._seen_task: Dict[int, float] = {}
        self._skip: set = set()
        self._handled_until: Dict[str, float] = {}
        self._level_done: set = set()
        self.commands = 0
        self.audio_rng = random.Random(seed + 7)      # own stream: the spoken task never shifts the other decisions
        self._audio_done: set = set()
        self.do_audio = True

    # ---- action hooks (the UI test bot overrides these to press real keys and click real buttons) ---
    def issue(self, cs: str, hdg=None, alt=None, spd=None, turn=None, resume=False, dct=None) -> bool:
        ok, _, _ = self.w.issue(cs, hdg=hdg, alt=alt, spd=spd, turn_dir=turn, dct=dct, resume=resume)
        return ok

    def transfer(self, cs: str) -> None:
        self.w.request_transfer(cs)

    def answer(self, task, choice: int) -> None:
        self.w.tasks.answer(task.id, choice)

    def audio_sum(self, value: int) -> None:
        self.w.audio.answer_sum(value)

    def audio_match(self) -> None:
        self.w.audio.press_match()

    def _handle_audio(self) -> None:
        """Spoken task: answer `reaction` seconds after the last token, with the same error and omission rates."""
        au = self.w.audio
        if au is None or not self.do_audio:
            return
        it = au.open_item
        if it is None or it.id in self._audio_done or au.t < it.end + self.reaction:
            return
        self._audio_done.add(it.id)
        if self.audio_rng.random() < self.p_skip:
            return
        ok = self.audio_rng.random() <= self.p_correct
        if it.kind == "sum":
            self.audio_sum(it.truth if ok else it.truth + self.audio_rng.choice([-2, -1, 1, 2]))
        elif it.truth or not ok:
            self.audio_match()

    # ---- conflict handling -----------------------------------------------------------
    def _best_turn(self, cs: str):
        ac = self.w.aircraft.get(cs)
        if ac is None:
            return None
        base = ac.tgt_hdg if (ac.tgt_hdg is not None and not ac.nav) else ac.hdg
        for mag in range(10, self.max_turn + 1, 10):
            for side, sign in (("R", 1), ("L", -1)):
                conf, zone = self.w.what_if(cs, hdg=base + sign * mag, turn_dir=side)
                zone_bad = zone is not None and self.w.scenario.zone_from is not None
                if not conf and not zone_bad:
                    return (base + sign * mag, side)
        return None

    def _handle_conflicts(self) -> None:
        w = self.w
        for c in list(w.predicted):
            if c.t_start > self.lead_s:
                continue
            key = f"{c.a}|{c.b}"
            if self._handled_until.get(key, -1) > w.t:
                continue
            if any(cl.callsign in c.pair and not cl.applied for cl in w.pending):
                continue
            # prefer the aircraft with the shorter remaining time in the sector (fewer knock-on effects): try both
            options = []
            for cs in (c.a, c.b):
                if cs not in w.aircraft:
                    continue
                bt = self._best_turn(cs)
                if bt is not None:
                    options.append((abs(angle_diff(bt[0], w.aircraft[cs].hdg)), cs, bt))
            if options:
                options.sort()
                _, cs, (hdg, side) = options[0]
                ok = self.issue(cs, hdg=hdg, turn=side)
                if ok:
                    self.commands += 1
                    self._handled_until[key] = w.t + 60.0
                    continue
            # fall back to a level change
            for cs in (c.a, c.b):
                ac = w.aircraft.get(cs)
                if ac is None:
                    continue
                for d in (2000, -2000, 4000, -4000):
                    new = ac.tgt_alt + d
                    if 10000 <= new <= ac.ac_type.ceiling and not w.what_if(cs, alt=new)[0]:
                        ok = self.issue(cs, alt=new)
                        if ok:
                            self.commands += 1
                            self._handled_until[key] = w.t + 60.0
                            break
                else:
                    continue
                break

    def _handle_zone(self) -> None:
        w = self.w
        for cs, (t0, t1) in list(w.zone_alerts.items()):
            if cs not in w.aircraft or t0 > 240 or self._handled_until.get("Z" + cs, -1) > w.t:
                continue
            bt = self._best_turn(cs)
            if bt:
                ok = self.issue(cs, hdg=bt[0], turn=bt[1])
                if ok:
                    self.commands += 1
                    self._handled_until["Z" + cs] = w.t + 60.0

    def _handle_resume_and_levels(self) -> None:
        w = self.w
        conflict_aircraft = {x for c in w.predicted for x in c.pair if c.t_start < 400}
        for cs, ac in list(w.aircraft.items()):
            if any(cl.callsign == cs and not cl.applied for cl in w.pending):
                continue
            if not ac.nav and ac.route_idx < len(ac.route) and cs not in conflict_aircraft:
                if self._handled_until.get("R" + cs, -1) < w.t:
                    conf, zone = self._what_if_resume(cs)
                    if not conf and zone is None:
                        ok = self.issue(cs, resume=True)
                        if ok:
                            self.commands += 1
                        self._handled_until["R" + cs] = w.t + 45.0
            if self.do_levels and abs(ac.tgt_alt - ac.exit_alt) > 1:
                if self._handled_until.get("L" + cs, -1) < w.t and w.t - ac.spawn_time > 20:
                    if not w.what_if(cs, alt=ac.exit_alt)[0]:
                        ok = self.issue(cs, alt=ac.exit_alt)
                        if ok:
                            self.commands += 1
                            self._level_done.add(cs)
                    self._handled_until["L" + cs] = w.t + 30.0

    def _what_if_resume(self, cs: str):
        w = self.w
        ac = w.aircraft[cs]
        c = ac.copy()
        c.resume_nav(w.wind_vec)
        from .core.predict import build_trajectory, predict_pair, zone_incursion
        tr = build_trajectory(c, w.wind_from, w.wind_speed)
        for o, ot in w.trajs.items():
            if o != cs and predict_pair(tr, ot, cs, o) is not None:
                return [1], None
        zone = None
        if w.spec.zone and w.scenario.zone_from is not None and w.sector.zones:
            z = w.sector.zones[0]
            zone = zone_incursion(tr, z.x, z.y, z.radius)
        return [], zone

    # ---- tasks ---------------------------------------------------------------------------
    def _handle_transfers(self) -> None:
        w = self.w
        if not self.do_transfer:
            return
        for cs, ac in list(w.aircraft.items()):
            if ac.transferred or ac.flags.get("tfr_done"):
                continue
            if dist((ac.x, ac.y), w.sector.fixes[ac.exit_fix]) <= TRANSFER_RANGE - 2 and not w.tasks.has_open(cs, "transfer"):
                self.transfer(cs)

    def _handle_tasks(self) -> None:
        w = self.w
        for t in list(w.tasks.tasks):
            if t.kind == "memshow" or not t.is_open:
                continue
            first = self._seen_task.setdefault(t.id, w.tasks.real_t)
            if t.id in self._skip:
                continue
            if w.tasks.real_t - first < self.reaction:
                continue
            if self.rng.random() < self.p_skip:
                self._skip.add(t.id)
                continue
            choice = t.correct
            if self.rng.random() > self.p_correct and len(t.options) > 1:
                choice = self.rng.choice([i for i in range(len(t.options)) if i != t.correct])
            self.answer(t, choice)

    def act(self) -> None:
        w = self.w
        if w.finished:
            return
        if self.act_conflicts:
            self._handle_conflicts()
            self._handle_zone()
        self._handle_resume_and_levels()
        self._handle_transfers()
        self._handle_tasks()
        self._handle_audio()


def play(world: World, bot: Optional[Bot], step_real: float = 0.5, max_real: float = 3000.0) -> World:
    while not world.finished and world.real_t < max_real:
        world.advance(step_real)
        if bot is not None:
            bot.act()
    return world
