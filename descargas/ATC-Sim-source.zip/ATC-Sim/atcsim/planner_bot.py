"""Scripted players for the strip planner (tests, calibration, the UI driver).

`perfect=True`: reads the truth (the world's conflict list and strip errors) once a strip has been on the board for
`reaction_s` real seconds, declares every conflict, solves it with the cheapest single action that creates nothing
new, and marks every wrong strip. It must score full marks; anything less is a game or generator bug.
`perfect=False`: a capacity-limited planner. It can examine `scan_per_s` strip pairs (and strips) per real second,
in the order a human would (earliest entries first), and overlooks an examined conflict with probability `p_slip`.
With more strips and a faster clock the queue grows, so the same player degrades as the level rises.
"""
from __future__ import annotations

import random
from typing import List, Optional, Set, Tuple

from .core.planner import Action, PlannerWorld, best_plan, pair_key


class PlannerBot:
    def __init__(self, world: PlannerWorld, perfect: bool = True, reaction_s: float = 1.5, scan_per_s: float = 2.0,
                 p_slip: float = 0.0, seed: int = 0, audio_p: float = 1.0):
        self.w = world
        self.perfect = perfect
        self.reaction_s = reaction_s
        self.scan_per_s = scan_per_s
        self.p_slip = p_slip
        self.rng = random.Random(seed)
        self.audio_p = audio_p
        self.examined: Set[Tuple[str, str]] = set()
        self.noticed: Set[Tuple[str, str]] = set()
        self.checked: Set[str] = set()
        self.queue: List[tuple] = []
        self._budget = 0.0
        self._last_real = world.real_t
        self._audio_done: Set[int] = set()

    # ---- what the player can see ------------------------------------------------------------------------------
    def _ready(self, *css: str) -> bool:
        w = self.w
        return all(cs in w.visible_real and w.real_t - w.visible_real[cs] >= self.reaction_s for cs in css)

    def _scan(self) -> None:
        """Capacity-limited reading of the board: new strips and pairs join a queue examined at a fixed rate."""
        w = self.w
        self._budget += (w.real_t - self._last_real) * self.scan_per_s
        self._last_real = w.real_t
        board = [cs for cs in w.on_board() if cs not in w.exited]
        known = {q[1] for q in self.queue if q[0] == "s"} | self.checked
        for cs in board:
            if cs not in known:
                self.queue.append(("s", cs))
        known_p = {q[1] for q in self.queue if q[0] == "p"} | self.examined
        for i, a in enumerate(board):
            for b in board[i + 1:]:
                p = pair_key(a, b)
                if p not in known_p:
                    self.queue.append(("p", p))
        while self._budget >= 1.0 and self.queue:
            kind, x = self.queue.pop(0)
            self._budget -= 1.0
            if kind == "s":
                self.checked.add(x)
            else:
                self.examined.add(x)
                if self.rng.random() >= self.p_slip:
                    self.noticed.add(x)

    # ---- actions (the UI driver overrides these three) --------------------------------------------------------
    def do_declare(self, a: str, b: str) -> None:
        self.w.declare(a, b)

    def do_flag(self, cs: str) -> None:
        self.w.flag(cs)

    def do_apply(self, act: Action) -> None:
        self.w.apply(act.cs, delay=act.delay, route_i=act.route_i, levels=list(act.levels))

    def do_audio_sum(self, value: int) -> None:
        self.w.audio.answer_sum(value)

    def do_audio_match(self) -> None:
        self.w.audio.press_match()

    # ---- one decision step ------------------------------------------------------------------------------------
    def act(self) -> None:
        w = self.w
        if w.finished:
            return
        if not self.perfect:
            self._scan()
        for cs in w.on_board():
            f = w.flights[cs]
            if f.err and cs not in w.flags and f.t_entry > w.t and self._ready(cs) and (self.perfect or cs in self.checked):
                self.do_flag(cs)
        for p, c in sorted(w.future_conflicts().items(), key=lambda kv: kv[1].t):
            if not self._ready(*p) or (not self.perfect and p not in self.noticed):
                continue
            if p not in w.declared:
                self.do_declare(*p)
            for act in best_plan(w.flights, p, w.t) or []:
                self.do_apply(act)
        self._audio()

    def _audio(self) -> None:
        au = self.w.audio
        if au is None:
            return
        it = au.open_item
        if it is None or it.id in self._audio_done or au.t < it.end + 0.6:
            return
        self._audio_done.add(it.id)
        if self.rng.random() > self.audio_p:
            return
        if it.kind == "sum":
            self.do_audio_sum(int(it.truth))
        elif it.truth:
            self.do_audio_match()


def run_core(level: int, seed: int, dt: float = 0.25, audio=None, bot_seed: int = 0, **kw):
    """Play a whole planner run in the core (no pygame). Returns (world, result)."""
    from .core.planner import PlannerWorld, compute_planner_result, generate_planner
    w = PlannerWorld(generate_planner(seed, level), audio=audio)
    bot = PlannerBot(w, seed=bot_seed, **kw)
    n = 0
    while not w.finished and n < 200000:
        w.advance(dt)
        bot.act()
        n += 1
    return w, compute_planner_result(w, "Ladder")
