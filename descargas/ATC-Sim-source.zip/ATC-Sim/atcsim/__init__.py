"""ATC Sim: radar sector simulator."""
__version__ = "1.0.0"
