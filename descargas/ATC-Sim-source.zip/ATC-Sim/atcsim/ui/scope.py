"""Radar scope renderer. Works from plain render records so the live game and the replay share one code path."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import pygame

from ..core.geometry import vec_from_hdg
from ..core.predict import Conflict
from ..core.sector import Sector
from . import theme as T


@dataclass
class RAc:
    cs: str
    x: float
    y: float
    alt: float
    hdg: float
    gs: float
    trk: float
    vs: int = 0                  # +1 climbing, -1 descending, 0 level
    tgt_alt: float = 0.0
    selected: bool = False
    state: str = "normal"        # normal | warn | alert | los
    tfr: bool = False            # transfer window open and not yet transferred
    assigned: str = ""           # extra label line for the selected aircraft
    wp: str = ""


@dataclass
class Overlay:
    aids: int = 3
    t: float = 0.0
    conflicts: Sequence[Conflict] = ()
    trajs: Optional[dict] = None
    trails: Optional[dict] = None
    los_pairs: Sequence[Tuple[str, str]] = ()
    zone_alerts: Optional[dict] = None
    zone_active: bool = False
    zone_scheduled: bool = False
    proposal: Optional[dict] = None     # {"cs", "hdg", "conflicts", "zone"}
    wind: Tuple[float, float] = (0.0, 0.0)
    highlight: str = ""
    blink: bool = False


class ScopeView:
    def __init__(self, rect: pygame.Rect, sector: Sector):
        self.rect = rect
        self.sector = sector
        x0, y0, x1, y1 = sector.bounds
        self.cx, self.cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        self.scale = min((rect.w - 24) / (x1 - x0), (rect.h - 24) / (y1 - y0))
        self.static = self._build_static()
        self.obstacles = self._static_obstacles()
        self.label_pref: Dict[str, int] = {}
        self.hit: List[Tuple[str, Tuple[int, int]]] = []
        self.fix_hit: List[Tuple[str, Tuple[int, int]]] = []

    # ---- transforms ----------------------------------------------------------------------
    def to_screen(self, x: float, y: float) -> Tuple[int, int]:
        return (int(self.rect.centerx + (x - self.cx) * self.scale), int(self.rect.centery - (y - self.cy) * self.scale))

    def to_world(self, px: int, py: int) -> Tuple[float, float]:
        return ((px - self.rect.centerx) / self.scale + self.cx, -(py - self.rect.centery) / self.scale + self.cy)

    # ---- static layer -------------------------------------------------------------------
    def _build_static(self) -> pygame.Surface:
        r = self.rect
        surf = pygame.Surface(r.size)
        surf.fill(T.SCOPE_BG)
        off = pygame.Rect(0, 0, r.w, r.h)

        def sp(x, y):
            px, py = self.to_screen(x, y)
            return (px - r.x, py - r.y)

        # range rings around the sector centre
        c = sp(self.cx, self.cy)
        x0_, y0_, x1_, y1_ = self.sector.bounds
        tl, br = sp(x0_, y1_), sp(x1_, y0_)
        surf.set_clip(pygame.Rect(tl[0], tl[1], br[0] - tl[0], br[1] - tl[1]))
        for nm in (20, 40, 60, 80):
            pygame.draw.circle(surf, T.RING, c, int(nm * self.scale), 1)
        surf.set_clip(None)
        # 10 NM grid ticks (faint dots)
        x0, y0, x1, y1 = self.sector.bounds
        for gx in range(int(x0), int(x1) + 1, 10):
            for gy in range(int(y0), int(y1) + 1, 10):
                px, py = sp(gx, gy)
                surf.set_at((px, py), T.FAINT)
        # airways
        for name, r_ in self.sector.routes.items():
            pts = [sp(*self.sector.fixes[n]) for n in r_]
            pygame.draw.lines(surf, T.AIRWAY, False, pts, 2)
        # boundary
        pts = [sp(*p) for p in self.sector.polygon]
        pygame.draw.lines(surf, (70, 120, 120), True, pts, 2)
        # fixes
        for n, (x, y) in self.sector.fixes.items():
            px, py = sp(x, y)
            gate = n in self.sector.boundary_fixes
            col = T.CYAN if gate else T.DIM
            pygame.draw.polygon(surf, col, [(px, py - 5), (px - 4, py + 3), (px + 4, py + 3)], 1)
            lab = T.text(n, 12, col, mono=True)
            dx, dy = self._fix_label_offset(n, x, y, lab.get_width())
            surf.blit(lab, (px + dx, py + dy))
        # north marker and scale bar
        T.blit_text(surf, "N", (12, 8), 14, T.DIM, mono=True)
        pygame.draw.line(surf, T.DIM, (12, 26), (12, 40), 1)
        bar = int(10 * self.scale)
        pygame.draw.line(surf, T.DIM, (14, r.h - 14), (14 + bar, r.h - 14), 2)
        T.blit_text(surf, "10 NM", (14 + bar + 6, r.h - 22), 12, T.DIM, mono=True)
        return surf

    def _fix_label_offset(self, n: str, x: float, y: float, lw: int):
        """Label offset from the fix symbol, in pixels (single source of truth for drawing and obstacle rectangles)."""
        if n in self.sector.boundary_fixes:
            if y >= 39:
                return (-lw // 2, 6)
            if y <= -39:
                return (-lw // 2, -20)
            if x <= -49:
                return (8, -6)
            return (-lw - 8, -6)
        return (6, -6)

    def _static_obstacles(self) -> List[pygame.Rect]:
        """Screen rectangles that dynamic labels should avoid: fix names, zone name, scale bar."""
        out: List[pygame.Rect] = []
        for n, (x, y) in self.sector.fixes.items():
            px, py = self.to_screen(x, y)
            surf = T.text(n, 12, T.DIM, mono=True)
            dx, dy = self._fix_label_offset(n, x, y, surf.get_width())
            out.append(pygame.Rect(px + dx, py + dy, surf.get_width(), surf.get_height()).inflate(2, 0))
            out.append(pygame.Rect(px - 5, py - 6, 11, 11))
        for z in self.sector.zones:
            c = self.to_screen(z.x, z.y)
            out.append(pygame.Rect(c[0] - 45, c[1] - 6, 90, 15))
        return out

    # ---- drawing ---------------------------------------------------------------------------
    def draw(self, dst: pygame.Surface, acs: Sequence[RAc], ov: Overlay) -> None:
        r = self.rect
        dst.blit(self.static, r.topleft)
        prev_clip = dst.get_clip()
        dst.set_clip(r)
        self.hit = []
        self.fix_hit = []
        self.label_rects: Dict[str, pygame.Rect] = {}       # where each label was drawn (used by tests)
        for n, (x, y) in self.sector.fixes.items():
            self.fix_hit.append((n, self.to_screen(x, y)))

        # restricted zone
        for z in self.sector.zones:
            c = self.to_screen(z.x, z.y)
            rad = int(z.radius * self.scale)
            if ov.zone_active:
                s = pygame.Surface((rad * 2 + 2, rad * 2 + 2), pygame.SRCALPHA)
                pygame.draw.circle(s, (200, 50, 50, 55), (rad + 1, rad + 1), rad)
                dst.blit(s, (c[0] - rad - 1, c[1] - rad - 1))
                pygame.draw.circle(dst, T.ZONE, c, rad, 2)
                T.blit_text(dst, f"{z.name} ACTIVE", (c[0], c[1] - 6), 12, T.RED, mono=True, anchor="midtop")
            elif ov.zone_scheduled:
                self._dashed_circle(dst, c, rad, T.FAINT)
                T.blit_text(dst, f"{z.name} (inactive)", (c[0], c[1] - 6), 12, T.FAINT, mono=True, anchor="midtop")

        by_cs = {a.cs: a for a in acs}
        pos = {a.cs: self.to_screen(a.x, a.y) for a in acs}

        # trails
        if ov.trails:
            for a in acs:
                tr = ov.trails.get(a.cs)
                if tr:
                    n = len(tr)
                    for i, (tx, ty) in enumerate(tr):
                        px, py = self.to_screen(tx, ty)
                        col = T.lerp(T.SCOPE_BG, T.DIM, (i + 1) / (n + 1))
                        pygame.draw.circle(dst, col, (px, py), 2)

        # velocity vectors (aid level 1+)
        if ov.aids >= 1:
            for a in acs:
                vx, vy = vec_from_hdg(a.trk, a.gs * 2.0 / 60.0)
                p0 = pos[a.cs]
                p1 = self.to_screen(a.x + vx, a.y + vy)
                col = T.DIM if a.state == "normal" else (T.AMBER if a.state == "warn" else T.RED)
                pygame.draw.line(dst, col, p0, p1, 1)

        # predicted conflicts (aid level 3): where each aircraft will be at the closest approach
        if ov.aids >= 3 and ov.trajs:
            for c in ov.conflicts:
                if c.t_start > 300:
                    continue
                ta, tb = ov.trajs.get(c.a), ov.trajs.get(c.b)
                if not ta or not tb or c.a not in pos or c.b not in pos:
                    continue
                k = min(int(round(c.t_cpa / ta.dt)), len(ta.xs) - 1)
                pa, pb = self.to_screen(ta.xs[k], ta.ys[k]), self.to_screen(tb.xs[k], tb.ys[k])
                col = T.RED if c.t_start < 120 else T.AMBER
                self._dashed_line(dst, pos[c.a], pa, col)
                self._dashed_line(dst, pos[c.b], pb, col)
                pygame.draw.line(dst, col, pa, pb, 1)
                for p in (pa, pb):
                    pygame.draw.line(dst, col, (p[0] - 4, p[1] - 4), (p[0] + 4, p[1] + 4), 1)
                    pygame.draw.line(dst, col, (p[0] - 4, p[1] + 4), (p[0] + 4, p[1] - 4), 1)
                mid = ((pa[0] + pb[0]) // 2, (pa[1] + pb[1]) // 2)
                T.blit_text(dst, f"{int(c.t_start) // 60}:{int(c.t_start) % 60:02d}", (mid[0] + 6, mid[1] - 6), 12, col, mono=True)

        # selected ring (5 NM)
        for a in acs:
            if a.selected and ov.aids >= 2:
                self._dashed_circle(dst, pos[a.cs], int(5 * self.scale), T.FAINT)

        # trial proposal
        if ov.proposal:
            p = ov.proposal
            a = by_cs.get(p["cs"])
            if a is not None:
                bad = bool(p.get("conflicts")) or bool(p.get("zone"))
                col = T.RED if bad else T.GREEN
                vx, vy = vec_from_hdg(p["hdg"], 30.0)
                self._dashed_line(dst, pos[a.cs], self.to_screen(a.x + vx, a.y + vy), col, 6, 4)
                if bad:
                    if p.get("conflicts"):
                        c0 = p["conflicts"][0]
                        other = c0.b if c0.a == a.cs else c0.a
                        txt = f"TRIAL: conflict with {other} in {int(c0.t_start) // 60}:{int(c0.t_start) % 60:02d}"
                    else:
                        txt = "TRIAL: enters restricted area"
                else:
                    txt = "TRIAL: clear"
                if ov.aids >= 2:
                    T.blit_text(dst, txt, (pos[a.cs][0] + 14, pos[a.cs][1] + 44), 12, col, mono=True)

        # loss of separation circles
        for pair in ov.los_pairs:
            for cs in pair:
                if cs in pos and ov.blink:
                    pygame.draw.circle(dst, T.RED, pos[cs], int(2.5 * self.scale), 2)

        # aircraft symbols and labels
        placed: List[pygame.Rect] = list(self.obstacles)
        for a in acs:
            p = pos[a.cs]
            col = {"normal": T.WHITE, "warn": T.AMBER, "alert": T.RED, "los": T.RED}[a.state]
            if a.selected:
                col = T.YELLOW
            rect = pygame.Rect(p[0] - 4, p[1] - 4, 9, 9)
            pygame.draw.rect(dst, col, rect, 1)
            pygame.draw.circle(dst, col, p, 1)
            if ov.highlight == a.cs:
                pygame.draw.circle(dst, T.CYAN, p, 22 + (3 if ov.blink else 0), 2)
            self.hit.append((a.cs, p))
            placed.append(rect.inflate(4, 4))
        # labels: the selected aircraft and the ones in trouble choose their spot first
        prio = {"los": 1, "alert": 1, "warn": 2, "normal": 3}
        for a in sorted(acs, key=lambda a: (0 if a.selected else prio.get(a.state, 3))):
            self._label(dst, a, pos[a.cs], placed, ov)

        # loss-of-separation banner
        if ov.los_pairs and ov.blink:
            T.blit_text(dst, "LOSS OF SEPARATION", (r.centerx, r.y + 8), 18, T.RED, bold=True, anchor="midtop")
        dst.set_clip(prev_clip)

    def _label(self, dst, a: RAc, p, placed, ov: Overlay) -> None:
        arrow = "^" if a.vs > 0 else ("v" if a.vs < 0 else "-")
        fl = int(round(a.alt / 100.0))
        l1 = a.cs
        l2 = f"{fl:03d}{arrow}{int(round(a.tgt_alt / 100.0)):03d}" if a.vs != 0 else f"{fl:03d} {arrow}"
        l3 = f"{int(round(a.gs)):03d} {(int(round(a.hdg)) or 360):03d}"
        lines = [l1, l2, l3]
        if a.selected and a.assigned:
            lines.append(a.assigned)
        col = {"normal": T.TEXT, "warn": T.AMBER, "alert": T.RED, "los": T.RED}[a.state]
        if a.selected:
            col = T.YELLOW
        surfs = [T.text(s, 13, col, mono=True) for s in lines]
        tfr = T.text("TFR", 11, T.GREEN, mono=True, bold=True) if a.tfr else None
        w = max(s.get_width() for s in surfs)
        if tfr is not None:
            w = max(w, surfs[0].get_width() + 6 + tfr.get_width())
        lh = surfs[0].get_height()
        h = lh * len(surfs)
        cands = [(12, -h - 4), (12, 6), (-w - 12, -h - 4), (-w - 12, 6),
                 (14, -h // 2), (-w - 14, -h // 2), (-w // 2, -h - 12), (-w // 2, 12),
                 (34, -h - 22), (34, 24), (-w - 34, -h - 22), (-w - 34, 24)]
        pref = self.label_pref.get(a.cs, 0)
        best, best_i, best_rect = None, pref, None
        for i, (dx, dy) in enumerate(cands):
            rc = pygame.Rect(p[0] + dx, p[1] + dy, w, h)
            cost = 0.0
            for o in placed:
                ov_ = rc.clip(o)
                if ov_.w > 0 and ov_.h > 0:
                    cost += ov_.w * ov_.h
            inside = rc.clip(self.rect)
            cost += 6.0 * (rc.w * rc.h - inside.w * inside.h)
            cost += 3.0 * (i if i < 4 else i + 2)                # near candidates first
            if i == pref:
                cost -= 40.0                                    # hysteresis: a label that fits stays where it is
            if best is None or cost < best:
                best, best_i, best_rect = cost, i, rc
        rect = best_rect
        self.label_pref[a.cs] = best_i
        self.label_rects[a.cs] = rect
        placed.append(rect.inflate(2, 1))
        # dark backing so that crossing airways, vectors and trails do not cut through the text
        back = pygame.Surface(rect.size, pygame.SRCALPHA)
        back.fill((7, 16, 14, 150))
        dst.blit(back, rect.topleft)
        y = rect.y
        for k, s_ in enumerate(surfs):
            dst.blit(s_, (rect.x, y))
            if k == 0 and tfr is not None:
                dst.blit(tfr, (rect.x + s_.get_width() + 6, y + 1))
            y += s_.get_height()
        # leader line to the nearest point of the label box
        lx = min(max(p[0], rect.x), rect.right)
        ly = min(max(p[1], rect.y), rect.bottom)
        if math.hypot(lx - p[0], ly - p[1]) > 8:
            pygame.draw.line(dst, T.FAINT if not a.selected else T.YELLOW, p, (lx, ly), 1)

    @staticmethod
    def _dashed_line(dst, a, b, col, dash: int = 4, gap: int = 4) -> None:
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(dx, dy)
        if L < 1:
            return
        ux, uy = dx / L, dy / L
        d = 0.0
        while d < L:
            e = min(d + dash, L)
            pygame.draw.line(dst, col, (a[0] + ux * d, a[1] + uy * d), (a[0] + ux * e, a[1] + uy * e), 1)
            d += dash + gap

    @staticmethod
    def _dashed_circle(dst, c, rad, col) -> None:
        if rad < 2:
            return
        n = max(24, int(rad * 0.6))
        for i in range(0, n, 2):
            a0 = 2 * math.pi * i / n
            a1 = 2 * math.pi * (i + 1) / n
            pygame.draw.line(dst, col, (c[0] + rad * math.cos(a0), c[1] + rad * math.sin(a0)),
                             (c[0] + rad * math.cos(a1), c[1] + rad * math.sin(a1)), 1)

    # ---- picking -------------------------------------------------------------------------
    def pick_aircraft(self, pos, radius: int = 14) -> Optional[str]:
        best, bd = None, radius * radius
        for cs, p in self.hit:
            d = (p[0] - pos[0]) ** 2 + (p[1] - pos[1]) ** 2
            if d <= bd:
                best, bd = cs, d
        return best

    def pick_fix(self, pos, radius: int = 12) -> Optional[str]:
        best, bd = None, radius * radius
        for n, p in self.fix_hit:
            d = (p[0] - pos[0]) ** 2 + (p[1] - pos[1]) ** 2
            if d <= bd:
                best, bd = n, d
        return best
