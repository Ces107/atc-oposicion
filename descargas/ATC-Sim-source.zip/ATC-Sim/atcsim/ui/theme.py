"""Colours, fonts and cached text rendering."""
from __future__ import annotations

from typing import Dict, List, Tuple

import pygame

W, H = 1440, 810

BG = (9, 14, 13)
SCOPE_BG = (7, 16, 14)
PANEL = (17, 24, 26)
PANEL2 = (24, 33, 36)
LINE = (52, 70, 72)
TEXT = (218, 228, 224)
DIM = (128, 148, 146)
FAINT = (104, 130, 130)
GREEN = (96, 214, 130)
AMBER = (245, 176, 52)
RED = (240, 84, 84)
CYAN = (132, 200, 176)
YELLOW = (250, 230, 90)
BLUE = (110, 150, 240)
WHITE = (245, 250, 248)
AIRWAY = (30, 62, 66)
RING = (22, 44, 44)
ZONE = (200, 60, 60)

_fonts: Dict[Tuple[str, int, bool], pygame.font.Font] = {}
_text_cache: Dict[Tuple, pygame.Surface] = {}

MONO_NAMES = "consolas,dejavusansmono,liberationmono,couriernew,menlo,monospace"
UI_NAMES = "segoeui,dejavusans,liberationsans,arial,helvetica"


def font(size: int, mono: bool = False, bold: bool = False) -> pygame.font.Font:
    key = ("m" if mono else "u", size, bold)
    f = _fonts.get(key)
    if f is None:
        f = pygame.font.SysFont(MONO_NAMES if mono else UI_NAMES, size, bold=bold)
        _fonts[key] = f
    return f


def text(s: str, size: int = 15, color=TEXT, mono: bool = False, bold: bool = False) -> pygame.Surface:
    key = (s, size, color, mono, bold)
    surf = _text_cache.get(key)
    if surf is None:
        if len(_text_cache) > 4000:
            _text_cache.clear()
        surf = font(size, mono, bold).render(s, True, color)
        _text_cache[key] = surf
    return surf


def blit_text(dst: pygame.Surface, s: str, pos, size: int = 15, color=TEXT, mono: bool = False, bold: bool = False,
              anchor: str = "topleft") -> pygame.Rect:
    surf = text(s, size, color, mono, bold)
    r = surf.get_rect()
    setattr(r, anchor, pos)
    dst.blit(surf, r)
    return r


def wrap(s: str, size: int, width: int, mono: bool = False, bold: bool = False) -> List[str]:
    f = font(size, mono, bold)
    out: List[str] = []
    for para in s.split("\n"):
        words = para.split(" ")
        cur = ""
        for wd in words:
            trial = wd if not cur else cur + " " + wd
            if f.size(trial)[0] <= width or not cur:
                cur = trial
            else:
                out.append(cur)
                cur = wd
        out.append(cur)
    return out


def lerp(a, b, t: float):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def fmt_time(t: float) -> str:
    t = max(0, int(t))
    return f"{t // 60:02d}:{t % 60:02d}"
