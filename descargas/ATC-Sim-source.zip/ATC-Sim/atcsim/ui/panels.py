"""Right-hand panels: flight strip bay, interrupting-task cards, message log, command box, top bar."""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import pygame

from ..core.geometry import dist
from ..core.tasks import KEYS, LABELS, Task
from ..core.world import TRANSFER_RANGE, World
from . import theme as T

Hit = List[Tuple[pygame.Rect, tuple]]

KEYCAP = {"space": "SPACE"}


def panel(dst, rect, title: str = "") -> None:
    pygame.draw.rect(dst, T.PANEL, rect)
    pygame.draw.rect(dst, T.LINE, rect, 1)
    if title:
        T.blit_text(dst, title, (rect.x + 8, rect.y + 4), 12, T.DIM, bold=True)


def strip_order(world: World) -> List[str]:
    def key(cs):
        a = world.aircraft[cs]
        fx = world.sector.fixes[a.exit_fix]
        gs = max(a.ground_speed(world.wind_vec), 1.0)
        return dist((a.x, a.y), fx) / gs
    return sorted(world.aircraft, key=key)


def draw_strips(dst, rect, world: World, selected: Optional[str], scroll: int, states: Dict[str, str], hits: Hit) -> int:
    panel(dst, rect, "STRIPS")
    n = len(world.aircraft)
    top = rect.y + 22
    avail = rect.h - 26 - 14
    row_h = 30 if n * 30 <= avail else max(20, avail // max(n, 1))
    cap = max(1, avail // row_h)
    order = strip_order(world)
    scroll = max(0, min(scroll, max(0, n - cap)))
    for lab, off in (("CALLSIGN", 10), ("TYPE", 86), ("LEVEL", 134), ("XFL", 200), ("EXIT", 266), ("FREQUENCY", 326)):
        T.blit_text(dst, lab, (rect.x + off, top), 11, T.FAINT, mono=True)
    top += 14
    for i, cs in enumerate(order[scroll:scroll + cap - 1 if n > cap else scroll + cap]):
        a = world.aircraft[cs]
        r = pygame.Rect(rect.x + 4, top + i * row_h, rect.w - 8, row_h - 2)
        st = states.get(cs, "normal")
        bg = T.PANEL2
        if cs == selected:
            bg = (52, 50, 22)
        pygame.draw.rect(dst, bg, r)
        edge = {"normal": T.LINE, "warn": T.AMBER, "alert": T.RED, "los": T.RED}[st]
        pygame.draw.rect(dst, edge, r, 1)
        lvl = f"{int(round(a.alt / 100)):03d}"
        xfl = int(round(a.exit_alt / 100))
        cur_t = int(round(a.tgt_alt / 100))
        lvl_txt = f"{lvl}>{cur_t:03d}" if abs(a.tgt_alt - a.alt) > 1 else lvl
        need = abs(a.tgt_alt - a.exit_alt) > 200
        col = T.YELLOW if cs == selected else T.TEXT
        ty = r.y + (row_h - 2 - 14) // 2
        T.blit_text(dst, cs, (r.x + 6, ty), 14, col, mono=True, bold=True)
        T.blit_text(dst, a.type_code, (r.x + 82, ty + 1), 12, T.DIM, mono=True)
        T.blit_text(dst, lvl_txt, (r.x + 130, ty), 13, T.TEXT, mono=True)
        xcol = T.AMBER if need else T.GREEN
        T.blit_text(dst, f"XFL{xfl:03d}", (r.x + 196, ty), 12, xcol, mono=True)
        T.blit_text(dst, a.exit_fix, (r.x + 262, ty), 13, T.CYAN, mono=True)
        fx = world.sector.fixes[a.exit_fix]
        in_range = dist((a.x, a.y), fx) <= TRANSFER_RANGE
        if a.transferred:
            T.blit_text(dst, a.freq_now, (r.x + 322, ty), 12, T.GREEN, mono=True)
            T.blit_text(dst, "OK", (r.right - 26, ty), 12, T.GREEN, mono=True, bold=True)
        else:
            T.blit_text(dst, a.freq_next, (r.x + 322, ty), 12, T.TEXT, mono=True)
            if in_range and not a.flags.get("tfr_done"):
                T.blit_text(dst, "TFR", (r.right - 34, ty), 12, T.GREEN, mono=True, bold=True)
        hits.append((r, ("select", cs)))
    if n > cap:
        T.blit_text(dst, f"{scroll + 1}-{min(n, scroll + cap - 1)} / {n}",
                    (rect.x + 8, rect.bottom - 16), 11, T.DIM)
    return scroll


def numeric_owner(tasks) -> Optional[Task]:
    """The open task that the number keys answer: the most urgent one among the tasks that use number keys."""
    cands = [t for t in tasks if t.is_open and t.kind not in ("readback", "alert", "levelreq", "memshow")
             and KEYS.get(t.kind, [""])[0].isdigit()]
    return min(cands, key=lambda t: t.time_left) if cands else None


def draw_tasks(dst, rect, world: World, hits: Hit, blink: bool) -> None:
    panel(dst, rect, "TASKS")
    tasks = [t for t in world.tasks.tasks]
    if not tasks:
        return
    y = rect.y + 22
    own = numeric_owner(tasks)                                       # the task the number keys currently answer
    owner = own.id if own is not None else None
    if own is not None:                                              # it is always shown first, as a full card
        tasks = [own] + [t for t in tasks if t is not own]
    for i, t in enumerate(tasks):
        h = _task_height(t, rect.w)
        rest = len(tasks) - i - 1
        if y + h + 20 * rest > rect.bottom - 2:
            # not enough room for the full card: this and every later task becomes a one-line row (still answerable by key)
            for t2 in tasks[i:]:
                _draw_task_line(dst, pygame.Rect(rect.x + 4, y, rect.w - 8, 18), t2)
                y += 20
            break
        _draw_task(dst, pygame.Rect(rect.x + 4, y, rect.w - 8, h), t, hits, blink,
                   keys_live=(t.kind in ("readback", "alert", "levelreq") or t.id == owner))
        y += h + 4


def _draw_task_line(dst, r: pygame.Rect, t: Task) -> None:
    frac = max(0.0, min(1.0, t.time_left / max(t.time_total, 0.1)))
    pygame.draw.rect(dst, T.PANEL2, r)
    pygame.draw.rect(dst, T.RED if frac < 0.3 else T.LINE, r, 1)
    ks = KEYS.get(t.kind, [])
    keys = "/".join(k.upper() if k != "space" else "SPACE" for k in ks) if not (ks and ks[0].isdigit()) else "next"
    T.blit_text(dst, f"{LABELS.get(t.kind, t.kind)}  {t.aircraft}  [{keys}]"[:52], (r.x + 6, r.y + 2), 12, T.AMBER)
    bar = pygame.Rect(r.right - 70, r.y + 5, 62, 8)
    pygame.draw.rect(dst, T.BG, bar)
    pygame.draw.rect(dst, T.lerp(T.RED, T.GREEN, frac), (bar.x, bar.y, int(bar.w * frac), bar.h))


def _task_height(t: Task, w: int) -> int:
    lines = T.wrap(t.prompt, 13, w - 24)
    opts = 0
    if t.options:
        opts = 26 if t.kind in ("readback", "alert", "levelreq") or len(t.options) <= 3 else 26 * 2
        if t.kind in ("ttc",):
            opts = 26 * 2
    return 22 + 16 * min(len(lines), 3) + opts + 8


def _draw_task(dst, r: pygame.Rect, t: Task, hits: Hit, blink: bool, keys_live: bool = True) -> None:
    frac = max(0.0, min(1.0, t.time_left / max(t.time_total, 0.1)))
    urgent = frac < 0.3
    bg = (44, 22, 22) if urgent else T.PANEL2
    pygame.draw.rect(dst, bg, r)
    pygame.draw.rect(dst, T.RED if urgent else T.LINE, r, 1)
    title = LABELS.get(t.kind, t.kind)
    T.blit_text(dst, title, (r.x + 8, r.y + 3), 12, T.AMBER if t.kind != "memshow" else T.CYAN, bold=True)
    bar = pygame.Rect(r.right - 110, r.y + 6, 100, 8)
    pygame.draw.rect(dst, T.BG, bar)
    col = T.lerp(T.RED, T.GREEN, frac)
    pygame.draw.rect(dst, col, (bar.x, bar.y, int(bar.w * frac), bar.h))
    lines = T.wrap(t.prompt, 13, r.w - 24)[:3]
    y = r.y + 20
    for ln in lines:
        T.blit_text(dst, ln, (r.x + 8, y), 13, T.TEXT)
        y += 16
    if not t.options:
        return
    keys = KEYS.get(t.kind, [])
    n = len(t.options)
    per_row = n if n <= 3 else 3
    bw = (r.w - 16 - (per_row - 1) * 6) // per_row
    for i, o in enumerate(t.options):
        row, col_i = divmod(i, per_row)
        b = pygame.Rect(r.x + 8 + col_i * (bw + 6), y + 4 + row * 26, bw, 22)
        pygame.draw.rect(dst, (34, 52, 56), b)
        pygame.draw.rect(dst, T.CYAN, b, 1)
        k = keys[i] if i < len(keys) else "?"
        cap = KEYCAP.get(k, k.upper())
        T.blit_text(dst, cap if keys_live else "click", (b.x + 5, b.y + 4), 12, T.YELLOW if keys_live else T.FAINT, mono=True, bold=True)
        if not keys_live:
            cap = "click"
        label = o
        maxw = b.w - 14 - 9 * len(cap)
        while T.font(12).size(label)[0] > maxw and len(label) > 3:
            label = label[:-2]
        T.blit_text(dst, label, (b.x + 12 + 9 * len(cap), b.y + 4), 12, T.TEXT)
        hits.append((b, ("answer", t.id, i)))


def draw_messages(dst, rect, world: World) -> None:
    panel(dst, rect, "MESSAGES")
    y = rect.y + 22
    cols = {"info": T.DIM, "cmd": T.TEXT, "alarm": T.RED}
    for (t, lvl, txt) in world.messages[-((rect.h - 26) // 16):]:
        T.blit_text(dst, f"{T.fmt_time(t)}  {txt}"[:70], (rect.x + 8, y), 12, cols.get(lvl, T.TEXT), mono=True)
        y += 16


def draw_command_box(dst, rect, world: World, selected: Optional[str], proposal: Optional[dict],
                     typing: Optional[Tuple[str, str]], flash: str, hits: Hit) -> None:
    panel(dst, rect, "")
    if not selected or selected not in world.aircraft:
        T.blit_text(dst, "Tab", (rect.x + 10, rect.y + 28), 15, T.DIM)
        if flash:
            T.blit_text(dst, flash, (rect.x + 10, rect.bottom - 22), 13, T.RED)
        return
    a = world.aircraft[selected]
    T.blit_text(dst, selected, (rect.x + 10, rect.y + 22), 20, T.YELLOW, bold=True)
    cur_h = a.tgt_hdg if (not a.nav and a.tgt_hdg is not None) else a.hdg
    nav = f"direct {a.next_wp[0]}" if a.next_wp else "no waypoint"
    hd = ("HDG %03d" % (round(cur_h) or 360)) if not a.nav else "own nav " + nav
    T.blit_text(dst, f"{hd}  FL{int(a.tgt_alt / 100):03d}  TAS {int(a.tgt_tas)}", (rect.x + 130, rect.y + 27), 12, T.DIM, mono=True)
    p = proposal or {}
    fields = [("HDG", f"{(int(round(p['hdg'])) or 360):03d}" if p.get("hdg") is not None else None),
              ("LEVEL", f"FL{int(p['alt'] / 100):03d}" if p.get("alt") is not None else None),
              ("TAS", f"{int(p['spd'])}" if p.get("spd") is not None else None)]
    x = rect.x + 10
    for name, txt in fields:
        b = pygame.Rect(x, rect.y + 52, 112, 40)
        act = txt is not None
        pygame.draw.rect(dst, (40, 58, 40) if act else T.PANEL2, b)
        pygame.draw.rect(dst, T.GREEN if act else T.LINE, b, 1)
        T.blit_text(dst, name, (b.x + 5, b.y + 3), 10, T.DIM)
        T.blit_text(dst, txt if act else "-", (b.x + 6, b.y + 17), 17, T.GREEN if act else T.FAINT, mono=True, bold=True)
        x += 118
    send = pygame.Rect(x, rect.y + 52, rect.right - x - 10, 40)
    can = bool(proposal)
    pygame.draw.rect(dst, (30, 90, 50) if can else T.PANEL2, send)
    pygame.draw.rect(dst, T.GREEN if can else T.LINE, send, 1)
    T.blit_text(dst, "SEND  Enter", send.center, 14, T.WHITE if can else T.FAINT, bold=True, anchor="center")
    if can:
        hits.append((send, ("send",)))
    if typing:
        T.blit_text(dst, f"{typing[0].upper()} {typing[1]}_", (rect.x + 10, rect.bottom - 30),
                    14, T.YELLOW, mono=True)
    elif flash:
        T.blit_text(dst, flash, (rect.x + 10, rect.bottom - 30), 13, T.RED)


def speaker(dst, x: int, y: int, col, waves: int = 0, k: int = 1) -> None:
    """Loudspeaker glyph (16k x 16k) with 0-2 sound arcs."""
    pygame.draw.rect(dst, col, (x, y + 5 * k, 4 * k, 6 * k))
    pygame.draw.polygon(dst, col, [(x + 4 * k, y + 5 * k), (x + 9 * k, y + k), (x + 9 * k, y + 15 * k), (x + 4 * k, y + 11 * k)])
    for i in range(waves):
        pygame.draw.arc(dst, col, (x + (5 - 3 * i) * k, y + (2 - 3 * i) * k, (10 + 6 * i) * k, (12 + 6 * i) * k), -0.9, 0.9, 2 * k)


def draw_audio(dst, rect, au, typed: Optional[str], blink: bool) -> None:
    """Spoken-task widget: speaker (cyan = speaking, amber = answer now), Σ or the target code, key cap, time bar."""
    pygame.draw.rect(dst, T.PANEL2, rect)
    pygame.draw.rect(dst, T.LINE, rect, 1)
    it = au.open_item
    speaking = au.speaking
    answering = it is not None and not speaking
    col = T.CYAN if speaking else (T.AMBER if answering else T.FAINT)
    speaker(dst, rect.x + 8, rect.y + 8, col, 2 if speaking else (1 if answering else 0))
    x = rect.x + 34
    cy = rect.y + 6
    if au.variant == "sum":
        T.blit_text(dst, "Σ", (x, rect.centery), 22, T.CYAN, bold=True, anchor="midleft")
        x += 24
    else:
        T.blit_text(dst, "=", (x, rect.centery), 22, T.CYAN, bold=True, anchor="midleft")
        x += 20
        tgt = " ".join(t.upper() for t in au.target) if au.show_target else "· · ·"
        r = T.blit_text(dst, tgt, (x, cy), 15, T.WHITE if au.show_target else T.FAINT, mono=True, bold=True)
        x = r.right + 12
    if typed is not None:
        T.blit_text(dst, f"V {typed}{'_' if blink else ' '}", (x, cy), 15, T.YELLOW, mono=True, bold=True)
    elif it is not None:
        cap = "V" if au.variant == "sum" else "M"
        b = pygame.Rect(x, cy - 1, 22, 20)
        pygame.draw.rect(dst, (34, 52, 56), b)
        pygame.draw.rect(dst, T.YELLOW if answering else T.CYAN, b, 1)
        T.blit_text(dst, cap, b.center, 13, T.YELLOW, mono=True, bold=True, anchor="center")
    if answering:
        frac = max(0.0, min(1.0, (it.deadline - au.t) / max(it.deadline - it.end, 0.1)))
        bar = pygame.Rect(rect.right - 74, rect.y + 12, 64, 8)
        pygame.draw.rect(dst, T.BG, bar)
        pygame.draw.rect(dst, T.lerp(T.RED, T.GREEN, frac), (bar.x, bar.y, int(bar.w * frac), bar.h))


def draw_topbar(dst, rect, world: World, label: str, paused: bool, losses: int, extra: str = "") -> None:
    pygame.draw.rect(dst, T.PANEL, rect)
    pygame.draw.line(dst, T.LINE, rect.bottomleft, rect.bottomright)
    T.blit_text(dst, label, (12, rect.y + 6), 17, T.WHITE, bold=True)
    x = 330
    T.blit_text(dst, f"SIM {T.fmt_time(world.t)}", (x, rect.y + 8), 14, T.TEXT, mono=True)
    T.blit_text(dst, f"x{world.scale:g}", (x + 110, rect.y + 8), 14, T.DIM, mono=True)
    T.blit_text(dst, f"WIND {int(round(world.wind_from)) or 360:03d}/{int(world.wind_speed)}", (x + 170, rect.y + 8), 14, T.CYAN, mono=True)
    T.blit_text(dst, f"IN SECTOR {len(world.aircraft)}", (x + 320, rect.y + 8), 14, T.TEXT, mono=True)
    lc = T.RED if losses else T.GREEN
    T.blit_text(dst, f"LOSSES {losses}", (x + 470, rect.y + 8), 14, lc, mono=True, bold=True)
    if world.zone_active:
        T.blit_text(dst, "R-31 ACTIVE", (x + 590, rect.y + 8), 14, T.RED, mono=True, bold=True)
    elif world.scenario.zone_from is not None and world.spec.zone:
        T.blit_text(dst, "R-31 pending", (x + 590, rect.y + 8), 14, T.FAINT, mono=True)
    if extra:
        T.blit_text(dst, extra, (rect.right - 12, rect.y + 8), 13, T.AMBER, anchor="topright")
    if paused:
        T.blit_text(dst, "PAUSED", (rect.right - 150, rect.y + 6), 18, T.AMBER, bold=True, anchor="topright")
