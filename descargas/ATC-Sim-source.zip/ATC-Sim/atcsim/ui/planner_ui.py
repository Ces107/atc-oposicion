"""Strip planner screens: briefing, the strip board with the route schematic, and the debrief. Spanish, little text."""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import pygame

from ..core.audio_task import NICE as A_NICE, AudioTask, code_text
from ..core.planner import (GATES, INNER, PARITY, POINTS, SEGMENTS, SEP_MIN, Flight, PlannerResult, PlannerWorld,
                            best_plan, fmt_t, planner_spec)
from ..core.scoring import endurance_text
from . import theme as T
from .panels import draw_audio
from .screens import MenuScreen, Screen, audio_decisions, audio_summary_lines, title

BAY = pygame.Rect(8, 44, 930, 760)
MAP = pygame.Rect(946, 44, 486, 470)
EDIT = pygame.Rect(946, 520, 486, 284)
TOP = pygame.Rect(0, 0, T.W, 38)
AUDIO_RECT = pygame.Rect(1046, 3, 388, 32)
ROW_H = 44
BOX_W, GAP_W, BOX_X = 84, 32, 118
MODE_ES = {"Adaptive": "adaptativo", "Ladder": "nivel"}
KIND_ES = {"punto": "punto", "alcance": "alcance", "frente": "frente"}

HELP = [
    ("SEPARACIÓN  (mismo nivel)", None),
    (f"punto común", f"{SEP_MIN:g}' o más entre las dos horas"),
    ("mismo tramo", "ni adelantar ni cruzarse de frente"),
    ("cambio de nivel", "sobre un punto: cuenta en los dos niveles"),
    ("SALIDA", None),
    ("punto de salida", "al XFL;  cada punto acepta niveles par o impar"),
    ("ERROR DE FICHA", None),
    ("hora de salida", "no cuadra con entrada + ruta / velocidad"),
    ("XFL", "no lo acepta el punto de salida"),
    ("TIEMPOS", None),
    ("tramos", "24 / 36 / 48 NM"),
    ("velocidad", "240 kt = 4 NM/min   360 = 6   480 = 8"),
    ("TECLAS", None),
    ("clic  Tab", "ficha"),
    ("C ... C", "conflicto (dos fichas);  clic dcho. = par con la elegida"),
    ("X", "ficha con error"),
    ("← →   ↑ ↓", "tramo y su nivel  (Mayús 2000 ft)"),
    ("+  −", "demora en la entrada (1')"),
    ("R", "ruta alternativa"),
    ("Enter  Esc", "aplicar  cancelar"),
    ("V cifras Enter   M", "tarea hablada"),
    ("P   F1", "pausa   ayuda"),
]


def _gap_x(i: int) -> int:
    """x offset (inside a strip) of the gap after route point i (the label of segment i)."""
    return BOX_X + i * (BOX_W + GAP_W) + BOX_W


def _box_x(i: int) -> int:
    return BOX_X + i * (BOX_W + GAP_W)


# ----------------------------------------------------------------------------------------------------------------
class PlannerBriefingScreen(Screen):
    def __init__(self, app, mode: str, level: int, seed: Optional[int] = None):
        self.app, self.mode, self.level = app, mode, max(1, min(10, int(level)))
        self.seed = seed if seed is not None else app.stats.next_seed()
        if mode == "Ladder":
            app.plan_level = self.level              # the menu's Plan row comes back on this level
        self.starting = False
        self._drawn = False
        self.help = False

    def on_key(self, key, mods, unicode):
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.starting = True
        elif key in (pygame.K_F1, pygame.K_h):
            self.help = not self.help
        elif key == pygame.K_ESCAPE:
            self.app.goto(MenuScreen(self.app, sel=6 if self.mode == "Adaptive" else 7))

    def on_click(self, pos, button):
        if button == 1:
            self.starting = True

    def update(self, dt):
        if self.starting and self._drawn:
            self.app.start_planner(self.mode, self.level, self.seed)

    def audio_line(self) -> str:
        a = self.app
        variant = a.audio_variant(self.mode, self.level, self.seed)
        lang = a.stats.settings()["voice"].upper()
        if variant is None:
            from ..core.audio_task import resolve_variant
            return f"Audio: sin sonido ({lang})" if resolve_variant(a.stats.settings()["audio"], self.level, self.seed) else ""
        if variant == "sum":
            return f"Audio Σ {lang}:  V + cifras + Enter"
        if not hasattr(self, "_target"):
            self._target = code_text(AudioTask("code", self.level, self.seed).target)
        return f"Audio = {lang}:  {self._target}  ->  M"

    def draw(self, dst):
        dst.fill(T.BG)
        sp = planner_spec(self.level)
        title(dst, f"Plan {MODE_ES.get(self.mode, self.mode)}  L{sp.level}  {sp.name}", f"seed {self.seed}")
        lines = [
            f"{sp.n_flights} fichas    1' = {sp.rs_per_min:g} s",
            f"Mismo nivel: {SEP_MIN:g}' sobre punto común",
            "Salida: su punto, al XFL",
            "Horas de paso en la ficha" if sp.show_etos else "Solo horas de entrada y salida",
            "Comprobación al aplicar" if sp.check_aid else "Sin comprobación",
        ]
        au = self.audio_line()
        if au:
            lines.append(au)
        lines.append(f"Objetivo: {int(sp.goal_accuracy * 100)} %, 0 pérdidas")
        y = 120
        for ln in lines:
            pygame.draw.line(dst, T.LINE, (40, y + 34), (660, y + 34))
            T.blit_text(dst, ln, (40, y + 6), 20, T.TEXT)
            y += 40
        if self.starting:
            T.blit_text(dst, "...", (40, y + 30), 26, T.AMBER, bold=True)
            self._drawn = True
        else:
            T.blit_text(dst, "Enter  Empezar", (40, y + 30), 22, T.GREEN, bold=True)
            T.blit_text(dst, "F1  Ayuda      Esc  Volver", (40, y + 62), 18, T.DIM)
        draw_schematic(dst, pygame.Rect(760, 100, 620, 600), None, None)
        if self.help:
            draw_help(dst, pygame.Rect(700, 90, 700, 640))


# ----------------------------------------------------------------------------------------------------------------
def _map_xy(rect: pygame.Rect, p: Tuple[float, float]) -> Tuple[int, int]:
    x0, x1, y0, y1 = -72.0, 60.0, -72.0, 60.0
    k = min((rect.w - 40) / (x1 - x0), (rect.h - 40) / (y1 - y0))
    cx = rect.x + 20 + (p[0] - x0) * k + ((rect.w - 40) - (x1 - x0) * k) / 2
    cy = rect.y + 20 + (y1 - p[1]) * k + ((rect.h - 40) - (y1 - y0) * k) / 2
    return int(cx), int(cy)


def _dashed(dst, col, a, b, width=2, dash=8) -> None:
    dx, dy = b[0] - a[0], b[1] - a[1]
    n = max(1, int((dx * dx + dy * dy) ** 0.5 // dash))
    for i in range(0, n, 2):
        p = (a[0] + dx * i / n, a[1] + dy * i / n)
        q = (a[0] + dx * min(n, i + 1) / n, a[1] + dy * min(n, i + 1) / n)
        pygame.draw.line(dst, col, p, q, width)


def draw_schematic(dst, rect: pygame.Rect, sel: Optional[Flight], pick: Optional[Flight],
                   pend_route: Optional[int] = None) -> None:
    """Route structure only (no aircraft): points, segments with their length, gate parity; the selected strip's
    route in yellow (its alternative dashed), the first strip of a conflict pair in blue."""
    pygame.draw.rect(dst, T.SCOPE_BG, rect)
    pygame.draw.rect(dst, T.LINE, rect, 1)
    for k, ln in SEGMENTS.items():
        a, b = tuple(k)
        pa, pb = _map_xy(rect, POINTS[a]), _map_xy(rect, POINTS[b])
        pygame.draw.line(dst, T.AIRWAY, pa, pb, 3)
        mx, my = (pa[0] + pb[0]) // 2, (pa[1] + pb[1]) // 2
        T.blit_text(dst, str(ln), (mx + 4, my + 2), 12, T.FAINT, mono=True)

    def route_line(f: Flight, ri: int, col, width: int, dashed: bool = False) -> None:
        r = f.routes[ri]
        for a, b in zip(r, r[1:]):
            pa, pb = _map_xy(rect, POINTS[a]), _map_xy(rect, POINTS[b])
            if dashed:
                _dashed(dst, col, pa, pb, 2)
            else:
                pygame.draw.line(dst, col, pa, pb, width)
    if pick is not None:
        route_line(pick, pick.route_i, T.BLUE, 5)
    if sel is not None:
        ri = sel.route_i if pend_route is None else pend_route
        if len(sel.routes) > 1:
            route_line(sel, 1 - ri, T.AMBER, 2, dashed=True)
        route_line(sel, ri, T.YELLOW, 4)
    for name, p in POINTS.items():
        x, y = _map_xy(rect, p)
        if name in GATES:
            pygame.draw.polygon(dst, T.CYAN, [(x, y - 8), (x - 7, y + 5), (x + 7, y + 5)])
            T.blit_text(dst, name, (x + 10, y - 16), 14, T.CYAN, mono=True, bold=True)
            T.blit_text(dst, PARITY[name], (x + 10, y + 1), 12, T.DIM, mono=True)
        else:
            pygame.draw.circle(dst, T.TEXT, (x, y), 6, 2)
            T.blit_text(dst, name, (x + 9, y - 18), 14, T.TEXT, mono=True, bold=True)


def draw_help(dst, rect: pygame.Rect) -> None:
    veil = pygame.Surface(rect.size, pygame.SRCALPHA)
    veil.fill((10, 18, 20, 238))
    dst.blit(veil, rect.topleft)
    pygame.draw.rect(dst, T.CYAN, rect, 2)
    y = rect.y + 12
    for a, b in HELP:
        if b is None:
            T.blit_text(dst, a, (rect.x + 16, y + 4), 15, T.CYAN, bold=True)
            y += 26
        else:
            T.blit_text(dst, a, (rect.x + 24, y + 10), 14, T.YELLOW, mono=True, anchor="midleft")
            T.blit_text(dst, b, (rect.x + 230, y + 10), 14, T.TEXT, anchor="midleft")
            y += 20


# ----------------------------------------------------------------------------------------------------------------
class PlannerScreen(Screen):
    """The strip board. The clock never stops except on pause (P)."""

    def __init__(self, app, world: PlannerWorld, mode: str, voice=None, lang: str = "es"):
        self.app, self.w, self.mode = app, world, mode
        self.voice, self.lang = voice, lang
        self.spec = world.spec
        self.sel: Optional[str] = None
        self.pick: Optional[str] = None
        self.seg = 0
        self.pend: Optional[dict] = None
        self.typing: Optional[str] = None
        self.paused = False
        self.pause_menu = False
        self.auto_paused = False
        self.abort_request = False
        self.help = False
        self.scroll = 0
        self.real = 0.0
        self.flash = ""
        self.flash_ttl = 0.0
        self.feedback: List[list] = []
        self._ev_seen = 0
        self._afb_seen = 0
        self._was_running = True
        self.rows: List[Tuple[pygame.Rect, str]] = []

    # ---- time ---------------------------------------------------------------------------------------------
    def update(self, dt):
        self.real += dt
        if self.flash_ttl > 0:
            self.flash_ttl -= dt
            if self.flash_ttl <= 0:
                self.flash = ""
        w = self.w
        if not self.paused:
            w.advance(dt)
        if w.audio is not None:
            cues = w.audio.pop_cues()
            if self.voice is not None:
                if (not self.paused) != self._was_running:
                    self.voice.pause(self.paused)
                if cues and not self.paused:
                    self.voice.play(self.lang, cues)
            self._was_running = not self.paused
        self._collect_feedback(dt)
        board = w.on_board()
        if self.sel is not None and (self.sel not in board or self.sel in w.exited):
            self.select(None)
        if self.pick is not None and (self.pick not in board or self.pick in w.exited):
            self.pick = None
        if self.abort_request:
            if self.voice is not None:
                self.voice.stop()
            self.app.goto(MenuScreen(self.app))
            return
        if w.finished:
            self.app.finish_planner(self)

    def _collect_feedback(self, dt) -> None:
        w = self.w
        while self._ev_seen < len(w.events):
            e = w.events[self._ev_seen]
            self._ev_seen += 1
            k, o, txt = e["kind"], e["outcome"], e["text"]
            if k == "det":
                self.feedback.append(["OK  conflicto " + txt if o == "correct" else "MAL  sin conflicto " + txt,
                                      T.GREEN if o == "correct" else T.RED, 1.8 if o == "correct" else 3.0])
            elif k == "coord":
                if o == "correct":
                    self.feedback.append([f"OK  ficha {txt}", T.GREEN, 1.8])
                elif o == "wrong":
                    self.feedback.append([f"MAL  ficha correcta {txt}", T.RED, 3.0])
                else:
                    self.feedback.append([f"PERDIDA  ficha {txt}", T.AMBER, 3.2])
            elif k == "sep":
                self.feedback.append([f"PÉRDIDA  {txt}", T.RED, 4.0])
            elif k == "exit":
                self.feedback.append([f"SALIDA MAL  {txt}", T.RED, 3.2])
        au = w.audio
        while au is not None and self._afb_seen < len(au.log):
            it = au.log[self._afb_seen]
            self._afb_seen += 1
            name = A_NICE.get(it.kind, it.kind)
            if it.outcome == "correct":
                self.feedback.append([f"OK  {name}", T.GREEN, 1.6])
            elif it.outcome == "wrong":
                self.feedback.append([f"MAL  {name}" + (f": {it.truth}" if it.kind == "sum" else ": no era"), T.RED, 3.2])
            elif it.outcome == "blank":
                self.feedback.append([f"PERDIDA  {name}" + (f": {it.truth}" if it.kind == "sum" else ": era el objetivo"),
                                      T.AMBER, 3.2])
        for f in self.feedback:
            f[2] -= dt
        self.feedback = [f for f in self.feedback if f[2] > 0][-3:]

    def flash_msg(self, s: str, ttl: float = 2.0) -> None:
        self.flash, self.flash_ttl = s, ttl

    def auto_pause(self) -> None:
        if not self.paused:
            self.paused = self.auto_paused = True

    # ---- selection and pending changes --------------------------------------------------------------------
    def select(self, cs: Optional[str]) -> None:
        if cs == self.sel:
            return
        self.sel = cs
        self.pend = None
        self.seg = 0
        if cs is not None:
            f = self.w.flights[cs]
            segs = self.w.editable(cs)["segments"]
            self.seg = next((i for i, ok in enumerate(segs) if ok), len(f.levels) - 1)

    def cycle(self, step: int) -> None:
        order = [cs for cs in self.w.on_board() if cs not in self.w.exited]
        if not order:
            return
        i = order.index(self.sel) if self.sel in order else (-1 if step > 0 else 0)
        self.select(order[(i + step) % len(order)])

    def _pending(self) -> Optional[dict]:
        if self.sel is None:
            self.flash_msg("Elige una ficha")
            return None
        if self.pend is None:
            f = self.w.flights[self.sel]
            self.pend = {"delay": f.delay, "route_i": f.route_i, "levels": list(f.levels)}
        return self.pend

    def _route_len(self) -> int:
        f = self.w.flights[self.sel]
        ri = self.pend["route_i"] if self.pend else f.route_i
        return len(f.routes[ri]) - 1

    def change_level(self, delta: int) -> None:
        p = self._pending()
        if p is None:
            return
        i = max(0, min(self.seg, len(p["levels"]) - 1))
        p["levels"][i] = max(240, min(400, p["levels"][i] + delta))

    def change_delay(self, delta: float) -> None:
        p = self._pending()
        if p is None:
            return
        if not self.w.editable(self.sel)["delay"]:
            self.flash_msg("tarde")
            return
        p["delay"] = max(0.0, min(30.0, p["delay"] + delta))

    def toggle_route(self) -> None:
        p = self._pending()
        if p is None:
            return
        f = self.w.flights[self.sel]
        if len(f.routes) < 2:
            self.flash_msg("sin alternativa")
            return
        if not self.w.editable(self.sel)["route"]:
            self.flash_msg("tarde")
            return
        last = p["levels"][-1]
        p["route_i"] = 1 - p["route_i"]
        n = len(f.routes[p["route_i"]]) - 1
        p["levels"] = (list(f.levels) if p["route_i"] == f.route_i else [f.rfl] * (n - 1) + [last])
        self.seg = min(self.seg, n - 1)

    def commit(self) -> None:
        if self.sel is None or self.pend is None:
            return
        p = self.pend
        ok, msg, eff = self.w.apply(self.sel, delay=p["delay"], route_i=p["route_i"], levels=p["levels"])
        if ok:
            self.pend = None
            if self.spec.check_aid:
                if eff.get("created"):
                    self.feedback.append(["CREA CONFLICTO", T.RED, 2.6])
                elif eff.get("removed"):
                    self.feedback.append(["RESUELTO", T.GREEN, 1.8])
                else:
                    self.feedback.append(["SIN EFECTO", T.DIM, 1.6])
        else:
            self.flash_msg(msg or "-")

    def declare_key(self) -> None:
        if self.sel is None:
            self.flash_msg("Elige una ficha")
            return
        if self.pick is None:
            self.pick = self.sel
            return
        if self.pick == self.sel:
            self.pick = None
            return
        out, msg = self.w.declare(self.pick, self.sel)
        if out is None:
            self.flash_msg(msg or "-")
        self.pick = None

    # ---- input ----------------------------------------------------------------------------------------------
    def on_key(self, key, mods, unicode):
        w = self.w
        if self.pause_menu:
            if key in (pygame.K_ESCAPE, pygame.K_p, pygame.K_RETURN):
                self.pause_menu = self.paused = False
            elif key == pygame.K_q:
                self.abort_request = True
            return
        if self.typing is not None:
            if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                buf, self.typing = self.typing, None
                if buf and w.audio is not None and w.audio.answer_sum(int(buf)) is None:
                    self.flash_msg("V: -", 1.2)
            elif key == pygame.K_ESCAPE:
                self.typing = None
            elif key == pygame.K_BACKSPACE:
                self.typing = self.typing[:-1]
            elif len(unicode) == 1 and unicode in "0123456789" and len(self.typing) < 3:
                self.typing += unicode
            return
        if key == pygame.K_p:
            if self.paused and self.auto_paused:
                self.paused = self.auto_paused = False
                return
            self.paused = not self.paused
            if self.paused:
                w.pauses += 1
            return
        if self.paused:
            if key == pygame.K_ESCAPE:
                self.paused = self.auto_paused = False
            elif key == pygame.K_q:
                self.abort_request = True
            return
        shift = bool(mods & pygame.KMOD_SHIFT)
        if key in (pygame.K_F1, pygame.K_h):
            self.help = not self.help
        elif key == pygame.K_TAB:
            self.cycle(-1 if shift else 1)
        elif key == pygame.K_ESCAPE:
            if self.pend is not None:
                self.pend = None
            elif self.pick is not None:
                self.pick = None
            elif self.sel is not None:
                self.select(None)
            else:
                self.paused = self.pause_menu = True
                w.pauses += 1
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.commit()
        elif key == pygame.K_UP:
            self.change_level(20 if shift else 10)
        elif key == pygame.K_DOWN:
            self.change_level(-20 if shift else -10)
        elif key in (pygame.K_LEFT, pygame.K_RIGHT):
            if self.sel is not None:
                self.seg = max(0, min(self._route_len() - 1, self.seg + (1 if key == pygame.K_RIGHT else -1)))
        elif key in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self.change_delay(1.0)
        elif key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.change_delay(-1.0)
        elif key == pygame.K_r:
            self.toggle_route()
        elif key == pygame.K_c:
            self.declare_key()
        elif key == pygame.K_x:
            if self.sel is None:
                self.flash_msg("Elige una ficha")
            else:
                out, msg = w.flag(self.sel)
                if out is None:
                    self.flash_msg(msg or "-")
        elif key == pygame.K_v and w.audio is not None and w.audio.variant == "sum":
            self.typing = ""
        elif key == pygame.K_m and w.audio is not None and w.audio.variant == "code":
            if w.audio.press_match() is None:
                self.flash_msg("M: -", 1.2)

    def on_click(self, pos, button):
        if self.paused:
            if self.auto_paused and not self.pause_menu:
                self.paused = self.auto_paused = False
            return
        for r, cs in self.rows:
            if r.collidepoint(pos):
                if button == 3:
                    if self.sel is not None and self.sel != cs:
                        out, msg = self.w.declare(self.sel, cs)
                        if out is None:
                            self.flash_msg(msg or "-")
                    return
                if cs == self.sel:
                    rel = pos[0] - r.x                       # a click on a segment label picks that segment
                    for i in range(self._route_len()):
                        if _gap_x(i) - 6 <= rel <= _gap_x(i) + GAP_W + 6:
                            self.seg = i
                    return
                self.select(cs)
                return

    def on_wheel(self, pos, dy):
        if BAY.collidepoint(pos):
            self.scroll = max(0, self.scroll - dy)

    # ---- drawing ----------------------------------------------------------------------------------------------
    def draw(self, dst):
        w = self.w
        dst.fill(T.BG)
        self._draw_top(dst)
        self._draw_bay(dst)
        sel = w.flights.get(self.sel) if self.sel else None
        pick = w.flights.get(self.pick) if self.pick else None
        if self.help:
            draw_help(dst, pygame.Rect(MAP.x, MAP.y, MAP.w, EDIT.bottom - MAP.y))
        else:
            draw_schematic(dst, MAP, sel, pick, self.pend["route_i"] if self.pend else None)
            self._draw_edit(dst)
        fy = BAY.y + 40
        for text_, col_, _ in self.feedback:
            surf = T.text(text_, 18, col_, bold=True)
            bg = pygame.Surface((surf.get_width() + 20, surf.get_height() + 6), pygame.SRCALPHA)
            bg.fill((7, 16, 14, 225))
            r_ = bg.get_rect(midtop=(BAY.centerx, fy))
            dst.blit(bg, r_)
            dst.blit(surf, (r_.x + 10, r_.y + 3))
            fy += r_.h + 4
        if self.paused:
            self._draw_pause(dst)

    def _draw_top(self, dst) -> None:
        w = self.w
        pygame.draw.rect(dst, T.PANEL, TOP)
        pygame.draw.line(dst, T.LINE, TOP.bottomleft, TOP.bottomright)
        T.blit_text(dst, f"PLAN  L{self.spec.level}  {self.spec.name}", (12, 6), 17, T.WHITE, bold=True)
        T.blit_text(dst, fmt_t(w.t), (330, 3), 26, T.YELLOW, mono=True, bold=True)
        T.blit_text(dst, f"1'={self.spec.rs_per_min:g}s", (440, 11), 13, T.DIM, mono=True)
        lost = len(w.happened)
        T.blit_text(dst, f"PÉRDIDAS {lost}", (540, 9), 15, T.RED if lost else T.GREEN, mono=True, bold=True)
        T.blit_text(dst, f"C {len(w.declared)}", (720, 9), 15, T.BLUE, mono=True, bold=True)
        T.blit_text(dst, f"X {sum(1 for v in w.flags.values() if v['outcome'] == 'correct')}", (790, 9), 15, T.AMBER,
                    mono=True, bold=True)
        if self.paused:
            T.blit_text(dst, "PAUSA", (1030, 6), 18, T.AMBER, bold=True, anchor="topright")
        if w.audio is not None and not self.paused:
            draw_audio(dst, AUDIO_RECT, w.audio, self.typing, int(self.real * 2.5) % 2 == 0)

    def _draw_bay(self, dst) -> None:
        w = self.w
        pygame.draw.rect(dst, T.PANEL, BAY)
        pygame.draw.rect(dst, T.LINE, BAY, 1)
        board = w.on_board()
        cap = max(1, (BAY.h - 8) // ROW_H)
        self.scroll = max(0, min(self.scroll, max(0, len(board) - cap)))
        self.rows = []
        y = BAY.y + 4
        for cs in board[self.scroll:self.scroll + cap]:
            r = pygame.Rect(BAY.x + 4, y, BAY.w - 8, ROW_H - 4)
            self._draw_strip(dst, r, w.flights[cs])
            self.rows.append((r, cs))
            y += ROW_H
        if len(board) > cap:
            T.blit_text(dst, f"{self.scroll + 1}-{min(len(board), self.scroll + cap)} / {len(board)}",
                        (BAY.right - 8, BAY.bottom - 18), 12, T.DIM, anchor="topright")
        if not board:
            T.blit_text(dst, "· · ·", BAY.center, 28, T.FAINT, anchor="center")

    def _draw_strip(self, dst, r: pygame.Rect, f: Flight) -> None:
        w = self.w
        cs = f.cs
        selected = cs == self.sel
        gone = cs in w.exited
        bg = (52, 50, 22) if selected else T.PANEL2
        pygame.draw.rect(dst, bg, r)
        edge = T.BLUE if cs == self.pick else (T.YELLOW if selected else T.LINE)
        pygame.draw.rect(dst, edge, r, 2 if (selected or cs == self.pick) else 1)
        state_col = T.FAINT if gone else (T.CYAN if cs in w.entered else T.LINE)
        pygame.draw.rect(dst, state_col, (r.x, r.y, 5, r.h))
        txt = T.FAINT if gone else T.TEXT
        T.blit_text(dst, cs, (r.x + 12, r.y + 3), 15, T.YELLOW if selected else (T.FAINT if gone else T.WHITE),
                    mono=True, bold=True)
        T.blit_text(dst, f"{f.type_code} {f.speed}", (r.x + 12, r.y + 22), 12, T.DIM, mono=True)
        p = self.pend if selected else None
        ri = p["route_i"] if p else f.route_i
        route = f.routes[ri]
        delay = p["delay"] if p else f.delay
        levels = p["levels"] if p else f.levels
        if ri == f.route_i and p is None:
            times = f.times()
        else:
            tmp = Flight(f.cs, f.type_code, f.speed, f.entry_t, f.routes, f.rfl, f.xfl, f.shown_xfl,
                         delay=delay, route_i=ri, levels=list(levels))
            times = tmp.times()
        last = len(route) - 1
        for i, name in enumerate(route):
            bx = r.x + _box_x(i)
            box = pygame.Rect(bx, r.y + 3, BOX_W, r.h - 6)
            pygame.draw.rect(dst, T.PANEL, box)
            gate = i in (0, last)
            T.blit_text(dst, name, (bx + 6, r.y + 4), 13, (T.CYAN if gate else txt) if not gone else T.FAINT, mono=True,
                        bold=gate)
            if i == 0:
                tt, col = fmt_t(times[0]), (T.AMBER if delay > 0 else txt)
            elif i == last:
                shown = times[-1] + (0.0 if f.flagged else f.time_err)
                tt, col = fmt_t(shown), txt
            elif self.spec.show_etos:
                tt, col = fmt_t(times[i]), T.DIM
            else:
                tt, col = "", txt
            if tt:
                T.blit_text(dst, tt, (bx + 6, r.y + 21), 14, col, mono=True, bold=(i in (0, last)))
        for i in range(last):
            gx = r.x + _gap_x(i)
            lv = levels[i]
            changed = lv != f.levels[i] if (p and ri == f.route_i) else (lv != f.rfl)
            if selected or changed:
                col = T.AMBER if changed else T.DIM
                lab = pygame.Rect(gx + 1, r.y + 12, GAP_W - 2, 16)
                if selected and i == self.seg:
                    pygame.draw.rect(dst, (34, 52, 56), lab)
                    pygame.draw.rect(dst, T.YELLOW, lab, 1)
                    col = T.YELLOW if not changed else T.AMBER
                T.blit_text(dst, str(lv), lab.center, 12, col, mono=True, bold=True, anchor="center")
            else:
                pygame.draw.line(dst, T.LINE, (gx + 4, r.y + r.h // 2), (gx + GAP_W - 4, r.y + r.h // 2), 1)
        x = r.x + _box_x(5) + 6
        T.blit_text(dst, "RFL", (x, r.y + 4), 10, T.FAINT, mono=True)
        T.blit_text(dst, str(f.rfl), (x, r.y + 19), 15, txt, mono=True, bold=True)
        T.blit_text(dst, "XFL", (x + 50, r.y + 4), 10, T.FAINT, mono=True)
        T.blit_text(dst, str(f.shown_xfl), (x + 50, r.y + 19), 15, T.GREEN if f.flagged else txt, mono=True, bold=True)
        x += 104
        if delay > 0:
            T.blit_text(dst, f"+{delay:g}'", (x, r.y + 4), 13, T.AMBER, mono=True, bold=True)
        if ri == 1:
            T.blit_text(dst, "ALT", (x, r.y + 21), 13, T.AMBER, mono=True, bold=True)
        fl = w.flags.get(cs)
        if fl:
            T.blit_text(dst, "X", (r.right - 16, r.y + 4), 15, T.GREEN if fl["outcome"] == "correct" else T.RED,
                        mono=True, bold=True)
        nd = sum(1 for pr in w.declared if cs in pr)
        if nd:
            T.blit_text(dst, f"C{nd if nd > 1 else ''}", (r.right - 34, r.y + 21), 13, T.BLUE, mono=True, bold=True)

    def _draw_edit(self, dst) -> None:
        w = self.w
        r = EDIT
        pygame.draw.rect(dst, T.PANEL, r)
        pygame.draw.rect(dst, T.LINE, r, 1)
        if self.sel is None:
            rows = [("clic  Tab", "ficha"), ("C ... C", "conflicto"), ("X", "ficha con error"), ("F1", "ayuda")]
            y = r.y + 20
            for a, b in rows:
                T.blit_text(dst, a, (r.x + 20, y), 16, T.YELLOW, mono=True, bold=True)
                T.blit_text(dst, b, (r.x + 170, y), 16, T.DIM)
                y += 30
            if self.flash:
                T.blit_text(dst, self.flash, (r.x + 20, r.bottom - 30), 15, T.RED)
            return
        f = w.flights[self.sel]
        ed = w.editable(self.sel)
        p = self.pend
        T.blit_text(dst, f.cs, (r.x + 14, r.y + 10), 22, T.YELLOW, mono=True, bold=True)
        T.blit_text(dst, f"{f.type_code}  {f.speed} kt  {f.nm_min:g} NM/min", (r.x + 150, r.y + 16), 14, T.DIM, mono=True)
        if self.pick:
            T.blit_text(dst, f"C  {self.pick} + ?", (r.right - 14, r.y + 16), 14, T.BLUE, mono=True, bold=True,
                        anchor="topright")
        ri = p["route_i"] if p else f.route_i
        route = f.routes[ri]
        levels = p["levels"] if p else f.levels
        y = r.y + 50
        for i in range(len(route) - 1):
            seg = f"{route[i]}-{route[i + 1]}"
            on = i == self.seg
            open_ = ri != f.route_i or (i < len(ed["segments"]) and ed["segments"][i])
            col = T.YELLOW if on else (T.TEXT if open_ else T.FAINT)
            if on:
                pygame.draw.rect(dst, (34, 52, 56), (r.x + 8, y - 3, r.w - 16, 24))
            T.blit_text(dst, seg, (r.x + 16, y), 15, col, mono=True, bold=on)
            lv = levels[i]
            T.blit_text(dst, str(lv), (r.x + 250, y), 15, T.AMBER if lv != f.rfl else col, mono=True, bold=True)
            if i == len(route) - 2:
                T.blit_text(dst, f"XFL {f.shown_xfl}", (r.x + 320, y), 13, T.GREEN if lv == f.shown_xfl else T.RED, mono=True)
            y += 26
        y += 4
        d = p["delay"] if p else f.delay
        T.blit_text(dst, f"+{d:g}'" if d else "+0'", (r.x + 16, y), 15, T.AMBER if d else (T.TEXT if ed["delay"] else T.FAINT),
                    mono=True, bold=True)
        T.blit_text(dst, f"entrada {f.entry}", (r.x + 80, y + 1), 13, T.DIM)
        if len(f.routes) > 1:
            T.blit_text(dst, "ALT" if ri == 1 else "R", (r.x + 250, y), 15,
                        T.AMBER if ri == 1 else (T.TEXT if ed["route"] else T.FAINT), mono=True, bold=True)
        y += 34
        keys = "↑↓ ←→   + −   R   Enter   Esc"
        T.blit_text(dst, keys, (r.x + 16, r.bottom - 52), 15, T.YELLOW if p else T.DIM, mono=True)
        T.blit_text(dst, "C par   X ficha   F1", (r.x + 16, r.bottom - 28), 14, T.DIM, mono=True)
        if self.flash:
            T.blit_text(dst, self.flash, (r.right - 16, r.bottom - 28), 15, T.RED, anchor="topright")

    def _draw_pause(self, dst) -> None:
        veil = pygame.Surface((T.W, T.H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 170))
        dst.blit(veil, (0, 0))
        r = pygame.Rect(0, 0, 300, 140)
        r.center = BAY.center
        pygame.draw.rect(dst, T.PANEL, r)
        pygame.draw.rect(dst, T.AMBER, r, 2)
        T.blit_text(dst, "PAUSA", (r.centerx, r.y + 14), 30, T.AMBER, bold=True, anchor="midtop")
        lines = ["P    seguir", "Q    abandonar"]
        if self.spec.level >= 5 and not self.auto_paused:
            lines.append("L5+: asistida")
        y = r.y + 60
        for ln in lines:
            T.blit_text(dst, ln, (r.x + 24, y), 16, T.TEXT, mono=True)
            y += 24


# ----------------------------------------------------------------------------------------------------------------
class PlannerDebriefScreen(Screen):
    TABS = ["Resumen", "Conflictos", "Fichas"]

    def __init__(self, app, world: PlannerWorld, result: PlannerResult, mode: str):
        self.app, self.w, self.r, self.mode = app, world, result, mode
        self.tab = 0
        self.scroll = 0
        self.msg = ""
        self.tab_rects: List[pygame.Rect] = []
        self._conf_lines: Optional[List[Tuple[str, tuple, int]]] = None

    def _record(self) -> Optional[dict]:
        r = self.r
        for x in reversed(self.app.stats.data.get("planner_runs", [])):
            if x["seed"] == r.seed and x["level"] == r.level and x["mode"] == r.mode:
                return x
        return None

    def _advice(self) -> str:
        r = self.r
        if r.assisted:
            return "Pausa en L5+: asistida, no cuenta para el adaptativo."
        if r.met:
            return "Objetivo cumplido. Repite el nivel antes de subir: precisión primero."
        if r.lost:
            return "Repite la misma semilla (R) y evita cada pérdida: pestaña Conflictos."
        wc = r.worst_component()
        if wc:
            return f"Lo más flojo: {wc[0]} ({wc[1]:.0f} %). Repite el nivel y cuida eso."
        return "Repite el nivel."

    def _conflict_lines(self, width: int) -> List[Tuple[str, tuple, int]]:
        if self._conf_lines is not None:
            return self._conf_lines
        w = self.w
        L: List[Tuple[str, tuple, int]] = []
        pairs = sorted(set(w.designed) | set(w.happened), key=lambda p: (w.designed.get(p) or w.happened[p]["conflict"]).t)
        orig = {f.cs: f for f in w.sc.flights}
        for p in pairs:
            c = w.designed.get(p) or w.happened[p]["conflict"]
            h = w.happened.get(p)
            d = w.declared.get(p)
            created = p not in w.designed
            if h:
                head, col = "PÉRDIDA" + (" (creada)" if created else ""), T.RED
            elif d:
                head, col = "OK", T.GREEN
            else:
                head, col = "RESUELTO SIN DECLARAR", T.AMBER
            L.append((f"{head}   {p[0]} / {p[1]}   {KIND_ES[c.kind]} {c.where}  FL{c.level}  {fmt_t(c.t)}", col, 16))
            det = (f"declarado a las {fmt_t(d['t'])} ({d['latency']:.0f} s)" if d else "sin declarar")
            L.append(("      " + det, T.TEXT, 14))
            acts = [e for e in w.edits if e["cs"] in p]
            for e in acts:
                f = w.flights[e["cs"]]
                fr, to = e["from"], e["to"]
                bits = []
                if to[0] != fr[0]:
                    bits.append(f"demora +{to[0]:g}'")
                if to[1] != fr[1]:
                    bits.append("ruta " + "-".join(f.routes[to[1]][1:-1]))
                if to[2] != fr[2]:
                    bits.append("niveles " + " ".join(str(v) for v in to[2]))
                L.append((f"      {fmt_t(e['t'])}  {e['cs']}: " + ", ".join(bits), T.DIM, 14))
            if (h or not d) and not created:
                tmp = {cs: Flight(**{k: getattr(g, k) for k in ("cs", "type_code", "speed", "entry_t", "routes", "rfl", "xfl",
                                                                  "shown_xfl", "err", "time_err")}, levels=list(g.levels))
                       for cs, g in orig.items()}
                now = max(orig[p[0]].entry_t, orig[p[1]].entry_t) - w.spec.lead_min + 1.0
                plan = best_plan(tmp, p, now)
                if plan:
                    L.append(("      mejor: " + ";  ".join(a.text(tmp[a.cs]) for a in plan), T.CYAN, 14))
            L.append(("", T.TEXT, 6))
        for fa in w.false_alarms:
            L.append((f"FALSA ALARMA   {fa['pair'][0]} / {fa['pair'][1]}   {fmt_t(fa['t'])}", T.RED, 16))
        if not L:
            L.append(("Sin conflictos", T.GREEN, 18))
        self._conf_lines = L
        return L

    def build(self, width: int) -> List[Tuple[str, tuple, int]]:
        r = self.r
        w = self.w
        L: List[Tuple[str, tuple, int]] = []
        if self.tab == 0:
            L.append((f"Puntuación {r.score:.0f} / 100", T.WHITE, 30))
            L.append((("OBJETIVO CUMPLIDO" if r.met else "OBJETIVO NO CUMPLIDO") + f"   ({int(w.spec.goal_accuracy * 100)} %, 0 pérdidas)",
                      T.GREEN if r.met else T.RED, 18))
            spd = f"{r.s_per_decision:.1f} s por decisión" if r.s_per_decision is not None else "sin decisiones"
            L.append((f"Ítems {r.correct} bien, {r.wrong} mal, {r.blank} en blanco  -  precisión {r.accuracy:.1f} %  -  {spd}  -  "
                      f"{r.flights} fichas", T.TEXT, 15))
            L.append(("", T.TEXT, 8))
            L.append((self._advice(), T.AMBER, 16))
            if self.mode == "Adaptive":
                ad = self.app.stats.data.get("planner_adaptive", {"level": r.level, "ok": 0, "bad": 0})
                L.append((f"Adaptativo: siguiente L{ad['level']} ({ad['ok']} limpias, {ad['bad']} fallidas seguidas).", T.CYAN, 15))
            L.append(("", T.TEXT, 8))
            L.append((f"Conflictos {r.conflicts}:  detectados {r.found}   sin detectar {r.missed}   falsas alarmas {r.false_alarms}", T.TEXT, 15))
            L.append((f"Pérdidas {r.lost}" + (f"  (creadas {r.created})" if r.created else ""), T.RED if r.lost else T.GREEN, 15))
            L.append((f"Fichas con error {r.coord_errors}:  marcadas {r.coord_flagged}   marcadas sin error {r.coord_false}", T.TEXT, 15))
            if r.exits_checked:
                L.append((f"Salidas al XFL {r.exits_ok} / {r.exits_checked}", T.GREEN if r.exits_ok == r.exits_checked else T.RED, 15))
            L.append((f"Coste de resolución {r.cost_units:g}  (mínimo {r.ref_cost:g}):  demora {r.delay_min:g}'  ruta {r.reroutes} (+{r.reroute_min:g}')  "
                      f"tramos con otro nivel {r.level_changes}", T.TEXT, 15))
            L.append(("", T.TEXT, 8))
            L.append(("Componentes", T.CYAN, 17))
            comps = sorted(r.components.items(), key=lambda kv: (r.component_accuracy(kv[0]) or 0))
            for name, c in comps:
                n = c["correct"] + c["wrong"] + c["blank"]
                acc = 100.0 * c["correct"] / n if n else 0
                bar = "#" * int(acc / 5) + "." * (20 - int(acc / 5))
                L.append((f"{name:<14} [{bar}] {acc:5.1f}%   ({c['correct']}/{c['wrong']}/{c['blank']})",
                          T.RED if acc < 70 else (T.AMBER if acc < 90 else T.GREEN), 14))
            L.append(("", T.TEXT, 8))
            L.append((endurance_text(r.thirds_data), T.TEXT, 14))
            rec = self._record()
            for txt, col in audio_summary_lines(rec.get("audio") if rec else r.audio):
                L.append((txt, col, 15 if col is T.WHITE else 14))
            L.append(("", T.TEXT, 8))
            L.append(("Descuentos", T.CYAN, 17))
            if not r.breakdown:
                L.append(("Ninguno.", T.GREEN, 14))
            for txt, v in r.breakdown:
                L.append((f"{v:+6.1f}   {txt}", T.TEXT, 14))
        elif self.tab == 1:
            L = list(self._conflict_lines(width))
            for out, head, detail in audio_decisions(w):
                L.append((("EN BLANCO  " if out == "blank" else "MAL  ") + head + "   " + detail,
                          T.AMBER if out == "blank" else T.RED, 14))
        else:
            any_ = False
            for cs in w.order:
                f = w.flights[cs]
                fl = w.flags.get(cs)
                if not f.err and not fl:
                    continue
                any_ = True
                if f.err == "T":
                    what = f"hora de salida {fmt_t(f.t_exit + f.time_err)} (era {fmt_t(f.t_exit)})"
                elif f.err == "L":
                    what = f"XFL {f.rfl} en {f.exit} ({PARITY[f.exit]}: {f.xfl})"
                else:
                    what = "sin error"
                if f.err and fl and fl["outcome"] == "correct":
                    L.append((f"OK         {cs:<8} {what}   marcada {fmt_t(fl['t'])}", T.GREEN, 15))
                elif f.err:
                    L.append((f"PERDIDA    {cs:<8} {what}", T.AMBER, 15))
                else:
                    L.append((f"MAL        {cs:<8} marcada sin error", T.RED, 15))
            exits = [cs for cs in sorted(w.touched_levels)]
            if exits:
                L.append(("", T.TEXT, 8))
                L.append(("Salidas", T.CYAN, 17))
                for cs in exits:
                    f = w.flights[cs]
                    ok = f.exit_ok()
                    L.append((f"{'OK ' if ok else 'MAL'}  {cs:<8} {f.exit} a {f.levels[-1]}  (XFL {f.xfl})", T.GREEN if ok else T.RED, 15))
            if not any_ and not exits:
                L.append(("Ninguna", T.DIM, 18))
        return L

    def draw(self, dst):
        dst.fill(T.BG)
        title(dst, "Plan: resultado", f"{MODE_ES.get(self.mode, self.mode)}  L{self.r.level}  seed {self.r.seed}")
        x = 40
        self.tab_rects = []
        counts = [None, len(set(self.w.designed) | set(self.w.happened)) + len(self.w.false_alarms),
                  sum(1 for f in self.w.flights.values() if f.err) + sum(1 for v in self.w.flags.values() if v["outcome"] == "wrong")]
        for i, name in enumerate(self.TABS):
            label = name + (f" ({counts[i]})" if counts[i] is not None else "")
            r = pygame.Rect(x, 88, 200, 32)
            pygame.draw.rect(dst, (30, 52, 46) if i == self.tab else T.PANEL2, r)
            pygame.draw.rect(dst, T.GREEN if i == self.tab else T.LINE, r, 1)
            T.blit_text(dst, f"{i + 1}  {label}", r.center, 15, T.WHITE if i == self.tab else T.DIM, anchor="center")
            self.tab_rects.append(r)
            x += 208
        area = pygame.Rect(40, 134, T.W - 80, T.H - 190)
        lines = self.build(area.w)
        total = sum(sz + 6 for (_, _, sz) in lines)
        self.scroll = max(0, min(self.scroll, max(0, total - area.h)))
        dst.set_clip(area)
        y = area.y - self.scroll
        for s, col, sz in lines:
            h = sz + 6
            if y + h >= area.y and y <= area.bottom:
                T.blit_text(dst, s, (area.x, y), sz, col, mono=(self.tab == 0 and "[" in s) or self.tab == 2)
            y += h
        dst.set_clip(None)
        foot = "1-3 pestañas    N siguiente    R repetir    " + ("A audio solo    " if self.r.audio else "") + "E exportar    Esc menú"
        T.blit_text(dst, foot, (40, T.H - 46), 14, T.DIM)
        if self.msg:
            T.blit_text(dst, self.msg, (40, T.H - 26), 13, T.AMBER)

    def on_wheel(self, pos, dy):
        self.scroll = max(0, self.scroll - dy * 40)

    def on_click(self, pos, button):
        for i, r in enumerate(self.tab_rects):
            if r.collidepoint(pos):
                self.tab, self.scroll = i, 0

    def on_key(self, key, mods, unicode):
        a = self.app
        n = len(self.TABS)
        if key in (pygame.K_1, pygame.K_2, pygame.K_3):
            self.tab, self.scroll = key - pygame.K_1, 0
        elif key == pygame.K_RIGHT:
            self.tab, self.scroll = (self.tab + 1) % n, 0
        elif key == pygame.K_LEFT:
            self.tab, self.scroll = (self.tab - 1) % n, 0
        elif key == pygame.K_DOWN:
            self.scroll += 40
        elif key == pygame.K_UP:
            self.scroll = max(0, self.scroll - 40)
        elif key == pygame.K_PAGEDOWN:
            self.scroll += 300
        elif key == pygame.K_PAGEUP:
            self.scroll = max(0, self.scroll - 300)
        elif key == pygame.K_a and self.r.audio:
            a.start_audio_solo(self)
        elif key == pygame.K_r:
            a.goto(PlannerBriefingScreen(a, self.mode, self.r.level, seed=self.r.seed))
        elif key == pygame.K_n:
            lvl = a.stats.data["planner_adaptive"]["level"] if self.mode == "Adaptive" else self.r.level
            a.goto(PlannerBriefingScreen(a, self.mode, lvl))
        elif key == pygame.K_e:
            path = a.export_csv()
            self.msg = path if path else a.stats.warning
        elif key == pygame.K_ESCAPE:
            a.goto(MenuScreen(a, sel=6 if self.mode == "Adaptive" else 7))
