"""Application shell: window, main loop, screen transitions, run lifecycle and persistence hooks."""
from __future__ import annotations

import os
import sys
import time
from typing import Optional

import pygame

from ..core.audio_task import AudioTask, resolve_variant
from ..core.paths import resource_dir, user_data_dir
from ..core.generator import generate
from ..core.coach import load_profile
from ..core.persistence import StatsStore
from ..core.scenario import level_spec
from ..core.scoring import RADAR_ONLY, adaptive_update, compute_result
from ..core.tutorial import Tutorial, tutorial_scenario
from ..core.world import World
from . import theme as T
from .screens import AudioSoloScreen, BriefingScreen, DebriefScreen, MenuScreen, Screen
from .session import GameSession
from .sound import Voice, durations


def _dpi_aware() -> None:
    """Windows: opt in to per-monitor DPI so the window is not blurred by the OS and desktop sizes are real pixels."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except (AttributeError, OSError):
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


class GameScreen(Screen):
    def __init__(self, app: "App", session: GameSession):
        self.app = app
        self.s = session

    def update(self, dt):
        s = self.s
        s.update(dt)
        if s.abort_request:
            self.app.goto(MenuScreen(self.app))
            return
        if s.tut is not None and s.tut.done:
            self.app.finish_tutorial(s)
            return
        if s.world.finished:
            self.app.finish_run(s)

    def draw(self, dst):
        self.s.draw(dst)

    def on_key(self, key, mods, unicode):
        s = self.s
        if s.tut is not None and key == pygame.K_ESCAPE and s.typing is None and not s.proposal and not s.world.selected and not s.paused:
            self.app.finish_tutorial(s, skipped=True)
            return
        s.on_key(key, mods, unicode)

    def on_click(self, pos, button):
        self.s.on_click(pos, button, bool(pygame.key.get_mods() & pygame.KMOD_SHIFT))

    def on_wheel(self, pos, dy):
        self.s.on_wheel(pos, dy)


class App:
    def __init__(self, headless: bool = False, stats_path: Optional[str] = None, profile_path: Optional[str] = None):
        self.headless = headless
        if headless:
            os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
            os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        if not headless:
            _dpi_aware()
        pygame.init()
        pygame.display.set_caption("ATC Sim")
        try:
            pygame.display.set_icon(pygame.image.load(os.path.join(resource_dir(), "assets", "icon.png")))
        except (pygame.error, FileNotFoundError, OSError):
            pass
        # fit mode: on a desktop too small for the 1440x810 design (for example a 1366x768 laptop) pygame.SCALED would
        # open a window larger than the screen. Then draw on an off-screen surface and scale it into a resizable window.
        self.fit = False
        self._view = (0, 0, 1.0)
        self.window = None
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0] if not headless else (99999, 99999)
        except (pygame.error, IndexError):
            dw, dh = 99999, 99999
        forced = os.environ.get("SIM_DESKTOP", "")          # testing hook, for example SIM_DESKTOP=1366x768
        if "x" in forced:
            try:
                dw, dh = (int(v) for v in forced.split("x", 1))
            except ValueError:
                pass
        if dw < T.W + 40 or dh < T.H + 120:
            k = min((dw - 40) / T.W, (dh - 120) / T.H)
            self.window = pygame.display.set_mode((max(640, int(T.W * k)), max(360, int(T.H * k))), pygame.RESIZABLE)
            self.surface = pygame.Surface((T.W, T.H))
            self.fit = True
        else:
            try:
                self.surface = pygame.display.set_mode((T.W, T.H), pygame.SCALED | pygame.RESIZABLE)
            except pygame.error:
                self.surface = pygame.display.set_mode((T.W, T.H))
        self.clock = pygame.time.Clock()
        self.stats = StatsStore(stats_path)
        # optional coach profile from the dashboard (ignored when missing or malformed)
        self.coach = load_profile(profile_path)
        ad = self.stats.data["adaptive"]
        if (self.coach and self.coach["level"] and not self.stats.data["runs"]
                and (ad["level"], ad["ok"], ad["bad"]) == (1, 0, 0)):
            ad["level"] = self.coach["level"]       # only when there is no sim history; the sim's own rule stays authoritative
        self.voice = Voice()
        self.quit = False
        self.screen: Screen = MenuScreen(self)
        self.last_fps = 0.0
        self.fps_history = []

    # ---- transitions ---------------------------------------------------------------------
    def goto(self, screen: Screen) -> None:
        self.screen = screen

    def goto_briefing(self, mode: str, level: int, seed: Optional[int] = None) -> None:
        self.goto(BriefingScreen(self, mode, level, seed))

    # ---- spoken secondary task --------------------------------------------------------------
    @property
    def lang(self) -> str:
        return self.stats.settings()["voice"]

    def audio_variant(self, mode: str, level: int, seed: int) -> Optional[str]:
        """Variant of the spoken task for a run, or None (off, radar-only baseline, or no way to hear it)."""
        if mode == RADAR_ONLY:
            return None
        v = resolve_variant(self.stats.settings()["audio"], level, seed)
        if v is None or not (self.headless or self.voice.available(self.lang)):
            return None
        return v

    def make_audio(self, variant: str, level: int, seed: int, **kw) -> AudioTask:
        return AudioTask(variant, level, seed, durations=durations(self.lang), **kw)

    def start_audio_solo(self, debrief) -> None:
        a = debrief.r.audio or {}
        if a.get("variant"):
            self.goto(AudioSoloScreen(self, debrief, a["variant"], debrief.r.level, debrief.r.seed))

    def start_run(self, mode: str, level: int, seed: int) -> None:
        # draw a "preparing" frame first so the window does not look frozen while the scenario is verified
        sc = generate(seed, level)
        w = World(sc, tasks=(mode != RADAR_ONLY))
        variant = self.audio_variant(mode, level, seed)
        if variant:
            self.voice.preload(self.lang)
            w.audio = self.make_audio(variant, level, seed)
        self.goto(GameScreen(self, GameSession(w, mode, voice=self.voice, lang=self.lang)))

    def start_tutorial(self) -> None:
        sc = tutorial_scenario()
        w = World(sc, tasks=False, pilot_delay=1.5)
        tut = Tutorial(w)
        self.goto(GameScreen(self, GameSession(w, "Practice", tut)))

    def finish_tutorial(self, s: GameSession, skipped: bool = False) -> None:
        if not skipped:
            self.stats.data["tutorial_done"] = True
            self.stats.save()
        self.goto(MenuScreen(self))

    def finish_run(self, s: GameSession) -> None:
        mode = s.mode
        r = compute_result(s.world, mode)
        if s.voice is not None:
            s.voice.stop()
        rec = self.stats.add_run(r, voice=s.lang if r.audio else None)
        if mode == "Adaptive":
            self.stats.data["adaptive"] = adaptive_update(self.stats.data["adaptive"], r.met, r.assisted)
            self.stats.save()
        self.goto(DebriefScreen(self, s.world, r, mode, True))

    def export_csv(self) -> Optional[str]:
        folder = os.path.dirname(os.path.abspath(self.stats.path)) or user_data_dir()
        path = os.path.join(folder, time.strftime("sim_export_%Y%m%d-%H%M%S.csv"))
        return path if self.stats.export_csv(path) else None

    # ---- events and frames --------------------------------------------------------------
    def handle_event(self, e) -> None:
        if e.type == pygame.QUIT:
            self.quit = True
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_F11:
                try:
                    if self.fit:
                        # a plain toggle_fullscreen would switch the monitor to a 4:3 video mode: use the desktop size instead
                        self._fs = not getattr(self, "_fs", False)
                        if self._fs:
                            self._win_size = pygame.display.get_surface().get_size()
                            pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                        else:
                            pygame.display.set_mode(self._win_size, pygame.RESIZABLE)
                    else:
                        pygame.display.toggle_fullscreen()
                except pygame.error:
                    pass
                return
            self.screen.on_key(e.key, e.mod, getattr(e, "unicode", "") or "")
        elif e.type == pygame.MOUSEBUTTONDOWN:
            if e.button in (1, 3):
                self.screen.on_click(self._to_logical(e.pos), e.button)
        elif e.type in (getattr(pygame, "WINDOWFOCUSLOST", -1), getattr(pygame, "WINDOWMINIMIZED", -1)):
            # losing focus (alt-tab, notification) must not cost the player a loss of separation: pause quietly
            if isinstance(self.screen, GameScreen) and not self.screen.s.paused and self.screen.s.tut is None:
                self.screen.s.paused = True
                self.screen.s.auto_paused = True
        elif e.type == pygame.MOUSEWHEEL:
            self.screen.on_wheel(self._to_logical(pygame.mouse.get_pos()), e.y)

    def _to_logical(self, pos):
        if not self.fit:
            return pos
        ox, oy, k = self._view
        return (int((pos[0] - ox) / k), int((pos[1] - oy) / k))

    def _present(self) -> None:
        if not self.fit:
            pygame.display.flip()
            return
        win = pygame.display.get_surface()
        ww, wh = win.get_size()
        k = min(ww / T.W, wh / T.H)
        size = (max(1, int(T.W * k)), max(1, int(T.H * k)))
        ox, oy = (ww - size[0]) // 2, (wh - size[1]) // 2
        self._view = (ox, oy, k)
        win.fill(T.BG)
        win.blit(pygame.transform.smoothscale(self.surface, size), (ox, oy))
        pygame.display.flip()

    def frame(self, dt: float, draw: bool = True) -> None:
        for e in pygame.event.get():
            self.handle_event(e)
        # a briefing that was confirmed generates the run on the next frame (after the "Preparing" text was drawn)
        scr = self.screen
        if isinstance(scr, BriefingScreen) and scr.starting:
            if getattr(scr, "_drawn_starting", False):
                self.start_run(scr.mode, scr.level, scr.seed)
                scr = self.screen
            else:
                scr._drawn_starting = True
        self.screen.update(dt)
        if draw:
            self.screen.draw(self.surface)
            self._present()

    def run(self) -> None:
        last = time.perf_counter()
        while not self.quit:
            self.clock.tick(60)
            now = time.perf_counter()
            dt = min(now - last, 0.1)        # monotonic clock; a stall (window drag, sleep) never becomes a burst of sim time
            last = now
            self.frame(dt)
        pygame.quit()

    def screenshot(self, path: str) -> None:
        self.screen.draw(self.surface)
        pygame.image.save(self.surface, path)


def main() -> None:
    try:
        App().run()
    except Exception:
        import traceback
        try:
            with open(os.path.join(user_data_dir(), "crash.log"), "w", encoding="utf-8") as f:
                f.write(traceback.format_exc())
        except OSError:
            pass
        raise
