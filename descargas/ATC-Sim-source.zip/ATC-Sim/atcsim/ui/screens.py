"""Menu, briefing, debrief, replay, statistics and help screens."""
from __future__ import annotations

import time
from typing import Callable, Dict, List, Optional, Tuple

import pygame

from ..core import analysis
from ..core.audio_task import (DEFAULT_ON_FROM, NICE as A_NICE, SETTINGS as AUDIO_SETTINGS, TONE, VOICES, AudioTask,
                               code_text, resolve_variant)
from ..core.persistence import StatsStore
from ..core.scenario import LEVELS, level_spec
from ..core.scoring import RADAR_ONLY, RunResult, endurance_text, latest_pair_cost
from ..core.world import World
from . import theme as T
from .panels import speaker
from .scope import Overlay, RAc, ScopeView
from .session import SCOPE_RECT

TASK_HELP = [
    ("Read-back", "Y  N", "error detection"),
    ("Transfer", "T, then 1 2 3", "handover"),
    ("Alert", "Space", "vigilance"),
    ("Level request", "A  D", "what-if"),
    ("Priority recall", "1-4", "working memory"),
    ("Time to conflict", "1-6", "estimation"),
    ("ETA", "1-5", "mental arithmetic"),
    ("Audio Σ", "V + cifras + Enter", "oír y sumar"),
    ("Audio =", "M", "escucha selectiva"),
]

AUDIO_ROW = 5                                   # menu row of the spoken-task setting (Quit stays last)
SETTING_TEXT = {"auto": "auto", "sum": "Σ", "code": "=", "off": "no"}
VARIANT_GLYPH = {"sum": "Σ", "code": "="}


def audio_hint(st: Dict[str, str]) -> str:
    return f"{SETTING_TEXT[st['audio']]}   {st['voice'].upper()}"


def level_audio_text(setting: str, level: int) -> str:
    if setting == "auto":
        return "Σ / =" if level >= DEFAULT_ON_FROM else "-"
    return VARIANT_GLYPH.get(setting, "-")

CONTROL_HELP = [
    ("Select", "click  Tab"),
    ("Heading", "Left Right (Shift 10, Ctrl 1)  H + digits  right-click"),
    ("Level", "Up Down (Shift 2000, Ctrl 100)  F + digits"),
    ("Speed (TAS)", "+ - (Shift 20)  S + digits"),
    ("Send", "Enter"),
    ("Cancel", "Esc"),
    ("Resume nav", "R"),
    ("Direct to", "Shift+click a fix"),
    ("Transfer", "T"),
    ("Pause", "P"),
    ("Abandon", "Q while paused"),
    ("Fullscreen", "F11"),
]

SCORING_HELP = [
    "Separation 5 NM or 1000 ft. Exit at XFL +-200 ft. Transfer inside 20 NM.",
    "Score 100 minus: loss 10-22, R-31 6, bad handoff 3, wrong 1.5, blank 2, needless instruction 0.5.",
    "Adaptive: +1 after 2 clean runs (3 from level 5), -1 after 2 failed.",
]


class Screen:
    def update(self, dt: float) -> None: ...
    def draw(self, dst: pygame.Surface) -> None: ...
    def on_key(self, key: int, mods: int, unicode: str) -> None: ...
    def on_click(self, pos, button: int) -> None: ...
    def on_wheel(self, pos, dy: int) -> None: ...


def title(dst, s: str, sub: str = "") -> None:
    T.blit_text(dst, s, (40, 26), 28, T.WHITE, bold=True)
    if sub:
        T.blit_text(dst, sub, (T.W - 40, 38), 15, T.DIM, anchor="topright")
    pygame.draw.line(dst, T.LINE, (40, 72), (T.W - 40, 72))


def button(dst, r: pygame.Rect, label: str, sel: bool, hint: str = "") -> None:
    if sel:
        pygame.draw.rect(dst, T.PANEL2, r)
        pygame.draw.rect(dst, T.GREEN, (r.x, r.y, 3, r.h))
    pygame.draw.line(dst, T.LINE, r.bottomleft, r.bottomright)
    T.blit_text(dst, label, (r.x + 16, r.y + 10), 20, T.GREEN if sel else T.TEXT, bold=sel)
    if hint:
        T.blit_text(dst, hint, (r.right - 12, r.y + 14), 14, T.DIM, anchor="topright")


# ----------------------------------------------------------------------------------------------
class MenuScreen(Screen):
    def __init__(self, app, sel=None, level=None):
        self.app = app
        self.sel = sel if sel is not None else (1 if app.stats.data.get("tutorial_done") else 0)
        self.level = level if level is not None else min(10, max(1, app.stats.data["adaptive"]["level"]))
        self.rects: List[pygame.Rect] = []

    def items(self):
        ad = self.app.stats.data["adaptive"]
        return [
            ("Practice", "" if not self.app.stats.data.get("tutorial_done") else "done"),
            ("Adaptive", f"L{ad['level']}"),
            (f"Ladder  L{self.level}", "< >"),
            ("Stats", str(len(self.app.stats.data['runs']))),
            ("Help", "F1"),
            ("Audio", audio_hint(self.app.stats.settings())),
            ("Quit", "Q"),
        ]

    def activate(self, i: int) -> None:
        a = self.app
        if i == 0:
            a.start_tutorial()
        elif i == 1:
            a.goto_briefing("Adaptive", a.stats.data["adaptive"]["level"])
        elif i == 2:
            a.goto_briefing("Ladder", self.level)
        elif i == 3:
            a.goto(StatsScreen(a))
        elif i == 4:
            a.goto(HelpScreen(a))
        elif i == AUDIO_ROW:
            st = a.stats.settings()
            st["audio"] = AUDIO_SETTINGS[(AUDIO_SETTINGS.index(st["audio"]) + 1) % len(AUDIO_SETTINGS)]
            a.stats.save()
        else:
            a.quit = True

    def toggle_voice(self) -> None:
        a = self.app
        st = a.stats.settings()
        st["voice"] = VOICES[(VOICES.index(st["voice"]) + 1) % len(VOICES)]
        a.stats.save()
        a.voice.play(st["voice"], [TONE, "1", "2", "3"])          # hear the voice and the volume at once

    def on_key(self, key, mods, unicode):
        n = len(self.items())
        if key in (pygame.K_DOWN, pygame.K_TAB):
            self.sel = (self.sel + 1) % n
        elif key == pygame.K_UP:
            self.sel = (self.sel - 1) % n
        elif key == pygame.K_LEFT and self.sel == 2:
            self.level = max(1, self.level - 1)
        elif key == pygame.K_RIGHT and self.sel == 2:
            self.level = min(10, self.level + 1)
        elif key in (pygame.K_LEFT, pygame.K_RIGHT) and self.sel == AUDIO_ROW:
            self.toggle_voice()
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.activate(self.sel)
        elif key == pygame.K_F1:
            self.app.goto(HelpScreen(self.app))
        elif key == pygame.K_q:
            self.app.quit = True
        elif key == pygame.K_ESCAPE:
            self.sel = n - 1                 # Esc only highlights "Quit" (Enter confirms): an accidental Esc must not close the game
        elif key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9):
            if self.sel == 2:
                self.level = key - pygame.K_0

    def on_click(self, pos, button):
        for i, r in enumerate(self.rects):
            if r.collidepoint(pos):
                if i == 2:
                    # left third lowers, right third raises, middle starts
                    if pos[0] < r.x + 60:
                        self.level = max(1, self.level - 1)
                        self.sel = 2
                        return
                    if pos[0] > r.right - 60:
                        self.level = min(10, self.level + 1)
                        self.sel = 2
                        return
                if i == AUDIO_ROW and pos[0] > r.right - 120:     # right end (the ES/EN part) switches the voice
                    self.sel = i
                    self.toggle_voice()
                    return
                self.sel = i
                self.activate(i)
                return

    def draw(self, dst):
        dst.fill(T.BG)
        title(dst, "ATC Sim")
        self.rects = []
        y = 110
        for i, (lab, hint) in enumerate(self.items()):
            r = pygame.Rect(40, y, 560, 46)
            self.rects.append(r)
            button(dst, r, lab, i == self.sel, hint)
            y += 50
        sp = level_spec(self.level)
        x0, x1 = 700, T.W - 40
        T.blit_text(dst, f"L{sp.level}  {sp.name}", (x0, 106), 26, T.AMBER, bold=True)
        rows = [("Aircraft", str(sp.n_aircraft)), ("Clock", f"x{sp.scale:g}"), ("Wind", f"{int(sp.wind_kt)} kt"),
                ("Conflicts", str(sp.design_conflicts)), ("Task every", f"{int(sp.task_gap_s)} s"),
                ("Answer in", f"{sp.task_deadline_s:g} s"), ("Aids", str(sp.aids)), ("R-31", "yes" if sp.zone else "no"),
                ("Goal", f"{int(sp.goal_accuracy * 100)} %"),
                ("Audio", level_audio_text(self.app.stats.settings()["audio"], sp.level))]
        yy = 152
        for k, v in rows:
            pygame.draw.line(dst, T.LINE, (x0, yy + 29), (x1, yy + 29))
            T.blit_text(dst, k, (x0, yy + 4), 16, T.DIM)
            T.blit_text(dst, v, (x1, yy + 4), 16, T.TEXT, anchor="topright")
            yy += 30
        st = self.app.stats
        b = st.data["best"].get(str(sp.level))
        T.blit_text(dst, f"Best {b['score']:.0f}" if b else "-", (x0, yy + 12), 16, T.GREEN if b else T.FAINT)
        if st.warning:
            T.blit_text(dst, st.warning[:150], (40, T.H - 40), 13, T.RED)
        coach = getattr(self.app, "coach", None)
        if coach:
            T.blit_text(dst, coach["message"][:150], (40, T.H - 66), 14, T.AMBER)


# ----------------------------------------------------------------------------------------------
class BriefingScreen(Screen):
    def __init__(self, app, mode: str, level: int, seed: Optional[int] = None):
        self.app, self.mode, self.level = app, mode, level
        self.seed = seed if seed is not None else app.stats.next_seed()
        self.starting = False

    def on_key(self, key, mods, unicode):
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self.starting = True
        elif key == pygame.K_ESCAPE:
            ladder = self.mode == "Ladder"
            self.app.goto(MenuScreen(self.app, sel=2 if ladder else 1, level=self.level if ladder else None))

    def on_click(self, pos, button):
        if button == 1:
            self.starting = True

    def update(self, dt):
        pass

    def audio_line(self) -> str:
        """One briefing line for the spoken task: what to do and, for codes, the target (given here and spoken at start)."""
        a = self.app
        if self.mode == RADAR_ONLY:
            return ""
        st = a.stats.settings()
        variant = a.audio_variant(self.mode, self.level, self.seed)
        lang = st["voice"].upper()
        if variant is None:
            wanted = resolve_variant(st["audio"], self.level, self.seed)
            return f"Audio: sin sonido ({lang})" if wanted else ""
        if variant == "sum":
            return f"Audio Σ {lang}:  V + cifras + Enter"
        if not hasattr(self, "_target"):
            self._target = code_text(AudioTask("code", self.level, self.seed).target)
        return f"Audio = {lang}:  {self._target}  ->  M"

    def draw(self, dst):
        dst.fill(T.BG)
        sp = level_spec(self.level)
        title(dst, f"{self.mode}  L{sp.level}  {sp.name}", f"seed {self.seed}")
        lines = [
            "Separation: 5 NM or 1000 ft",
            "Exit gate at XFL +-200 ft",
            "Transfer inside 20 NM of the gate",
            "Check every read-back",
        ]
        if sp.zone:
            lines.append("R-31: keep out while active")
        lines.append(["Aids: none", "Aids: 2-min vectors", "Aids: vectors, alerts, trial", "Aids: all + conflict lines"][sp.aids])
        if self.mode == RADAR_ONLY:
            lines.append("No tasks")
        else:
            au = self.audio_line()
            if au:
                lines.append(au)
        lines.append(f"Goal: {int(sp.goal_accuracy * 100)} % accuracy, 0 losses")
        y = 120
        for ln in lines:
            pygame.draw.line(dst, T.LINE, (40, y + 34), (620, y + 34))
            T.blit_text(dst, ln, (40, y + 6), 20, T.TEXT)
            y += 40
        if self.starting:
            T.blit_text(dst, "...", (40, y + 30), 26, T.AMBER, bold=True)
        else:
            T.blit_text(dst, "Enter  Start", (40, y + 30), 22, T.GREEN, bold=True)
            T.blit_text(dst, "Esc  Back", (40, y + 62), 18, T.DIM)


# ----------------------------------------------------------------------------------------------
class DebriefScreen(Screen):
    TABS = ["Summary", "Losses", "Decisions", "Handoffs"]

    def __init__(self, app, world: World, result: RunResult, mode: str, saved: bool):
        self.app, self.world, self.r, self.mode, self.saved = app, world, result, mode, saved
        self.tab = 0
        self.scroll = 0
        self.sel = 0
        self._reports: Dict[int, dict] = {}
        self.losses = sorted(world.losses, key=lambda e: e.start_t)
        self.decisions = analysis.task_report_lines(world) + audio_decisions(world)
        self.hand = world.handoffs
        self.msg = ""
        self.reco = self._recommendation()
        self.content_h = 0

    def _recommendation(self) -> str:
        r = self.r
        if r.assisted:
            return "This run used pause at level 5+, so it is marked 'assisted' and does not count for Adaptive mode."
        if r.met:
            return "Goal met. Repeat this level once more before going up: consistency first, speed second."
        if r.losses:
            return "Repeat the SAME seed and remove every loss of separation before anything else (see the Losses tab)."
        w = r.worst_component()
        if w:
            return f"Your weakest component was {w[0]} ({w[1]:.0f}%). Repeat the level and protect that one first."
        return "Repeat the level."

    def report(self, i: int) -> dict:
        if i not in self._reports:
            self._reports[i] = analysis.loss_report(self.world, self.losses[i])
        return self._reports[i]

    # ---- content builders: list of (text, color, size, block_index)
    def build(self, width: int):
        L: List[Tuple[str, tuple, int, int]] = []
        r = self.r
        if self.tab == 0:
            L.append((f"Score {r.score:.0f} / 100", T.WHITE, 30, -1))
            L.append((("GOAL MET" if r.met else "GOAL NOT MET") + f"   ({r.goal_text})", T.GREEN if r.met else T.RED, 18, -1))
            L.append((f"Items: {r.correct} correct, {r.wrong} wrong, {r.blank} blank   -   accuracy {r.accuracy:.1f}%   -   "
                      f"{r.seconds_per_item:.1f} s per item   -   {r.aircraft} aircraft   -   {r.commands} instructions "
                      f"({r.unneeded} without a predicted need)", T.TEXT, 15, -1))
            L.append(("", T.TEXT, 8, -1))
            L.append((self.reco, T.AMBER, 16, -1))
            if self.mode == "Adaptive":
                ad = self.app.stats.data["adaptive"]
                L.append((f"Adaptive mode: the next run is level {ad['level']} ({ad['ok']} clean and {ad['bad']} failed in a row).", T.CYAN, 15, -1))
            L.append(("", T.TEXT, 8, -1))
            L.append(("Components", T.CYAN, 17, -1))
            comps = sorted(r.components.items(), key=lambda kv: (r.component_accuracy(kv[0]) or 0))
            for name, c in comps:
                n = c["correct"] + c["wrong"] + c["blank"]
                acc = 100.0 * c["correct"] / n if n else 0
                bar = "#" * int(acc / 5) + "." * (20 - int(acc / 5))
                L.append((f"{name:<28} [{bar}] {acc:5.1f}%   ({c['correct']}/{c['wrong']}/{c['blank']})", T.RED if acc < 70 else (T.AMBER if acc < 90 else T.GREEN), 14, -1))
            L.append(("", T.TEXT, 8, -1))
            th = ["-" if v is None else f"{v:.0f}%" for v in r.thirds]
            L.append((f"Thirds: {th[0]}  /  {th[1]}  /  {th[2]}", T.TEXT, 14, -1))
            L.append((endurance_text(r.thirds_data), T.TEXT, 14, -1))
            runs = self.app.stats.data["runs"]
            rec = next((x for x in reversed(runs) if x["seed"] == r.seed and x["level"] == r.level and x["mode"] == r.mode), None)
            cost = latest_pair_cost(runs, rec) if rec is not None else None
            if cost:
                L.append((f"Dual-task cost (same seed, radar items): radar-only {cost['radar_only']:.0f}% vs with tasks {cost['full']:.0f}% = "
                          f"{cost['cost_points']:+.1f} points (target <= 5 before raising the load; a proposal, not an official cut-off).", T.CYAN, 14, -1))
            elif r.mode == RADAR_ONLY:
                L.append(("Radar-only baseline", T.DIM, 14, -1))
            else:
                L.append(("B: radar-only replay", T.DIM, 14, -1))
            for txt, col in audio_summary_lines(rec.get("audio") if rec else None):
                L.append((txt, col, 15 if col is T.WHITE else 14, -1))
            L.append(("", T.TEXT, 8, -1))
            L.append(("Score breakdown", T.CYAN, 17, -1))
            if not r.breakdown:
                L.append(("No deductions.", T.GREEN, 14, -1))
            for txt, v in r.breakdown:
                L.append((f"{v:+6.1f}   {txt}", T.TEXT, 14, -1))
        elif self.tab == 1:
            if not self.losses:
                L.append(("No losses", T.GREEN, 20, -1))
            for i, ep in enumerate(self.losses):
                rep = self.report(i)
                L.append((f"{i + 1}. {ep.a} / {ep.b}   at {T.fmt_time(ep.start_t)}   min {ep.min_h:.1f} NM, {ep.min_v:.0f} ft   [{rep['verdict']}]",
                          T.RED, 17, i))
                for ln in rep["lines"]:
                    for w_ in T.wrap(ln, 14, width - 30):
                        L.append((w_, T.TEXT, 14, i))
                L.append(("Enter  replay", T.DIM, 13, i))
                L.append(("", T.TEXT, 8, i))
        elif self.tab == 2:
            if not self.decisions:
                L.append(("All correct", T.GREEN, 20, -1))
            for i, (out, head, detail) in enumerate(self.decisions):
                L.append((("BLANK  " if out == "blank" else "WRONG  ") + head, T.AMBER if out == "blank" else T.RED, 15, -1))
                for w_ in T.wrap(detail, 14, width - 30):
                    L.append(("      " + w_, T.TEXT, 14, -1))
            L.append(("", T.TEXT, 8, -1))
            lat = [t for t in self.world.tasks.log if t.outcome == "correct" and t.response_s is not None]
            if lat:
                by: Dict[str, List[float]] = {}
                for t in lat:
                    by.setdefault(t.kind, []).append(t.response_s)
                L.append(("Response time", T.CYAN, 16, -1))
                for k, v in sorted(by.items()):
                    L.append((f"   {k:<10} {sum(v) / len(v):5.1f} s   ({len(v)} answers)", T.TEXT, 14, -1))
            a = r.audio
            if a and a.get("rt_s") is not None:
                L.append((f"   audio {VARIANT_GLYPH[a['variant']]:<4} {a['rt_s']:5.1f} s   ({a['correct']} answers)", T.TEXT, 14, -1))
        else:
            if not self.hand:
                L.append(("None", T.DIM, 18, -1))
            for h in self.hand:
                ok = h["outcome"] == "correct"
                if h["outcome"] == "blank":
                    L.append((f"NONE {h['callsign']:<8} not handed over", T.AMBER, 14, -1))
                    continue
                L.append((f"{'OK   ' if ok else 'BAD  '}{h['callsign']:<8} gate {h['gate']:<6} {h['gate_dist']:4.1f} NM off"
                          f"   level {h['alt']:.0f} ft (wanted {h['exit_alt']:.0f}, {h['alt_err']:+.0f})   transfer: "
                          f"{'yes' if h['transferred'] else 'NO'}   at {T.fmt_time(h['t'])}", T.GREEN if ok else T.RED, 14, -1))
        return L

    def draw(self, dst):
        dst.fill(T.BG)
        title(dst, "Debrief", f"{self.mode}  L{self.r.level}  seed {self.r.seed}")
        x = 40
        self.tab_rects = []
        for i, name in enumerate(self.TABS):
            label = name
            if i == 1:
                label += f" ({len(self.losses)})"
            elif i == 2:
                label += f" ({len(self.decisions)})"
            elif i == 3:
                label += f" ({len(self.hand)})"
            r = pygame.Rect(x, 88, 190, 32)
            pygame.draw.rect(dst, (30, 52, 46) if i == self.tab else T.PANEL2, r)
            pygame.draw.rect(dst, T.GREEN if i == self.tab else T.LINE, r, 1)
            T.blit_text(dst, f"{i + 1}  {label}", r.center, 15, T.WHITE if i == self.tab else T.DIM, anchor="center")
            self.tab_rects.append(r)
            x += 198
        area = pygame.Rect(40, 134, T.W - 80, T.H - 190)
        lines = self.build(area.w)
        total = sum(sz + 6 for (_, _, sz, _) in lines)
        self.content_h = total
        self.scroll = max(0, min(self.scroll, max(0, total - area.h)))
        dst.set_clip(area)
        y = area.y - self.scroll
        for (s, col, sz, blk) in lines:
            h = sz + 6
            if blk >= 0 and blk == self.sel and self.tab == 1:
                pygame.draw.rect(dst, (40, 24, 24), (area.x - 6, y - 2, area.w + 12, h + 2))
            if y + h >= area.y and y <= area.bottom:
                T.blit_text(dst, s, (area.x, y), sz, col, mono=(self.tab in (0, 3) and sz <= 15 and "[" in s) or self.tab == 3)
            y += h
        dst.set_clip(None)
        foot = "1-4 tabs    N next    R retry    B radar-only    " + ("A audio solo    " if self.r.audio else "") + "E export    Esc menu"
        T.blit_text(dst, foot, (40, T.H - 46), 14, T.DIM)
        if self.msg:
            T.blit_text(dst, self.msg, (40, T.H - 26), 13, T.AMBER)

    def on_wheel(self, pos, dy):
        self.scroll = max(0, self.scroll - dy * 40)

    def on_click(self, pos, button):
        for i, r in enumerate(getattr(self, "tab_rects", [])):
            if r.collidepoint(pos):
                self.tab, self.scroll = i, 0

    def on_key(self, key, mods, unicode):
        a = self.app
        if key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
            self.tab, self.scroll = key - pygame.K_1, 0
        elif key == pygame.K_RIGHT:
            self.tab, self.scroll = (self.tab + 1) % 4, 0
        elif key == pygame.K_LEFT:
            self.tab, self.scroll = (self.tab - 1) % 4, 0
        elif key == pygame.K_DOWN:
            if self.tab == 1 and self.losses:
                self.sel = min(len(self.losses) - 1, self.sel + 1)
                self._scroll_to_sel()
            else:
                self.scroll += 40
        elif key == pygame.K_UP:
            if self.tab == 1 and self.losses:
                self.sel = max(0, self.sel - 1)
                self._scroll_to_sel()
            else:
                self.scroll = max(0, self.scroll - 40)
        elif key == pygame.K_PAGEDOWN:
            self.scroll += 300
        elif key == pygame.K_PAGEUP:
            self.scroll = max(0, self.scroll - 300)
        elif key in (pygame.K_RETURN, pygame.K_KP_ENTER) and self.tab == 1 and self.losses:
            self.replay(self.sel)
        elif key == pygame.K_b and self.mode != RADAR_ONLY:
            a.goto_briefing(RADAR_ONLY, self.r.level, seed=self.r.seed)
        elif key == pygame.K_a and self.r.audio:
            a.start_audio_solo(self)
        elif key == pygame.K_r:
            a.goto_briefing(self.mode if self.mode in ("Adaptive", "Ladder", RADAR_ONLY) else "Ladder", self.r.level, seed=self.r.seed)
        elif key == pygame.K_n:
            lvl = a.stats.data["adaptive"]["level"] if self.mode == "Adaptive" else self.r.level
            a.goto_briefing(self.mode if self.mode in ("Adaptive", "Ladder") else "Ladder", lvl)
        elif key == pygame.K_e:
            path = a.export_csv()
            self.msg = path if path else a.stats.warning
        elif key == pygame.K_ESCAPE:
            a.goto(MenuScreen(a))

    def _scroll_to_sel(self) -> None:
        lines = self.build(T.W - 80)
        y = 0
        for (_, _, sz, blk) in lines:
            if blk == self.sel:
                self.scroll = max(0, y - 20)
                return
            y += sz + 6

    def replay(self, i: int) -> None:
        ep = self.losses[i]
        self.app.goto(ReplayScreen(self.app, self, ep))


# ----------------------------------------------------------------------------------------------
class ReplayScreen(Screen):
    def __init__(self, app, back: DebriefScreen, ep):
        self.app, self.back, self.ep = app, back, ep
        w = back.world
        self.t0 = max(0.0, ep.start_t - 150.0)
        self.t1 = (ep.end_t or ep.start_t) + 30.0
        self.clip = w.replay_clip(self.t0, self.t1)
        self.scope = ScopeView(SCOPE_RECT, w.sector)
        self.pos = 0.0
        self.speed = 4.0
        self.paused = False
        self.real = 0.0
        self.cmds = [c for c in w.clearances if c.applied and c.callsign in ep.pair and self.t0 <= (c.applied_t or 0) <= self.t1]

    def update(self, dt):
        self.real += dt
        if not self.paused and self.clip:
            span = self.clip[-1][0] - self.clip[0][0]
            self.pos = min(span, self.pos + dt * self.speed)

    def _frame(self):
        if not self.clip:
            return None, None
        t = self.clip[0][0] + self.pos
        idx = 0
        for i, (ts, _) in enumerate(self.clip):
            if ts <= t:
                idx = i
        return self.clip[idx], (self.clip[idx - 1] if idx > 0 else None)

    def on_key(self, key, mods, unicode):
        if key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
            self.app.goto(self.back)
        elif key == pygame.K_SPACE:
            self.paused = not self.paused
        elif key == pygame.K_r:
            self.pos = 0.0
            self.paused = False
        elif key == pygame.K_RIGHT:
            self.pos = min(self.clip[-1][0] - self.clip[0][0], self.pos + 10) if self.clip else 0
        elif key == pygame.K_LEFT:
            self.pos = max(0.0, self.pos - 10)
        elif key in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self.speed = min(16.0, self.speed * 2)
        elif key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.speed = max(0.5, self.speed / 2)

    def draw(self, dst):
        dst.fill(T.BG)
        frame, prev = self._frame()
        ep = self.ep
        pygame.draw.rect(dst, T.PANEL, (0, 0, T.W, 38))
        T.blit_text(dst, f"REPLAY  {ep.a} / {ep.b}", (12, 6), 18, T.WHITE, bold=True)
        T.blit_text(dst, f"{T.fmt_time(ep.start_t)}   min {ep.min_h:.1f} NM / {ep.min_v:.0f} ft", (330, 10), 14, T.AMBER)
        if frame is None:
            T.blit_text(dst, "No recording", (60, 200), 20, T.RED)
            return
        t, rows = frame
        prev_alt = {r[0]: r[3] for r in prev[1]} if prev else {}
        recs: List[RAc] = []
        los_now = []
        for (cs, x, y, alt, hdg, tas) in rows:
            vs = 0
            if cs in prev_alt:
                d = alt - prev_alt[cs]
                vs = 1 if d > 5 else (-1 if d < -5 else 0)
            recs.append(RAc(cs, x, y, alt, hdg, tas, hdg, vs, alt, selected=cs in ep.pair, state="normal"))
        import math
        for i in range(len(recs)):
            for j in range(i + 1, len(recs)):
                a, b = recs[i], recs[j]
                if math.hypot(a.x - b.x, a.y - b.y) < 5.0 and abs(a.alt - b.alt) < 1000.0:
                    a.state = b.state = "los"
                    los_now.append((a.cs, b.cs))
        ov = Overlay(aids=1, t=t, los_pairs=los_now, blink=int(self.real * 2.5) % 2 == 0, zone_active=False, zone_scheduled=False)
        self.scope.draw(dst, recs, ov)
        # side panel
        px = 946
        pygame.draw.rect(dst, T.PANEL, (px, 44, 486, 744))
        T.blit_text(dst, f"Time {T.fmt_time(t)}   speed x{self.speed:g}{'   PAUSED' if self.paused else ''}", (px + 12, 56), 16, T.TEXT, mono=True)
        span = max(1.0, self.clip[-1][0] - self.clip[0][0])
        bar = pygame.Rect(px + 12, 84, 460, 12)
        pygame.draw.rect(dst, T.BG, bar)
        pygame.draw.rect(dst, T.CYAN, (bar.x, bar.y, int(bar.w * self.pos / span), bar.h))
        for mark, col in ((ep.start_t, T.RED), (ep.end_t or ep.start_t, T.AMBER)):
            mx = bar.x + int(bar.w * (mark - self.clip[0][0]) / span)
            pygame.draw.line(dst, col, (mx, bar.y - 3), (mx, bar.bottom + 3), 2)
        y = 116
        T.blit_text(dst, "Instructions", (px + 12, y), 14, T.AMBER, bold=True)
        y += 22
        if not self.cmds:
            T.blit_text(dst, "none", (px + 12, y), 13, T.DIM)
            y += 20
        for c in self.cmds:
            col = T.TEXT if (c.applied_t or 0) <= t else T.FAINT
            for ln in T.wrap(f"{T.fmt_time(c.applied_t or 0)}  {c.callsign}: {c.text}", 13, 460, mono=True):
                T.blit_text(dst, ln, (px + 12, y), 13, col, mono=True)
                y += 17
        y += 12
        for a in recs:
            if a.cs in ep.pair:
                T.blit_text(dst, f"{a.cs}  FL{int(a.alt / 100):03d}  hdg {(int(round(a.hdg)) or 360):03d}  {int(a.gs)} kt", (px + 12, y), 14, T.YELLOW, mono=True)
                y += 20
        T.blit_text(dst, "Space  Left Right  R  + -  Esc", (px + 12, 760), 12, T.DIM)


# ----------------------------------------------------------------------------------------------
class StatsScreen(Screen):
    def __init__(self, app):
        self.app = app
        self.msg = ""

    def on_key(self, key, mods, unicode):
        if key == pygame.K_e:
            p = self.app.export_csv()
            self.msg = p if p else self.app.stats.warning
        elif key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_BACKSPACE):
            self.app.goto(MenuScreen(self.app))

    def on_click(self, pos, button):
        pass

    def draw(self, dst):
        dst.fill(T.BG)
        st = self.app.stats
        d = st.data
        title(dst, "Stats")
        ad = d["adaptive"]
        T.blit_text(dst, f"Adaptive L{ad['level']}    streak {st.clean_streak()}    runs {len(d['runs'])}", (40, 112), 16, T.TEXT)
        hdr = f"{'Date':<17}{'Mode':<10}{'Lv':>3}{'Score':>7}{'Corr':>6}{'Wrong':>6}{'Blank':>6}{'Acc%':>7}{'s/item':>8}{'Loss':>6}  Met"
        T.blit_text(dst, hdr, (40, 146), 14, T.DIM, mono=True)
        y = 168
        for x in reversed(d["runs"][-18:]):
            date = time.strftime("%d/%m/%Y %H:%M", time.localtime(x["ts"]))
            met = "Yes" if x["met"] else "No"
            line = (f"{date:<17}{x['mode'][:9]:<10}{x['level']:>3}{x['score']:>7.0f}{x['correct']:>6}{x['wrong']:>6}{x['blank']:>6}"
                    f"{x['accuracy']:>7.1f}{x['spi']:>8.1f}{x['losses']:>6}  {met}{'  (assisted)' if x.get('assisted') else ''}")
            au = x.get("audio")
            if au and au.get("n"):
                line += f"   {VARIANT_GLYPH[au['variant']]} {au['accuracy']:.0f}%"
            T.blit_text(dst, line, (40, y), 14, T.GREEN if x["met"] else T.TEXT, mono=True)
            y += 20
        if not d["runs"]:
            T.blit_text(dst, "No runs", (40, 180), 16, T.DIM)
        T.blit_text(dst, "Best", (900, 112), 16, T.CYAN, bold=True)
        yy = 140
        for lv in range(1, 11):
            b = d["best"].get(str(lv))
            T.blit_text(dst, f"Level {lv:>2}: " + (f"{b['score']:5.1f}  acc {b['accuracy']:.0f}%" if b else "-"), (900, yy), 14, T.TEXT, mono=True)
            yy += 20
        T.blit_text(dst, "E export CSV    Esc back", (40, T.H - 46), 14, T.DIM)
        if self.msg:
            T.blit_text(dst, self.msg, (40, T.H - 26), 13, T.AMBER)


class HelpScreen(Screen):
    def __init__(self, app):
        self.app = app
        self.scroll = 0

    def on_key(self, key, mods, unicode):
        if key == pygame.K_DOWN:
            self.scroll += 40
        elif key == pygame.K_UP:
            self.scroll = max(0, self.scroll - 40)
        elif key == pygame.K_PAGEDOWN:
            self.scroll += 300
        elif key == pygame.K_PAGEUP:
            self.scroll = max(0, self.scroll - 300)
        elif key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_F1, pygame.K_BACKSPACE):
            self.app.goto(MenuScreen(self.app))

    def on_wheel(self, pos, dy):
        self.scroll = max(0, self.scroll - dy * 40)

    def draw(self, dst):
        dst.fill(T.BG)
        title(dst, "Help")
        area = pygame.Rect(40, 90, T.W - 80, T.H - 140)
        rows: List[Tuple[str, str, str, tuple]] = [("Controls", "", "", T.CYAN)]
        for k, v in CONTROL_HELP:
            rows.append((k, v, "", T.TEXT))
        rows.append(("", "", "", T.TEXT))
        rows.append(("Tasks", "", "", T.CYAN))
        for k, v, w_ in TASK_HELP:
            rows.append((k, v, w_, T.TEXT))
        rows.append(("", "", "", T.TEXT))
        rows.append(("Scoring", "", "", T.CYAN))
        for ln in SCORING_HELP:
            rows.append((ln, "", "", T.TEXT))
        y = area.y - self.scroll
        total = 0
        dst.set_clip(area)
        for a, b, c, col in rows:
            if area.y - 30 < y < area.bottom:
                if not b and not c and col == T.CYAN:
                    T.blit_text(dst, a, (area.x, y), 20, col, bold=True)
                elif not b and not c:
                    T.blit_text(dst, a, (area.x, y), 15, col)
                else:
                    T.blit_text(dst, a, (area.x, y), 15, T.DIM)
                    T.blit_text(dst, b, (area.x + 190, y), 15, T.TEXT)
                    if c:
                        T.blit_text(dst, c, (area.x + 470, y), 15, T.DIM)
            y += 23
            total += 23
        dst.set_clip(None)
        self.scroll = min(self.scroll, max(0, total - area.h))
        T.blit_text(dst, "Esc back", (40, T.H - 40), 14, T.DIM)


# ---- spoken secondary task ---------------------------------------------------------------------
def audio_summary_lines(a: Optional[dict]) -> List[Tuple[str, tuple]]:
    """Debrief lines of the spoken task: its own accuracy and time, and the dual-task cost against the solo block."""
    if not a or not a.get("n"):
        return [] if not a else [(f"Audio {VARIANT_GLYPH[a['variant']]}: sin ítems", T.DIM)]
    rt = f"   {a['rt_s']:.1f} s" if a.get("rt_s") is not None else ""
    out = [(f"Audio {VARIANT_GLYPH[a['variant']]}  {a['accuracy']:.0f}%{rt}   ({a['correct']}/{a['wrong']}/{a['blank']})",
            T.WHITE)]
    c = a.get("cost")
    if c:
        rtc = f"   {c['cost_rt_s']:+.1f} s" if c.get("cost_rt_s") is not None else ""
        col = T.GREEN if c["cost_points"] <= 5 else (T.AMBER if c["cost_points"] <= 15 else T.RED)
        out.append((f"Coste doble tarea  {c['cost_points']:+.0f} pts{rtc}   (solo {c['solo_accuracy']:.0f}%)", col))
    else:
        out.append(("A: audio solo", T.DIM))
    return out


def audio_decisions(world: World) -> List[Tuple[str, str, str]]:
    au = getattr(world, "audio", None)
    if au is None:
        return []
    out = []
    for it in au.log:
        if it.outcome not in ("wrong", "blank"):
            continue
        name = A_NICE.get(it.kind, it.kind)
        if it.kind == "sum":
            detail = " + ".join(it.tokens) + f" = {it.truth}" + (f";  tú {it.answer}" if it.outcome == "wrong" else ";  sin respuesta")
        elif it.outcome == "wrong":
            detail = f"{code_text(it.tokens)}  ≠  {code_text(au.target)}"
        else:
            detail = f"{code_text(it.tokens)}  =  objetivo;  sin M"
        out.append((it.outcome, f"{name}  {T.fmt_time(it.closed_at or 0)}", detail))
    return out


class AudioSoloScreen(Screen):
    """Single-task baseline: the same spoken items (same seed, level and variant) with no traffic. Saved apart from the
    radar runs; the run it follows gets its dual-task cost. Esc abandons (nothing saved), P pauses."""
    ITEMS = {"sum": 8, "code": 20}                # codes: about 7 targets at a 35 % target share

    def __init__(self, app, back, variant: str, level: int, seed: int):
        self.app, self.back = app, back
        self.variant, self.level, self.seed = variant, level, seed
        self.lang = app.lang
        self.au = app.make_audio(variant, level, seed, max_items=self.ITEMS[variant], gap_scale=0.25, start_s=2.0)
        self.paused = False
        self.typing: Optional[str] = None
        self.feedback: List[list] = []
        self._seen = 0
        self.real = 0.0
        app.voice.preload(self.lang)

    def update(self, dt):
        self.real += dt
        au = self.au
        if not self.paused:
            au.tick(dt)
            cues = au.pop_cues()
            if cues:
                self.app.voice.play(self.lang, cues)
        while self._seen < len(au.log):
            it = au.log[self._seen]
            self._seen += 1
            if it.outcome == "correct":
                self.feedback.append(["OK", T.GREEN, 1.2])
            elif it.outcome == "wrong":
                self.feedback.append([f"MAL  {it.truth}" if it.kind == "sum" else "MAL", T.RED, 2.0])
            elif it.outcome == "blank":
                self.feedback.append([f"PERDIDA  {it.truth}" if it.kind == "sum" else "PERDIDA", T.AMBER, 2.0])
        for f in self.feedback:
            f[2] -= dt
        self.feedback = [f for f in self.feedback if f[2] > 0][-2:]
        if au.done:
            au.finish()
            self.app.stats.add_audio_solo(au.summary(), self.seed, voice=self.lang)
            self.back.msg = ""
            self.app.goto(self.back)

    def on_key(self, key, mods, unicode):
        au = self.au
        if key == pygame.K_ESCAPE:
            self.app.voice.stop()
            self.app.goto(self.back)
            return
        if key == pygame.K_p:
            self.paused = not self.paused
            self.app.voice.pause(self.paused)
            return
        if self.paused:
            return
        if self.typing is not None:
            if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                buf, self.typing = self.typing, None
                if buf:
                    au.answer_sum(int(buf))
            elif key == pygame.K_BACKSPACE:
                self.typing = self.typing[:-1]
            elif len(unicode) == 1 and unicode in "0123456789" and len(self.typing) < 3:
                self.typing += unicode
            return
        if key == pygame.K_v and self.variant == "sum":
            self.typing = ""
        elif key == pygame.K_m and self.variant == "code":
            au.press_match()

    def draw(self, dst):
        dst.fill(T.BG)
        au = self.au
        title(dst, f"Audio solo  {VARIANT_GLYPH[self.variant]}", f"L{self.level}  {self.lang.upper()}  seed {self.seed}")
        cx, cy = T.W // 2, T.H // 2 - 40
        it = au.open_item
        speaking = au.speaking
        col = T.CYAN if speaking else (T.AMBER if it is not None else T.FAINT)
        speaker(dst, cx - 30, cy - 120, col, 2 if speaking else (1 if it is not None else 0), k=5)
        if self.variant == "code":
            tgt = code_text(au.target) if au.show_target else "· · ·"
            T.blit_text(dst, tgt, (cx, cy + 10), 40, T.WHITE if au.show_target else T.FAINT, mono=True, bold=True, anchor="midtop")
            T.blit_text(dst, "M", (cx, cy + 80), 28, T.YELLOW if it is not None else T.FAINT, mono=True, bold=True, anchor="midtop")
        else:
            txt = f"V {self.typing}_" if self.typing is not None else "V"
            T.blit_text(dst, txt, (cx, cy + 20), 40, T.YELLOW if (self.typing is not None or it is not None) else T.FAINT,
                        mono=True, bold=True, anchor="midtop")
        n = au.max_items or 0
        done = len(au.log)
        x0 = cx - n * 14
        for i in range(n):
            o = au.log[i].outcome if i < done else None
            c = {"correct": T.GREEN, "wrong": T.RED, "blank": T.AMBER, "info": T.DIM}.get(o, T.LINE)
            pygame.draw.circle(dst, c, (x0 + i * 28 + 14, cy + 170), 8 if i < done else 5)
        fy = cy + 200
        for text_, col_, _ in self.feedback:
            T.blit_text(dst, text_, (cx, fy), 22, col_, bold=True, anchor="midtop")
            fy += 30
        T.blit_text(dst, "P pausa    Esc salir", (40, T.H - 46), 14, T.DIM)
        if self.paused:
            T.blit_text(dst, "PAUSA", (cx, 100), 30, T.AMBER, bold=True, anchor="midtop")
