"""One running game: input handling, trial proposals, rendering of the live scope and panels."""
from __future__ import annotations

from collections import deque
from typing import Deque, Dict, List, Optional, Tuple

import pygame

from ..core.geometry import angle_diff, bearing, dist, norm360
from ..core.scenario import level_spec
from ..core.tasks import KEYS, NICE
from ..core.tutorial import Tutorial
from ..core.world import TRANSFER_RANGE, World
from . import panels
from . import theme as T
from .scope import Overlay, RAc, ScopeView

SCOPE_RECT = pygame.Rect(8, 44, 930, 744)
STRIP_RECT = pygame.Rect(946, 44, 486, 268)
TASK_RECT = pygame.Rect(946, 318, 486, 260)
MSG_RECT = pygame.Rect(946, 584, 486, 86)
CMD_RECT = pygame.Rect(946, 676, 486, 130)
TOP_RECT = pygame.Rect(0, 0, T.W, 38)
# layout while the practice is running: the tutorial text takes the place of the message log
T_STRIP_RECT = pygame.Rect(946, 44, 486, 192)
T_TASK_RECT = pygame.Rect(946, 242, 486, 306)
T_TUT_RECT = pygame.Rect(946, 554, 486, 116)

KEY_NAMES = {pygame.K_y: "y", pygame.K_n: "n", pygame.K_a: "a", pygame.K_d: "d", pygame.K_SPACE: "space",
             pygame.K_1: "1", pygame.K_2: "2", pygame.K_3: "3", pygame.K_4: "4", pygame.K_5: "5", pygame.K_6: "6",
             pygame.K_KP1: "1", pygame.K_KP2: "2", pygame.K_KP3: "3", pygame.K_KP4: "4", pygame.K_KP5: "5",
             pygame.K_KP6: "6"}


class GameSession:
    def __init__(self, world: World, mode: str, tutorial: Optional[Tutorial] = None):
        self.world = world
        self.mode = mode
        self.tut = tutorial
        self.spec = level_spec(world.scenario.level)
        self.paused = False
        self.pause_menu = False
        self.scope = ScopeView(SCOPE_RECT, world.sector)
        self.trails: Dict[str, Deque[Tuple[float, float]]] = {}
        self._trail_mark = -1
        self.proposal: Optional[dict] = None
        self.typing: Optional[Tuple[str, str]] = None
        self.flash = ""
        self.flash_ttl = 0.0
        self.scroll = 0
        self.hits: panels.Hit = []
        self.states: Dict[str, str] = {}
        self._prop_key = None
        self._prop_result: Tuple[list, Optional[tuple]] = ([], None)
        self.real = 0.0
        self.aids = 3 if tutorial else self.spec.aids
        self.quit_request = False
        self.auto_paused = False
        self.abort_request = False
        self._fb_seen = 0                               # how many finished tasks already produced on-screen feedback
        self.feedback: List[list] = []                  # [text, colour, seconds left]: immediate result of every task

    # ---- time ----------------------------------------------------------------------------
    @property
    def running(self) -> bool:
        return not self.paused and not (self.tut is not None and self.tut.freeze)

    def update(self, dt: float) -> None:
        self.real += dt
        if self.flash_ttl > 0:
            self.flash_ttl -= dt
            if self.flash_ttl <= 0:
                self.flash = ""
        w = self.world
        if self.running:
            w.advance(dt)
        self._collect_feedback(dt)
        mark = int(w.t // 5)
        if mark != self._trail_mark:
            self._trail_mark = mark
            for cs, a in w.aircraft.items():
                self.trails.setdefault(cs, deque(maxlen=5)).append((a.x, a.y))
            for cs in list(self.trails):
                if cs not in w.aircraft:
                    del self.trails[cs]
        if self.tut is not None:
            self.tut.update()
        if self.proposal and self.proposal["cs"] not in w.aircraft:
            self.proposal = None
            self.typing = None
        if w.selected and w.selected not in w.aircraft:
            w.selected = None
            self.proposal = None
        if w.selected is None and self.proposal:
            self.proposal = None

    def _collect_feedback(self, dt: float) -> None:
        log = self.world.tasks.log
        while self._fb_seen < len(log):
            t = log[self._fb_seen]
            self._fb_seen += 1
            if t.outcome not in ("correct", "wrong", "blank"):
                continue
            name = NICE.get(t.kind, t.kind)
            right = t.options[t.correct] if (t.correct is not None and t.options and t.correct < len(t.options)) else ""
            if t.outcome == "correct":
                item = [f"OK  {name}", T.GREEN, 1.6]
            elif t.outcome == "wrong":
                item = [f"WRONG  {name}" + (f": it was {right}" if right else ""), T.RED, 3.2]
            else:
                item = [f"MISSED  {name}" + (f" {t.aircraft}" if t.aircraft else "") + (f": it was {right}" if right else ""), T.AMBER, 3.2]
            self.feedback.append(item)
        for f in self.feedback:
            f[2] -= dt
        self.feedback = [f for f in self.feedback if f[2] > 0][-3:]

    def flash_msg(self, s: str, ttl: float = 3.0) -> None:
        self.flash, self.flash_ttl = s, ttl

    # ---- selection ----------------------------------------------------------------------
    def select(self, cs: Optional[str]) -> None:
        if cs == self.world.selected:
            return
        self.world.select(cs)
        self.proposal = None
        self.typing = None

    def cycle(self, step: int) -> None:
        order = panels.strip_order(self.world)
        if not order:
            return
        cur = self.world.selected
        i = order.index(cur) if cur in order else (-1 if step > 0 else 0)
        self.select(order[(i + step) % len(order)])

    # ---- proposal ------------------------------------------------------------------------
    def _base(self):
        a = self.world.aircraft[self.world.selected]
        hdg = a.tgt_hdg if (not a.nav and a.tgt_hdg is not None) else a.hdg
        return a, hdg

    def _prop(self) -> dict:
        cs = self.world.selected
        if self.proposal is None or self.proposal["cs"] != cs:
            self.proposal = {"cs": cs, "hdg": None, "alt": None, "spd": None, "turn": None, "off": None, "base": None}
        return self.proposal

    def adjust(self, kind: str, delta: float, turn: Optional[str] = None) -> None:
        w = self.world
        if not w.selected or w.selected not in w.aircraft:
            self.flash_msg("Select an aircraft.")
            return
        a, base_h = self._base()
        p = self._prop()
        if kind == "hdg":
            # keep the SIGNED total turn so that R,R,R,L (= +10) is flown as a 10 degree right turn and not as a forced
            # 350 degree left turn; only a total beyond 180 degrees forces the long way round
            if p.get("off") is None:
                cur = p["hdg"] if p["hdg"] is not None else base_h
                p["base"] = base_h
                p["off"] = angle_diff(cur, base_h)
            p["off"] += delta
            p["hdg"] = float(norm360(round(p["base"] + p["off"])))
            p["turn"] = None if abs(p["off"]) < 0.5 else ("R" if p["off"] > 0 else "L")
        elif kind == "alt":
            cur = p["alt"] if p["alt"] is not None else a.tgt_alt
            new = min(max(cur + delta, 3000.0), float(a.ac_type.ceiling))
            p["alt"] = float(new)
        elif kind == "spd":
            cur = p["spd"] if p["spd"] is not None else a.tgt_tas
            t = a.ac_type
            p["spd"] = float(min(max(cur + delta, t.v_min), t.v_max))
        w.note_action("propose", a.callsign)
        self._normalize(a)

    def _normalize(self, a) -> None:
        p = self.proposal
        if p is None:
            return
        _, base_h = self._base()
        if p["hdg"] is not None and abs(angle_diff(p["hdg"], base_h)) < 0.5 and a.nav is False:
            p["hdg"] = None
            p["turn"] = None
            p["off"] = None
        if p["alt"] is not None and abs(p["alt"] - a.tgt_alt) < 1:
            p["alt"] = None
        if p["spd"] is not None and abs(p["spd"] - a.tgt_tas) < 0.5:
            p["spd"] = None
        if all(p[k] is None for k in ("hdg", "alt", "spd")):
            self.proposal = None

    def send(self) -> None:
        w = self.world
        p = self.proposal
        if not p or p["cs"] not in w.aircraft or all(p[k] is None for k in ("hdg", "alt", "spd")):
            self.proposal = None
            return
        ok, msg, cl = w.issue(p["cs"], hdg=p["hdg"], alt=p["alt"], spd=p["spd"], turn_dir=p["turn"])
        if ok:
            self.proposal = None
            self.typing = None
        else:
            self.flash_msg(msg)

    def commit_typing(self) -> None:
        if not self.typing or not self.world.selected:
            self.typing = None
            return
        field, buf = self.typing
        self.typing = None
        if not buf:
            return
        v = int(buf)
        a, _ = self._base()
        if field == "h" and v > 360:
            self.flash_msg("Heading 0-360")
            return
        p = self._prop()
        if field == "h":
            p["hdg"], p["turn"], p["off"] = float(norm360(v)), None, None
        elif field == "f":
            p["alt"] = float(v * 100)
        elif field == "s":
            p["spd"] = float(v)
        self.world.note_action("propose", a.callsign)

    # ---- input -----------------------------------------------------------------------------
    def on_key(self, key: int, mods: int, unicode: str = "") -> None:
        w = self.world
        if self.pause_menu:
            if key in (pygame.K_ESCAPE, pygame.K_p, pygame.K_RETURN):
                self.pause_menu = False
                self.paused = False
            elif key == pygame.K_q:
                self.abort_request = True
            return
        if self.typing is not None:
            f, buf = self.typing
            if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.commit_typing()
                self.send()
            elif key == pygame.K_ESCAPE:
                self.typing = None
            elif key == pygame.K_BACKSPACE:
                self.typing = (f, buf[:-1])
            elif len(unicode) == 1 and unicode in "0123456789" and len(buf) < 3:
                self.typing = (f, buf + unicode)
            return
        if key == pygame.K_p:
            if self.paused and self.auto_paused:
                self.paused = self.auto_paused = False        # resuming after a focus loss: no penalty, no pause counted
                return
            self.paused = not self.paused
            if self.paused:
                w.pauses += 1
            return
        if self.paused:
            if key == pygame.K_ESCAPE:
                self.paused = self.auto_paused = False
            elif key == pygame.K_q and self.tut is None:
                self.abort_request = True          # quit is available from ANY pause, not only from the Esc menu
            return
        shift = bool(mods & pygame.KMOD_SHIFT)
        ctrl = bool(mods & pygame.KMOD_CTRL)
        if key == pygame.K_TAB:
            self.cycle(-1 if shift else 1)
            return
        if key == pygame.K_ESCAPE:
            if self.proposal:
                self.proposal = None
            elif w.selected:
                self.select(None)
            else:
                self.paused = True
                self.pause_menu = True
                w.pauses += 1
            return
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self.tut is not None and self.tut.index == len(self.tut.steps) - 1:
                w.note_action("finish")
            self.send()
            return
        step_h = 1 if ctrl else (10 if shift else 5)
        if key == pygame.K_RIGHT:
            self.adjust("hdg", step_h, "R")
            return
        if key == pygame.K_LEFT:
            self.adjust("hdg", -step_h, "L")
            return
        if key == pygame.K_UP:
            self.adjust("alt", 2000 if shift else (100 if ctrl else 1000))
            return
        if key == pygame.K_DOWN:
            self.adjust("alt", -(2000 if shift else (100 if ctrl else 1000)))
            return
        if key in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
            self.adjust("spd", 20 if shift else 10)
            return
        if key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.adjust("spd", -(20 if shift else 10))
            return
        if key == pygame.K_r:
            if w.selected:
                ok, msg, _ = w.issue(w.selected, resume=True)
                if not ok:
                    self.flash_msg(msg)
                self.proposal = None
            else:
                self.flash_msg("Select an aircraft.")
            return
        if key == pygame.K_t:
            if w.selected:
                ok, msg, _ = w.request_transfer(w.selected)
                if not ok:
                    self.flash_msg(msg)
            else:
                self.flash_msg("Select an aircraft.")
            return
        if key in (pygame.K_h, pygame.K_f, pygame.K_s):
            if w.selected:
                self.typing = ({pygame.K_h: "h", pygame.K_f: "f", pygame.K_s: "s"}[key], "")
            else:
                self.flash_msg("Select an aircraft.")
            return
        name = KEY_NAMES.get(key)
        if name:
            self._task_key(name)

    def _task_key(self, name: str) -> None:
        if name.isdigit():
            t = panels.numeric_owner(self.world.tasks.tasks)      # same rule as the task panel: most urgent numeric task
            if t is not None and name in KEYS[t.kind]:
                self.world.tasks.answer(t.id, KEYS[t.kind].index(name))
            return
        for t in list(self.world.tasks.tasks):
            keys = KEYS.get(t.kind)
            if keys and name in keys and t.is_open:
                self.world.tasks.answer(t.id, keys.index(name))
                return

    def on_click(self, pos, button: int, shift: bool = False) -> None:
        if self.paused:
            if self.auto_paused and not self.pause_menu:
                self.paused = self.auto_paused = False     # clicking back into the window after a focus loss resumes
            return
        w = self.world
        if button == 1:
            for r, action in self.hits:
                if r.collidepoint(pos):
                    if action[0] == "select":
                        self.select(action[1])
                    elif action[0] == "answer":
                        w.tasks.answer(action[1], action[2])
                    elif action[0] == "send":
                        self.send()
                    return
            if SCOPE_RECT.collidepoint(pos):
                cs = self.scope.pick_aircraft(pos)
                if cs:
                    self.select(cs)
                    return
                fx = self.scope.pick_fix(pos)
                if fx and w.selected and shift:      # Shift+click only: a plain click near a fix must never send an instruction
                    ok, msg, _ = w.issue(w.selected, dct=fx)
                    if not ok:
                        self.flash_msg(msg)
                    self.proposal = None
                    return
                if fx and w.selected:
                    self.flash_msg(f"Shift+click {fx}")
                    return
                self.select(None)
        elif button == 3 and SCOPE_RECT.collidepoint(pos) and w.selected in w.aircraft:
            a = w.aircraft[w.selected]
            wx, wy = self.scope.to_world(*pos)
            hdg = round(bearing((a.x, a.y), (wx, wy)) / 5.0) * 5
            p = self._prop()
            p["hdg"], p["turn"], p["off"] = float(norm360(hdg)), None, None
            w.note_action("propose", a.callsign)
            self._normalize(a)

    def on_wheel(self, pos, dy: int) -> None:
        if (T_STRIP_RECT if self.tut is not None else STRIP_RECT).collidepoint(pos):
            self.scroll = max(0, self.scroll - dy)

    # ---- drawing --------------------------------------------------------------------------
    def _render_records(self) -> List[RAc]:
        w = self.world
        out: List[RAc] = []
        los = {c for pair in w.active_loss for c in pair}
        near: Dict[str, float] = {}
        if self.aids >= 2:
            for c in w.predicted:
                for cs in c.pair:
                    if cs not in near or c.t_start < near[cs]:
                        near[cs] = c.t_start
        self.states = {}
        for cs, a in w.aircraft.items():
            st = "normal"
            if cs in los:
                st = "los"
            elif cs in near and near[cs] < 90:
                st = "alert"
            elif cs in near and near[cs] < 240:
                st = "warn"
            self.states[cs] = st
            wv = w.wind_vec
            vs = 1 if a.tgt_alt > a.alt + 1 else (-1 if a.tgt_alt < a.alt - 1 else 0)
            fx = w.sector.fixes[a.exit_fix]
            tfr = (not a.transferred and not a.flags.get("tfr_done") and dist((a.x, a.y), fx) <= TRANSFER_RANGE)
            assigned = ""
            if cs == w.selected:
                cur_h = a.tgt_hdg if (not a.nav and a.tgt_hdg is not None) else None
                assigned = (f"H{(int(round(cur_h)) or 360):03d}" if cur_h is not None else f"DCT {a.next_wp[0] if a.next_wp else '-'}") \
                    + f" TAS{int(a.tgt_tas)}"
            out.append(RAc(cs, a.x, a.y, a.alt, a.hdg, a.ground_speed(wv), a.track(wv), vs, a.tgt_alt,
                           cs == w.selected, st, tfr, assigned))
        return out

    def _proposal_overlay(self) -> Optional[dict]:
        p = self.proposal
        w = self.world
        if not p or p["cs"] not in w.aircraft:
            return None
        a, base_h = self._base()
        hdg = p["hdg"] if p["hdg"] is not None else base_h
        res = ([], None)
        if self.aids >= 2:
            key = (p["cs"], p["hdg"], p["alt"], p["spd"], p["turn"], w._tick_n // 5, len(w.clearances))
            if key != self._prop_key:
                self._prop_key = key
                self._prop_result = w.what_if(p["cs"], hdg=p["hdg"], alt=p["alt"], spd=p["spd"], turn_dir=p["turn"])
            res = self._prop_result
        return {"cs": p["cs"], "hdg": hdg, "conflicts": res[0], "zone": res[1]}

    def draw(self, dst: pygame.Surface) -> None:
        w = self.world
        dst.fill(T.BG)
        recs = self._render_records()
        ov = Overlay(aids=self.aids, t=w.t, conflicts=w.predicted, trajs=w.trajs, trails=self.trails,
                     los_pairs=list(w.active_loss.keys()), zone_alerts=w.zone_alerts, zone_active=w.zone_active,
                     zone_scheduled=bool(w.scenario.zone_from is not None and w.spec.zone), proposal=self._proposal_overlay(),
                     wind=w.wind_vec, blink=int(self.real * 2.5) % 2 == 0,
                     highlight=(self.tut.step.highlight if (self.tut is not None and self.tut.step) else ""))
        self.scope.draw(dst, recs, ov)
        fy = SCOPE_RECT.y + 34
        for text_, col_, ttl_ in self.feedback:             # immediate, unmistakable result of every answered / missed task
            surf = T.text(text_, 18, col_, bold=True)
            bg = pygame.Surface((surf.get_width() + 20, surf.get_height() + 6), pygame.SRCALPHA)
            bg.fill((7, 16, 14, 200))
            r_ = bg.get_rect(midtop=(SCOPE_RECT.centerx, fy))
            dst.blit(bg, r_)
            dst.blit(surf, (r_.x + 10, r_.y + 3))
            fy += r_.h + 4
        self.hits = []
        strip_r, task_r = (T_STRIP_RECT, T_TASK_RECT) if self.tut is not None else (STRIP_RECT, TASK_RECT)
        self.scroll = panels.draw_strips(dst, strip_r, w, w.selected, self.scroll, self.states, self.hits)
        panels.draw_tasks(dst, task_r, w, self.hits, ov.blink)
        if self.tut is None:
            panels.draw_messages(dst, MSG_RECT, w)
        panels.draw_command_box(dst, CMD_RECT, w, w.selected, self.proposal, self.typing, self.flash, self.hits)
        label = f"{self.mode}  -  {self.spec.name}" if self.tut is None else "PRACTICE"
        panels.draw_topbar(dst, TOP_RECT, w, label, self.paused, len(w.losses),
                           extra="" if self.tut is None else "Esc: leave practice")
        if self.tut is not None and self.tut.step:
            self._draw_tutorial(dst)
        if self.paused:
            self._draw_pause(dst)

    def _draw_tutorial(self, dst) -> None:
        s = self.tut.step
        r = T_TUT_RECT
        pygame.draw.rect(dst, T.PANEL, r)
        pygame.draw.rect(dst, T.CYAN, r, 2)
        T.blit_text(dst, f"{self.tut.index + 1}/{len(self.tut.steps)}  {s.title}", (r.x + 12, r.y + 8), 16, T.CYAN, bold=True)
        y = r.y + 32
        for ln in T.wrap(s.text, 15, r.w - 24)[:3]:
            T.blit_text(dst, ln, (r.x + 12, y), 15, T.TEXT)
            y += 20
        if s.keys:
            T.blit_text(dst, s.keys, (r.x + 12, r.bottom - 20), 12, T.YELLOW, mono=True)

    def _draw_pause(self, dst) -> None:
        veil = pygame.Surface((T.W, T.H), pygame.SRCALPHA)
        veil.fill((0, 0, 0, 150))
        dst.blit(veil, (0, 0))
        r = pygame.Rect(0, 0, 300, 150)
        r.center = (SCOPE_RECT.centerx, SCOPE_RECT.centery)
        pygame.draw.rect(dst, T.PANEL, r)
        pygame.draw.rect(dst, T.AMBER, r, 2)
        T.blit_text(dst, "PAUSED", (r.centerx, r.y + 16), 30, T.AMBER, bold=True, anchor="midtop")
        lines = ["P    Resume"]
        if self.tut is None:
            lines.append("Q    Abandon")
        if self.world.scenario.level >= 5 and self.tut is None and not self.auto_paused:
            lines.append("Level 5+: assisted run")
        y = r.y + 64
        for ln in lines:
            T.blit_text(dst, ln, (r.x + 24, y), 16, T.TEXT, mono=True)
            y += 24
