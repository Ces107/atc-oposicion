"""Plays the pre-generated clips of the spoken task (assets/voice, made by tools/make_voice.py). Offline, no TTS at run time.

If the mixer cannot start (no audio device) the player is "silent": the game still runs and says so on the briefing.
Clip lengths are read from the WAV headers, so the core engine can schedule tokens without the mixer.
"""
from __future__ import annotations

import json
import os
import wave
from typing import Dict, List, Optional

import pygame

from ..core.audio_task import DIGITS, LETTERS, TONE
from ..core.paths import resource_dir

VOICE_DIR = os.path.join("assets", "voice")


def voice_dir() -> str:
    return os.path.join(resource_dir(), VOICE_DIR)


def clip_path(lang: str, token: str) -> str:
    if token == TONE:
        return os.path.join(voice_dir(), "tone.wav")
    return os.path.join(voice_dir(), lang, f"{token}.wav")


def durations(lang: str) -> Dict[str, float]:
    """Seconds of every clip of a language (from the WAV headers); missing clips are left out."""
    out: Dict[str, float] = {}
    for tok in list(DIGITS) + list(LETTERS) + [TONE]:
        p = clip_path(lang, tok)
        try:
            with wave.open(p, "rb") as w:
                out[tok] = w.getnframes() / float(w.getframerate())
        except (OSError, EOFError, wave.Error):
            continue
    return out


def manifest() -> Dict:
    try:
        with open(os.path.join(voice_dir(), "voice.json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def clips_complete(lang: str) -> bool:
    return len(durations(lang)) == len(DIGITS) + len(LETTERS) + 1


class Voice:
    """Lazy mixer start and clip cache. `available` = clips can actually be heard."""

    def __init__(self) -> None:
        self._mixer_ok: Optional[bool] = None
        self._cache: Dict[str, "pygame.mixer.Sound"] = {}
        self.channel = None

    def _mixer(self) -> bool:
        if self._mixer_ok is None:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
                pygame.mixer.set_reserved(1)
                self.channel = pygame.mixer.Channel(0)
                self._mixer_ok = True
            except (pygame.error, NotImplementedError, AttributeError):
                self._mixer_ok = False
        return self._mixer_ok

    def available(self, lang: str) -> bool:
        return clips_complete(lang) and self._mixer()

    def preload(self, lang: str) -> int:
        n = 0
        if not self._mixer():
            return 0
        for tok in list(DIGITS) + list(LETTERS) + [TONE]:
            if self._sound(lang, tok) is not None:
                n += 1
        return n

    def _sound(self, lang: str, tok: str):
        key = TONE if tok == TONE else f"{lang}/{tok}"
        s = self._cache.get(key)
        if s is None:
            try:
                s = pygame.mixer.Sound(clip_path(lang, tok))
            except (pygame.error, FileNotFoundError, OSError):
                return None
            self._cache[key] = s
        return s

    def play(self, lang: str, tokens: List[str]) -> None:
        if not tokens or not self._mixer():
            return
        for tok in tokens:
            s = self._sound(lang, tok)
            if s is None:
                continue
            try:
                if self.channel.get_busy():
                    self.channel.queue(s)
                else:
                    self.channel.play(s)
            except pygame.error:
                pass

    def pause(self, on: bool) -> None:
        if self._mixer_ok:
            try:
                (pygame.mixer.pause if on else pygame.mixer.unpause)()
            except pygame.error:
                pass

    def stop(self) -> None:
        if self._mixer_ok and self.channel is not None:
            try:
                self.channel.stop()
            except pygame.error:
                pass
